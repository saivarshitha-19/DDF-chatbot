/*!
 * Copyright (c) 2024 Oracle and/or its affiliates.
 * All rights reserved. Oracle Digital Assistant Client Web SDK, Release: 24.8.0
 */ !(function (e, factory) {
  "object" == typeof exports && "object" == typeof module
    ? (module.exports = factory())
    : "function" == typeof define && define.amd
    ? define("WebSDK", [], factory)
    : "object" == typeof exports
    ? (exports.WebSDK = factory())
    : (e.WebSDK = factory());
  e.WebSDK = factory();
})(self, () =>
  (() => {
    "use strict";
    var e = {
        8557: function (e, t, s) {
          var i =
              (this && this.t) ||
              (Object.create
                ? function (e, t, s, i) {
                    void 0 === i && (i = s);
                    var o = Object.getOwnPropertyDescriptor(t, s);
                    (o &&
                      !("get" in o ? !t.p : o.writable || o.configurable)) ||
                      (o = {
                        enumerable: !0,
                        get: function () {
                          return t[s];
                        },
                      }),
                      Object.defineProperty(e, i, o);
                  }
                : function (e, t, s, i) {
                    void 0 === i && (i = s), (e[i] = t[s]);
                  }),
            o =
              (this && this.u) ||
              function (e, t) {
                for (var s in e)
                  "default" === s ||
                    Object.prototype.hasOwnProperty.call(t, s) ||
                    i(t, e, s);
              };
          Object.defineProperty(t, "p", { value: !0 }), o(s(7607), t);
        },
        7607: function (e, t, s) {
          var i =
            (this && this.v) ||
            function (e, t, s, i) {
              return new (s || (s = Promise))(function (o, r) {
                function a(e) {
                  try {
                    c(i.next(e));
                  } catch (e) {
                    r(e);
                  }
                }
                function n(e) {
                  try {
                    c(i.throw(e));
                  } catch (e) {
                    r(e);
                  }
                }
                function c(e) {
                  var t;
                  e.done
                    ? o(e.value)
                    : ((t = e.value),
                      t instanceof s
                        ? t
                        : new s(function (e) {
                            e(t);
                          })).then(a, n);
                }
                c((i = i.apply(e, t || [])).next());
              });
            };
          Object.defineProperty(t, "p", { value: !0 }),
            (t.RecognitionLocale = t.CoreSpeechRecognitionService = void 0);
          const o = s(6064),
            r = s(6246);
          Object.defineProperty(t, "RecognitionLocale", {
            enumerable: !0,
            get: function () {
              return r.RecognitionLocale;
            },
          });
          const a = s(5565);
          class n {
            static getInstance() {
              return this._ || (this._ = new n()), this._;
            }
            constructor() {
              (this.O = a.UserAudioProviderService.getInstance()),
                (this.$ = !1),
                (this.I = []),
                (this.C = (e) => {
                  try {
                    this.T(e);
                  } catch (e) {
                    this.P(r.RecognitionError.RecognitionProcessingFailure),
                      this.L();
                  }
                }),
                (this.F = (e) => {
                  var t;
                  null === (t = this.N) ||
                    void 0 === t ||
                    t.trigger(r.SpeechRecognitionServiceEvent.ASRVisualData, e);
                }),
                (this.R = () =>
                  i(this, void 0, void 0, function* () {
                    var e;
                    if (this.U.tokenGenerator) {
                      const t = yield this.V.get();
                      null === (e = this.B) ||
                        void 0 === e ||
                        e.send(`Bearer ${t.token}`);
                    }
                    this.W();
                  })),
                (this.G = () => {
                  this.$ && this.L();
                }),
                (this.q = (e) => {
                  try {
                    const t = JSON.parse(e.data);
                    if (!t.event && t.code) return;
                    const s = (function (e) {
                      let t, s;
                      const i = e.requestId,
                        o = e.nbest;
                      "partialResult" === e.event
                        ? ((t = "partial"), (s = o[0].utterance))
                        : (null == o ? void 0 : o.length)
                        ? ((t = "final"), (s = o[0].utterance))
                        : ((t = "error"),
                          (s = e.resultCode
                            ? r.RecognitionError.RecognitionTooMuchSpeechTimeout
                            : r.RecognitionError.RecognitionNoSpeechTimeout));
                      return { requestId: i, type: t, text: s, message: e };
                    })(t);
                    this.Y(s);
                  } catch (e) {
                    this.P(r.RecognitionError.RecognitionProcessingFailure),
                      this.L();
                  }
                }),
                (this.J = () => {
                  var e;
                  this.K() &&
                    (this.P(r.RecognitionError.RecognitionProcessingFailure),
                    null === (e = this.B) || void 0 === e || e.close());
                }),
                this.O.on(a.UserAudioEvent.AnalyserData, this.F),
                this.O.on(a.UserAudioEvent.AudioData, this.C);
            }
            startRecognition() {
              return i(this, void 0, void 0, function* () {
                var e;
                if (!this.$) {
                  if (((this.$ = !0), this.B)) {
                    const e = this.B.readyState;
                    if (
                      e === r.ConnectionState.Closing ||
                      e === r.ConnectionState.Connecting
                    )
                      return;
                  }
                  yield this.O.start(),
                    null === (e = this.N) ||
                      void 0 === e ||
                      e.trigger(r.SpeechRecognitionServiceEvent.ASRStart),
                    this.X || (yield this.ee()),
                    (this.B = this.te(this.X));
                }
              });
            }
            stopRecognition() {
              return i(this, void 0, void 0, function* () {
                return this.se();
              });
            }
            setConfig(e) {
              return i(this, void 0, void 0, function* () {
                return (
                  e.recognitionLocale ||
                    (e.recognitionLocale = r.RecognitionLocale.EN_US),
                  e.tokenGenerator &&
                    (this.V = o.AuthTokenService.getInstance()),
                  (this.U = e),
                  (this.N = e.dispatcher),
                  this.ee()
                );
              });
            }
            setLocale(e) {
              (0, r.isValidLocale)(e) &&
                this.U &&
                ((this.U.recognitionLocale = e),
                this.ee().catch((e) => {
                  console.warn(
                    "[WebSDK][RecognitionService] - Failed to get server URL",
                    e
                  );
                }));
            }
            T(e) {
              var t;
              this.K() && !this.I.length
                ? null === (t = this.B) || void 0 === t || t.send(e)
                : this.I.push(e);
            }
            Y(e) {
              var t;
              null === (t = this.N) ||
                void 0 === t ||
                t.trigger(r.SpeechRecognitionServiceEvent.ASRResponse, e),
                ["final", "error"].includes(e.type) && this.L();
            }
            ee() {
              return i(this, void 0, void 0, function* () {
                this.X = yield c(this.U, this.V);
              });
            }
            te(e) {
              var t;
              try {
                const t = new WebSocket(e);
                return (
                  (t.onopen = this.R),
                  (t.onclose = this.G),
                  (t.onmessage = this.q),
                  (t.onerror = this.J),
                  t
                );
              } catch (e) {
                const s = new Error(r.RecognitionError.RecognitionNotReady);
                throw (
                  (null === (t = this.N) ||
                    void 0 === t ||
                    t.trigger(r.SpeechRecognitionServiceEvent.ASRError, s),
                  s)
                );
              }
            }
            P(e) {
              var t;
              null === (t = this.N) ||
                void 0 === t ||
                t.trigger(r.SpeechRecognitionServiceEvent.ASRResponse, {
                  requestId: "",
                  text: e,
                  type: "error",
                });
            }
            W() {
              var e;
              if (this.K())
                for (; this.I.length; ) {
                  const t = this.I.shift();
                  t && (null === (e = this.B) || void 0 === e || e.send(t));
                }
            }
            K() {
              var e;
              return (
                (null === (e = this.B) || void 0 === e
                  ? void 0
                  : e.readyState) === r.ConnectionState.Open
              );
            }
            L() {
              this.se().catch((e) => {
                console.warn("[WebSDK][EndRecognition]", e);
              });
            }
            se() {
              return i(this, void 0, void 0, function* () {
                var e;
                if (!this.$) return;
                this.$ = !1;
                const t = this.B;
                this.K() && (null == t || t.send("Done")),
                  null == t || t.close(),
                  (this.B = void 0),
                  (this.I = []),
                  yield this.O.stop(),
                  null === (e = this.N) ||
                    void 0 === e ||
                    e.trigger(r.SpeechRecognitionServiceEvent.ASRStop);
              });
            }
          }
          t.CoreSpeechRecognitionService = n;
          const c = (e, t) =>
              i(void 0, void 0, void 0, function* () {
                if (e.tokenGenerator) {
                  const s = yield t.get();
                  (e.channelId = s.getClaim("channelId")),
                    (e.userId = s.getClaim("userId"));
                }
                if (!e.channelId || !e.userId)
                  throw Error(r.RecognitionError.RecognitionNotReady);
                return (function (e) {
                  const {
                      channelId: t,
                      userId: s,
                      tokenGenerator: i,
                      URI: r,
                    } = e,
                    a = `ws${e.isTLS ? "s" : ""}://`,
                    n = `${l}/${e.recognitionLocale}/${h}`,
                    c = Object.assign(
                      { channelId: t, userId: s, encodeURI: "audio/raw" },
                      i && { jwtInBody: "true" }
                    );
                  return (0, o.buildURL)(a, r, c, n);
                })(e);
              }),
            l = "/voice/stream/recognize",
            h = "generic";
        },
        1794: function (e, t, s) {
          var i =
            (this && this.v) ||
            function (e, t, s, i) {
              return new (s || (s = Promise))(function (o, r) {
                function a(e) {
                  try {
                    c(i.next(e));
                  } catch (e) {
                    r(e);
                  }
                }
                function n(e) {
                  try {
                    c(i.throw(e));
                  } catch (e) {
                    r(e);
                  }
                }
                function c(e) {
                  var t;
                  e.done
                    ? o(e.value)
                    : ((t = e.value),
                      t instanceof s
                        ? t
                        : new s(function (e) {
                            e(t);
                          })).then(a, n);
                }
                c((i = i.apply(e, t || [])).next());
              });
            };
          Object.defineProperty(t, "p", { value: !0 }),
            (t.CoreSpeechSynthesisService = void 0);
          const o = s(6246),
            r = s(6064);
          let a = 1,
            n = 1,
            c = 1;
          const l = window,
            h = l.addEventListener,
            d = l.speechSynthesis,
            p = l.SpeechSynthesisUtterance,
            u = l.navigator,
            g = clearTimeout;
          function m() {
            return new Promise((e) => {
              b(e),
                d.addEventListener("voiceschanged", () => {
                  b(e);
                });
            });
          }
          function b(e) {
            const t = d.getVoices();
            if (t.length) {
              e(
                (function (e) {
                  if (!Array.isArray(e)) return e.ie;
                  return e;
                })(w(t))
              );
            }
          }
          t.CoreSpeechSynthesisService = class {
            constructor() {
              if (
                ((this.$ = !1),
                (this.N = (0, r.generateEventDispatcher)()),
                !l || !d || !p)
              )
                throw Error("TTSNoWebAPI");
              v()
                .then((e) => {
                  this.oe = e;
                })
                .catch(() => {
                  this.oe = void 0;
                }),
                h("beforeunload", (e) => {
                  d.cancel(), g(this.re), delete e.returnValue;
                }),
                h(
                  "click",
                  () => {
                    d && (d.cancel(), d.resume(), d.speak(new p(" ")));
                  },
                  { once: !0 }
                );
            }
            speak(e) {
              if (this.oe) {
                const t = new p(e);
                (t.voice = this.oe),
                  (t.pitch = a),
                  (t.rate = n),
                  (t.volume = c),
                  d.paused && d.resume(),
                  this.$ ||
                    ((this.$ = !0),
                    this.N.trigger(o.SpeechSynthesisServiceEvent.TTSStart)),
                  d.speak(t),
                  this.oe.localService || (g(this.re), k((e) => (this.re = e)));
              }
            }
            cancel() {
              d.speaking && (d.cancel(), g(this.re));
            }
            getVoices() {
              return i(this, void 0, void 0, function* () {
                return m();
              });
            }
            setVoice(e) {
              return i(this, void 0, void 0, function* () {
                return (function (e) {
                  const t = e.map((e) =>
                    Object.assign({ lang: "", name: "" }, e)
                  );
                  return m().then((e) => {
                    for (const s of t)
                      for (const t of e)
                        if (y(s.lang, t.lang) && y(s.name, t.name)) return t;
                    for (const s of t)
                      for (const t of e) if (y(s.lang, t.lang)) return t;
                    for (const s of t)
                      for (const t of e) if (t.lang.includes(s.lang)) return t;
                    return v();
                  });
                })(e).then((e) => {
                  var t, s, i;
                  (this.oe = e),
                    (a = null !== (t = e.pitch) && void 0 !== t ? t : 1),
                    (n = null !== (s = e.rate) && void 0 !== s ? s : 1),
                    (c = null !== (i = e.volume) && void 0 !== i ? i : 1);
                });
              });
            }
            getVoice() {
              return this.oe;
            }
            on(e, t) {
              this.N.bind(e, t);
            }
            off(e, t) {
              this.N.unbind(e, t);
            }
          };
          const f = [
              "Albert",
              "Bad News",
              "Bahh",
              "Bells",
              "Boing",
              "Bubbles",
              "Cellos",
              "Good News",
              "Jester",
              "Organ",
              "Superstar",
              "Trinoids",
              "Whisper",
              "Wobble",
              "Zarvox",
            ],
            w = (e) => e.filter((e) => !f.includes(e.name));
          function v() {
            return m().then((e) => {
              let t;
              const s = e.filter((e) => e.default);
              if ((1 === s.length && (t = s[0]), !t)) {
                const s = null == u ? void 0 : u.language;
                s && (t = e.find((e) => y(e.lang, s)));
              }
              if (!t) {
                const s = null == u ? void 0 : u.language.substring(0, 2);
                s && (t = e.find((e) => _(e.lang).includes(s)));
              }
              return t || (t = e[0]), t;
            });
          }
          const x = 1e4;
          function k(e) {
            const t = l.setTimeout(() => {
              d.speaking && (d.pause(), d.resume(), k(e));
            }, x);
            e(t);
          }
          function y(e, t) {
            return _(e) === _(t);
          }
          const _ = (e) => e.toLowerCase();
        },
        1606: (e, t) => {
          Object.defineProperty(t, "p", { value: !0 });
        },
        5214: (e, t, s) => {
          Object.defineProperty(t, "p", { value: !0 }),
            (t.BaseChatConnection = void 0);
          const i = s(8203),
            o = s(1668);
          t.BaseChatConnection = class {
            constructor(e) {
              (this.dispatcher = e), (this.state = i.ConnectionState.Closed);
            }
            getState() {
              return this.state;
            }
            isOpen() {
              return this.state === i.ConnectionState.Open;
            }
            isClosed() {
              return this.state === i.ConnectionState.Closed;
            }
            on(e, t) {
              this.dispatcher.bind(e, t);
            }
            off(e, t) {
              this.dispatcher.unbind(e, t);
            }
            setState(e) {
              (this.state = e), this.dispatcher.trigger(o.CoreEvent.State, e);
            }
          };
        },
        8203: (e, t) => {
          Object.defineProperty(t, "p", { value: !0 }),
            (t.ConnectionState = void 0);
          t.ConnectionState = { Connecting: 0, Open: 1, Closing: 2, Closed: 3 };
        },
        9170: (e, t) => {
          Object.defineProperty(t, "p", { value: !0 });
        },
        3747: function (e, t, s) {
          var i =
              (this && this.t) ||
              (Object.create
                ? function (e, t, s, i) {
                    void 0 === i && (i = s);
                    var o = Object.getOwnPropertyDescriptor(t, s);
                    (o &&
                      !("get" in o ? !t.p : o.writable || o.configurable)) ||
                      (o = {
                        enumerable: !0,
                        get: function () {
                          return t[s];
                        },
                      }),
                      Object.defineProperty(e, i, o);
                  }
                : function (e, t, s, i) {
                    void 0 === i && (i = s), (e[i] = t[s]);
                  }),
            o =
              (this && this.u) ||
              function (e, t) {
                for (var s in e)
                  "default" === s ||
                    Object.prototype.hasOwnProperty.call(t, s) ||
                    i(t, e, s);
              };
          Object.defineProperty(t, "p", { value: !0 }),
            o(s(5214), t),
            o(s(8203), t),
            o(s(9170), t);
        },
        5573: (e, t, s) => {
          Object.defineProperty(t, "p", { value: !0 }),
            (t.CoreError = t.CoreApiError = void 0);
          const i = s(6064),
            o = s(97),
            r = {
              ConnectionNone: "ConnectionNone",
              ConnectionExplicitClose: "ConnectionExplicitClose",
              MessageInvalid: "MessageInvalid",
              NetworkFailure: "NetworkFailure",
              NetworkOffline: "NetworkOffline",
              ProfileInvalid: "ProfileInvalid",
              TtsNotAvailable: "TtsNotAvailable",
              TTSNoWebAPI: "TTSNoWebAPI",
              SuggestionsEmptyRequest: "SuggestionsEmptyRequest",
              SuggestionsInvalidRequest: "SuggestionsInvalidRequest",
              SuggestionsTimeout: "SuggestionsTimeout",
              UploadBadFile: "UploadBadFile",
              UploadMaxSize: "UploadMaxSize",
              UploadNetworkFail: "UploadNetworkFail",
              UploadNotAvailable: "UploadNotAvailable",
              UploadUnauthorized: "UploadUnauthorized",
              UploadZeroSize: "UploadZeroSize",
              LocationNoAPI: "LocationNoAPI",
              LocationNotAvailable: "LocationNotAvailable",
              LocationTimeout: "LocationTimeout",
              LocationInvalid: "LocationInvalid",
            };
          t.CoreApiError = r;
          const a = Object.assign(
            Object.assign(Object.assign({}, r), i.AuthError),
            o.RecognitionError
          );
          t.CoreError = a;
        },
        8539: (e, t, s) => {
          Object.defineProperty(t, "p", { value: !0 }),
            (t.CoreEvent = t.ConnectionEvent = void 0);
          const i = s(97),
            o = s(6129),
            r = {
              Open: "open",
              Close: "close",
              Error: "error",
              Message: "message",
              MessageReceived: "message:received",
              MessageSent: "message:sent",
              State: "state",
            };
          t.ConnectionEvent = r;
          const a = Object.assign(
            Object.assign(
              Object.assign(
                Object.assign({}, i.SpeechSynthesisServiceEvent),
                i.SpeechRecognitionServiceEvent
              ),
              r
            ),
            o.ExecuteActionType
          );
          t.CoreEvent = a;
        },
        2239: (e, t) => {
          Object.defineProperty(t, "p", { value: !0 });
        },
        1668: function (e, t, s) {
          var i =
              (this && this.t) ||
              (Object.create
                ? function (e, t, s, i) {
                    void 0 === i && (i = s);
                    var o = Object.getOwnPropertyDescriptor(t, s);
                    (o &&
                      !("get" in o ? !t.p : o.writable || o.configurable)) ||
                      (o = {
                        enumerable: !0,
                        get: function () {
                          return t[s];
                        },
                      }),
                      Object.defineProperty(e, i, o);
                  }
                : function (e, t, s, i) {
                    void 0 === i && (i = s), (e[i] = t[s]);
                  }),
            o =
              (this && this.u) ||
              function (e, t) {
                for (var s in e)
                  "default" === s ||
                    Object.prototype.hasOwnProperty.call(t, s) ||
                    i(t, e, s);
              };
          Object.defineProperty(t, "p", { value: !0 }),
            o(s(5573), t),
            o(s(8539), t),
            o(s(2239), t);
        },
        6246: function (e, t, s) {
          var i =
              (this && this.t) ||
              (Object.create
                ? function (e, t, s, i) {
                    void 0 === i && (i = s);
                    var o = Object.getOwnPropertyDescriptor(t, s);
                    (o &&
                      !("get" in o ? !t.p : o.writable || o.configurable)) ||
                      (o = {
                        enumerable: !0,
                        get: function () {
                          return t[s];
                        },
                      }),
                      Object.defineProperty(e, i, o);
                  }
                : function (e, t, s, i) {
                    void 0 === i && (i = s), (e[i] = t[s]);
                  }),
            o =
              (this && this.u) ||
              function (e, t) {
                for (var s in e)
                  "default" === s ||
                    Object.prototype.hasOwnProperty.call(t, s) ||
                    i(t, e, s);
              };
          Object.defineProperty(t, "p", { value: !0 }),
            o(s(1606), t),
            o(s(3747), t),
            o(s(1668), t),
            o(s(6129), t),
            o(s(97), t),
            o(s(3743), t);
        },
        4834: function (e, t, s) {
          var i =
              (this && this.t) ||
              (Object.create
                ? function (e, t, s, i) {
                    void 0 === i && (i = s);
                    var o = Object.getOwnPropertyDescriptor(t, s);
                    (o &&
                      !("get" in o ? !t.p : o.writable || o.configurable)) ||
                      (o = {
                        enumerable: !0,
                        get: function () {
                          return t[s];
                        },
                      }),
                      Object.defineProperty(e, i, o);
                  }
                : function (e, t, s, i) {
                    void 0 === i && (i = s), (e[i] = t[s]);
                  }),
            o =
              (this && this.u) ||
              function (e, t) {
                for (var s in e)
                  "default" === s ||
                    Object.prototype.hasOwnProperty.call(t, s) ||
                    i(t, e, s);
              };
          Object.defineProperty(t, "p", { value: !0 }),
            o(s(2950), t),
            o(s(3506), t),
            o(s(9583), t);
        },
        2950: (e, t, s) => {
          Object.defineProperty(t, "p", { value: !0 }),
            (t.appendRequestId = void 0),
            (t.buildPostbackMessage = function (e) {
              var t;
              let s;
              s =
                "label" in e
                  ? e.label
                  : null !== (t = e.text) && void 0 !== t
                  ? t
                  : l;
              const i = {
                text: s,
                postback: e.postback,
                type: o.MessageType.Postback,
              };
              return a(i);
            }),
            (t.buildUserAttachmentMessage = function (e, t, s) {
              const i = (function (e) {
                  const t = e.split("/")[0].toLowerCase();
                  switch (t) {
                    case o.AttachmentType.Audio:
                    case o.AttachmentType.Image:
                    case o.AttachmentType.Video:
                      return t;
                    default:
                      return o.AttachmentType.File;
                  }
                })(e),
                r = {
                  type: o.MessageType.Attachment,
                  attachment: { type: i, url: t, title: s },
                };
              return a(r);
            }),
            (t.buildUserMessage = a),
            (t.buildUserTextMessage = function (e, t) {
              const s = a({ text: e, type: o.MessageType.Text });
              t &&
                (s.sdkMetadata
                  ? (s.sdkMetadata.speechId = t)
                  : (s.sdkMetadata = { speechId: t }));
              return s;
            }),
            (t.getUtteranceText = function (e, t) {
              const s = e.messagePayload;
              let r = l;
              if (s.voice)
                return x(
                  (function (e) {
                    var t;
                    const s = [
                      null === (t = e.voice) || void 0 === t ? void 0 : t.text,
                    ];
                    switch (e.type) {
                      case o.MessageType.Card:
                        s.push(
                          (function (e) {
                            if (!(null == e ? void 0 : e.length)) return l;
                            return e
                              .filter((e) => e.voice)
                              .map((e) => {
                                var t;
                                const s = [];
                                return (
                                  e.voice &&
                                    s.push(
                                      null === (t = e.voice) || void 0 === t
                                        ? void 0
                                        : t.text
                                    ),
                                  s.push(v(e.actions)),
                                  s.filter(Boolean).join(c)
                                );
                              })
                              .filter(Boolean)
                              .join(c);
                          })(e.cards)
                        );
                        break;
                      case o.MessageType.Form:
                      case o.MessageType.TableForm:
                        s.push(
                          (function (e) {
                            if (!(null == e ? void 0 : e.length)) return l;
                            return e
                              .filter(Boolean)
                              .map((e) => e.voice && e.voice.text)
                              .filter(Boolean)
                              .join(c);
                          })(e.forms)
                        );
                    }
                    return (
                      s.push(v(e.actions)),
                      s.push(v(e.globalActions)),
                      s.filter(Boolean).join(c)
                    );
                  })(e.messagePayload)
                );
              switch (s.type) {
                case o.MessageType.Attachment:
                  r = (function (e, t) {
                    return t[`${e.type}_${e.attachment.type}`];
                  })(s, t);
                  break;
                case o.MessageType.Card:
                  r = (function (e, t) {
                    const s = e.cards;
                    let i = l;
                    if (null == s ? void 0 : s.length) {
                      const e = t.card,
                        o = e ? (e.includes("{0}") ? e : `${e} {0}`) : l,
                        r = s.length > 1;
                      i = s
                        .filter((e) => e.title)
                        .map((e, t) => {
                          const s = [r ? o.replace("{0}", `${t + 1}`) : l];
                          return (
                            e.voice
                              ? s.push(e.voice.text)
                              : (s.push(e.title), s.push(e.description)),
                            s.push(u(e.actions)),
                            s.filter(Boolean).join(c)
                          );
                        })
                        .filter(Boolean)
                        .join(c);
                    }
                    return i;
                  })(s, t);
                  break;
                case o.MessageType.Location:
                  r = (function (e) {
                    const t = e.location;
                    return `${t.title ? `${t.title}${c}` : l}${t.latitude},${
                      t.longitude
                    }`;
                  })(s);
                  break;
                case o.MessageType.Text:
                case o.MessageType.TextStream:
                  r = s.text;
                  break;
                case o.MessageType.Table:
                  r = (function (e, t) {
                    return (
                      g(e.paginationInfo) +
                      e.rows
                        .filter((e) => {
                          var t;
                          return null === (t = null == e ? void 0 : e.fields) ||
                            void 0 === t
                            ? void 0
                            : t.length;
                        })
                        .map((e, s) => b(e, s, t))
                        .filter(Boolean)
                        .join(c)
                    );
                  })(s, t);
                  break;
                case o.MessageType.Form:
                  r = (function (e, t) {
                    return (
                      g(e.paginationInfo) +
                      e.forms
                        .filter((e) => e)
                        .map((e, s) => {
                          const i = (e.title ? `${e.title}: ` : l) + m(e, t);
                          return i
                            ? `${(t.itemIterator || l).replace(
                                "{0}",
                                `${s + 1}`
                              )}: ${i}`
                            : l;
                        })
                        .filter(Boolean)
                        .join(c)
                    );
                  })(s, t);
                  break;
                case o.MessageType.TableForm:
                  r = (function (e, t) {
                    return (
                      g(e.paginationInfo) +
                      e.rows
                        .filter((e) => {
                          var t;
                          return null === (t = null == e ? void 0 : e.fields) ||
                            void 0 === t
                            ? void 0
                            : t.length;
                        })
                        .map((s, i) => b(s, i, t) + c + m(e.forms[i], t))
                        .filter(Boolean)
                        .join(c)
                    );
                  })(s, t);
                  break;
                case o.MessageType.EditForm:
                  r = (function (e) {
                    var t, s;
                    return null !==
                      (s =
                        null !== (t = e.errorMessage) && void 0 !== t
                          ? t
                          : e.title) && void 0 !== s
                      ? s
                      : l;
                  })(s);
              }
              return (0, i.pipe)(
                (function (e, t) {
                  if (e.type === o.MessageType.EditForm && e.errorMessage)
                    return t;
                  const s = [];
                  return (
                    s.push(e.headerText),
                    s.push(t),
                    s.push(u(e.actions)),
                    s.push(e.footerText),
                    s.push(u(e.globalActions)),
                    s.filter(Boolean).join(c)
                  );
                })(s, r),
                x,
                k,
                w
              );
            });
          const i = s(6064),
            o = s(1683),
            r = s(9583);
          function a(e) {
            return n({ messagePayload: e });
          }
          const n = (e) =>
            e.requestId
              ? e
              : Object.assign(Object.assign({}, e), {
                  requestId: (0, i.generateID)({
                    prefix: "wsreq",
                    separator: "/",
                  }),
                });
          t.appendRequestId = n;
          const c = "; ",
            l = "",
            h = /<[^>]+>/g,
            d = /&#(\d+);/g,
            p = /&#[xX]([\da-fA-F]+);/g;
          function u(e) {
            return e
              ? e
                  .filter((e) => e.type !== o.ActionType.SubmitForm)
                  .map((e) => (e.voice ? e.voice.text : e.label || l))
                  .filter(Boolean)
                  .join(c)
              : l;
          }
          function g(e) {
            if (e && e.totalCount > e.rangeSize) {
              const t = e.status;
              return t ? t + c : l;
            }
            return l;
          }
          function m(e, t) {
            let s = u(e.actions);
            return (
              s && (s = c + s),
              (0, r.isFormEntityWithFields)(e)
                ? f(e.fields, t) + s
                : e.formRows
                    .filter((e) => (null == e ? void 0 : e.columns.length))
                    .map((e) =>
                      e.columns
                        .filter((e) => (null == e ? void 0 : e.fields.length))
                        .map((e) => f(e.fields, t))
                        .filter(Boolean)
                        .join(c)
                    )
                    .filter(Boolean)
                    .join(c) + s
            );
          }
          function b(e, t, s) {
            return `${(s.itemIterator || l).replace("{0}", `${t + 1}`)}: ${f(
              e.fields,
              s
            )}`;
          }
          function f(e, t) {
            return (null == e ? void 0 : e.length)
              ? e
                  .filter((e) => e)
                  .map((e) =>
                    (function (e, t) {
                      var s;
                      const i = null !== (s = e.label) && void 0 !== s ? s : l,
                        r = i ? `${i}: ` : l;
                      switch (e.displayType) {
                        case o.ReadOnlyDisplayType.Text:
                          return r + (e.value || l);
                        case o.ReadOnlyDisplayType.Link:
                          return r + (t.linkField || l).replace("{0}", i);
                        case o.ReadOnlyDisplayType.Action:
                          const s = e.action;
                          return r + (s.voice ? s.voice.text : s.label) || l;
                        default:
                          return i;
                      }
                    })(e, t)
                  )
                  .filter(Boolean)
                  .join(c)
              : l;
          }
          function w(e) {
            if (null == e ? void 0 : e.length) {
              const t = e
                .replace((0, i.resetRegex)(d), (e, t) => String.fromCharCode(t))
                .replace((0, i.resetRegex)(p), (e, t) => {
                  const s = Number.parseInt(`0x${t}`, 16);
                  return String.fromCharCode(s);
                });
              return (0, i.removeDisplayNoneAndDecode)(t).replace(
                (0, i.resetRegex)(h),
                l
              );
            }
            return l;
          }
          function v(e) {
            return (null == e ? void 0 : e.length)
              ? e
                  .filter((e) => e.type !== o.ActionType.SubmitForm)
                  .map((e) => e.voice && e.voice.text)
                  .filter(Boolean)
                  .join(c)
              : l;
          }
          const x = (e) => e.replaceAll(/([-.,?:;!]);/g, "$1"),
            k = (e) => e.replaceAll(/\r|\n|<br\/?>/gim, c);
        },
        3506: (e, t, s) => {
          Object.defineProperty(t, "p", { value: !0 }),
            (t.isReadOnlyField = p),
            (t.isValidMessage = function (e) {
              const t = !1;
              if (!(0, r.isMessage)(e)) return t;
              const s = e.messagePayload;
              if (!(0, r.isMessagePayload)(s)) return t;
              if (s.actions && !a(s.actions)) return t;
              if (s.globalActions && !a(s.globalActions)) return t;
              return Boolean(
                (function (e) {
                  switch (e.type) {
                    case o.MessageType.Attachment:
                      return (function (e) {
                        const t = e.attachment;
                        return !(!(null == t ? void 0 : t.type) || !t.url);
                      })(e);
                    case o.MessageType.Card:
                      return (function (e) {
                        let t = !1;
                        if (e.layout && e.cards.length) {
                          t = !0;
                          for (const t of e.cards) {
                            if (!t.title) return !1;
                            if (t.actions && !a(t.actions)) return !1;
                          }
                        }
                        return t;
                      })(e);
                    case o.MessageType.CloseSession:
                    case o.MessageType.SessionClosed:
                      return !0;
                    case o.MessageType.Location:
                      return (function (e) {
                        const t = e.location;
                        return !(
                          !(null == t ? void 0 : t.latitude) || !t.longitude
                        );
                      })(e);
                    case o.MessageType.Postback:
                      return (function (e) {
                        return !!e.postback;
                      })(e);
                    case o.MessageType.Text:
                      return (function (e) {
                        return !!e.text;
                      })(e);
                    case o.MessageType.TextStream:
                      return (function (e) {
                        return "string" == typeof e.text && !!e.streamState;
                      })(e);
                    case o.MessageType.Table:
                      return n(e);
                    case o.MessageType.Form:
                      return c(e);
                    case o.MessageType.TableForm:
                      return (function (e) {
                        return n(e) && c(e);
                      })(e);
                    case o.MessageType.EditForm:
                      return (function (e) {
                        const t = e.fields,
                          s = e.formColumns,
                          i = e.formRows;
                        return (
                          ((null == t ? void 0 : t.length) > 0 &&
                            t.every((e) =>
                              (function (e) {
                                const t = e.displayType,
                                  s = e;
                                return (
                                  t &&
                                  Object.values(o.DisplayType).includes(t) &&
                                  ((function (e) {
                                    const t = e.id;
                                    let s = !1;
                                    switch (e.displayType) {
                                      case o.DisplayType.SingleSelect:
                                      case o.DisplayType.MultiSelect:
                                        s = (function (e) {
                                          const t = e.layoutStyle,
                                            s = e.options;
                                          return (
                                            void 0 !== t &&
                                            "string" == typeof t &&
                                            t.length > 0 &&
                                            void 0 !== s &&
                                            s.length > 0 &&
                                            s.every((e) =>
                                              (function (e) {
                                                const t = e.label,
                                                  s = e.value;
                                                return (
                                                  void 0 !== t &&
                                                  "string" == typeof t &&
                                                  t.length > 0 &&
                                                  void 0 !== s
                                                );
                                              })(e)
                                            )
                                          );
                                        })(e);
                                        break;
                                      case o.DisplayType.Toggle:
                                        s = (function (e) {
                                          const t = e.valueOn,
                                            s = e.valueOff;
                                          return (
                                            void 0 !== t &&
                                            "string" == typeof t &&
                                            t.length > 0 &&
                                            void 0 !== s &&
                                            "string" == typeof s &&
                                            s.length > 0
                                          );
                                        })(e);
                                        break;
                                      case o.DisplayType.DatePicker:
                                      case o.DisplayType.TimePicker:
                                      case o.DisplayType.TextInput:
                                      case o.DisplayType.NumberInput:
                                        s = !0;
                                    }
                                    return s && void 0 !== t && t.length > 0;
                                  })(s) ||
                                    h(e))
                                );
                              })(e)
                            ) &&
                            "number" == typeof s &&
                            s > 0) ||
                          (null == i ? void 0 : i.length) > 0
                        );
                      })(e);
                    case o.MessageType.FormSubmission:
                      return (function (e) {
                        return !!e.submittedFields;
                      })(e);
                    case o.MessageType.InboundEvent:
                    case o.MessageType.OutboundEvent:
                      return (function (e) {
                        return (
                          !!e.eventType && !!e.eventVersion && !!e.eventData
                        );
                      })(e);
                    case o.MessageType.Status:
                      return (function (e) {
                        return e.type === o.MessageType.Status && "status" in e;
                      })(e);
                    case o.MessageType.Command:
                      return (function (e) {
                        return (
                          e.type === o.MessageType.Command && "command" in e
                        );
                      })(e);
                    case o.MessageType.UpdateApplicationContextCommand:
                      return (function (e) {
                        const { context: t, source: s } = e;
                        return (
                          void 0 !== t && "string" == typeof t && u.includes(s)
                        );
                      })(e);
                    case o.MessageType.GetDebugInfoCommand:
                      return (function (e) {
                        return void 0 !== e.infoTypes && e.infoTypes.length > 0;
                      })(e);
                  }
                  return !1;
                })(s)
              );
            }),
            (t.isValidProfileMessage = function (e) {
              return (0, i.isObject)(e) && (0, i.isObject)(e.profile);
            });
          const i = s(6064),
            o = s(1683),
            r = s(9583);
          function a(e) {
            for (const t of e)
              if (
                !t.type ||
                !(
                  (t.label && "string" == typeof t.label) ||
                  (t.imageUrl && "string" == typeof t.imageUrl)
                )
              )
                return !1;
            return !0;
          }
          function n(e) {
            const t = e.headings,
              s = e.rows;
            return (
              t &&
              t.length > 0 &&
              s &&
              s.length > 0 &&
              t.every((e) =>
                (function (e) {
                  const t = e.label;
                  return void 0 !== t && t.length > 0;
                })(e)
              ) &&
              s.every((e) => l(e))
            );
          }
          function c(e) {
            const t = e.forms;
            return (
              t &&
              t.length > 0 &&
              t.every(
                (e) =>
                  ((0, r.isFormEntityWithFields)(e) && l(e)) ||
                  (0, r.isFormEntityWithRows)(e)
              )
            );
          }
          function l(e) {
            const t = e.fields;
            return t && t.length > 0 && t.every((e) => h(e));
          }
          function h(e) {
            return !!e.displayType && p(e);
          }
          const d = Object.values(o.ReadOnlyDisplayType);
          function p(e) {
            return e && d.includes(e.displayType);
          }
          const u = Object.values(o.ContextSource);
        },
        9583: (e, t, s) => {
          Object.defineProperty(t, "p", { value: !0 }),
            (t.isSuggestionPayload =
              t.isSuggestionMessage =
              t.isStateMessage =
              t.isPostbackPayload =
              t.isPong =
              t.isPing =
              t.isMessagePayload =
              t.isMessage =
              t.isFormEntityWithRows =
              t.isFormEntityWithFields =
              t.isEventPayload =
              t.isEditFormPayloadWithRows =
              t.isEditFormPayloadWithFields =
                void 0);
          const i = s(6064),
            o = s(1683),
            r = (e) => (0, i.isObject)(e) && "messagePayload" in e;
          t.isMessage = r;
          const a = (e) => (0, i.isObject)(e) && "type" in e;
          t.isMessagePayload = a;
          t.isPostbackPayload = (e) =>
            a(e) && e.type === o.MessageType.Postback;
          t.isEventPayload = (e) =>
            a(e) &&
            (e.type === o.MessageType.InboundEvent ||
              e.type === o.MessageType.OutboundEvent);
          t.isFormEntityWithFields = (e) => void 0 !== e.fields;
          t.isFormEntityWithRows = (e) => void 0 !== e.formRows;
          t.isEditFormPayloadWithFields = (e) => void 0 !== e.fields;
          t.isEditFormPayloadWithRows = (e) => void 0 !== e.formRows;
          const n = (e) => a(e) && e.type === o.MessageType.Suggest;
          t.isSuggestionPayload = n;
          t.isSuggestionMessage = (e) => r(e) && n(e.messagePayload);
          const c = (e) => (0, i.isObject)(e) && "state" in e;
          t.isStateMessage = c;
          t.isPing = (e) => c(e) && e.state.type === o.StateType.Ping;
          t.isPong = (e) => c(e) && e.state.type === o.StateType.Pong;
        },
        6129: function (e, t, s) {
          var i =
              (this && this.t) ||
              (Object.create
                ? function (e, t, s, i) {
                    void 0 === i && (i = s);
                    var o = Object.getOwnPropertyDescriptor(t, s);
                    (o &&
                      !("get" in o ? !t.p : o.writable || o.configurable)) ||
                      (o = {
                        enumerable: !0,
                        get: function () {
                          return t[s];
                        },
                      }),
                      Object.defineProperty(e, i, o);
                  }
                : function (e, t, s, i) {
                    void 0 === i && (i = s), (e[i] = t[s]);
                  }),
            o =
              (this && this.u) ||
              function (e, t) {
                for (var s in e)
                  "default" === s ||
                    Object.prototype.hasOwnProperty.call(t, s) ||
                    i(t, e, s);
              };
          Object.defineProperty(t, "p", { value: !0 }),
            o(s(4834), t),
            o(s(1683), t);
        },
        3183: (e, t) => {
          Object.defineProperty(t, "p", { value: !0 }), (t.ActionType = void 0);
          t.ActionType = {
            Call: "call",
            Client: "client",
            Location: "location",
            Popup: "popup",
            Postback: "postback",
            Share: "share",
            SubmitForm: "submitForm",
            Url: "url",
            Webview: "webview",
          };
        },
        3123: (e, t) => {
          Object.defineProperty(t, "p", { value: !0 }),
            (t.ActionStyle = t.ActionDisplayType = void 0);
          t.ActionStyle = {
            Primary: "primary",
            Danger: "danger",
            Default: "default",
          };
          t.ActionDisplayType = {
            Button: "button",
            Icon: "icon",
            Link: "link",
          };
        },
        734: (e, t) => {
          Object.defineProperty(t, "p", { value: !0 });
        },
        5835: (e, t, s) => {
          Object.defineProperty(t, "p", { value: !0 }),
            (t.ClientActionType = void 0);
          const i = s(4018),
            o = Object.assign(Object.assign({}, i.ExecuteActionType), {
              COPY_MESSAGE_TEXT: "copyMessageText",
            });
          t.ClientActionType = o;
        },
        7662: function (e, t, s) {
          var i =
              (this && this.t) ||
              (Object.create
                ? function (e, t, s, i) {
                    void 0 === i && (i = s);
                    var o = Object.getOwnPropertyDescriptor(t, s);
                    (o &&
                      !("get" in o ? !t.p : o.writable || o.configurable)) ||
                      (o = {
                        enumerable: !0,
                        get: function () {
                          return t[s];
                        },
                      }),
                      Object.defineProperty(e, i, o);
                  }
                : function (e, t, s, i) {
                    void 0 === i && (i = s), (e[i] = t[s]);
                  }),
            o =
              (this && this.u) ||
              function (e, t) {
                for (var s in e)
                  "default" === s ||
                    Object.prototype.hasOwnProperty.call(t, s) ||
                    i(t, e, s);
              };
          Object.defineProperty(t, "p", { value: !0 }),
            o(s(3183), t),
            o(s(3123), t),
            o(s(734), t),
            o(s(5835), t),
            o(s(4539), t),
            o(s(4566), t),
            o(s(7833), t),
            o(s(7180), t),
            o(s(5507), t),
            o(s(1083), t),
            o(s(6805), t);
        },
        4539: (e, t) => {
          Object.defineProperty(t, "p", { value: !0 });
        },
        4566: (e, t) => {
          Object.defineProperty(t, "p", { value: !0 });
        },
        7833: (e, t) => {
          Object.defineProperty(t, "p", { value: !0 });
        },
        7180: (e, t) => {
          Object.defineProperty(t, "p", { value: !0 });
        },
        5507: (e, t) => {
          Object.defineProperty(t, "p", { value: !0 });
        },
        1083: (e, t) => {
          Object.defineProperty(t, "p", { value: !0 });
        },
        6805: (e, t) => {
          Object.defineProperty(t, "p", { value: !0 });
        },
        1683: function (e, t, s) {
          var i =
              (this && this.t) ||
              (Object.create
                ? function (e, t, s, i) {
                    void 0 === i && (i = s);
                    var o = Object.getOwnPropertyDescriptor(t, s);
                    (o &&
                      !("get" in o ? !t.p : o.writable || o.configurable)) ||
                      (o = {
                        enumerable: !0,
                        get: function () {
                          return t[s];
                        },
                      }),
                      Object.defineProperty(e, i, o);
                  }
                : function (e, t, s, i) {
                    void 0 === i && (i = s), (e[i] = t[s]);
                  }),
            o =
              (this && this.u) ||
              function (e, t) {
                for (var s in e)
                  "default" === s ||
                    Object.prototype.hasOwnProperty.call(t, s) ||
                    i(t, e, s);
              };
          Object.defineProperty(t, "p", { value: !0 }),
            o(s(7662), t),
            o(s(4771), t),
            o(s(4018), t),
            o(s(235), t),
            o(s(7446), t),
            o(s(8256), t),
            o(s(4620), t);
        },
        373: (e, t) => {
          Object.defineProperty(t, "p", { value: !0 });
        },
        2426: (e, t) => {
          Object.defineProperty(t, "p", { value: !0 });
        },
        3617: (e, t) => {
          Object.defineProperty(t, "p", { value: !0 });
        },
        6465: (e, t) => {
          Object.defineProperty(t, "p", { value: !0 });
        },
        8130: (e, t) => {
          Object.defineProperty(t, "p", { value: !0 });
        },
        6880: (e, t) => {
          Object.defineProperty(t, "p", { value: !0 });
        },
        8402: (e, t) => {
          Object.defineProperty(t, "p", { value: !0 });
        },
        8421: (e, t) => {
          Object.defineProperty(t, "p", { value: !0 });
        },
        3081: (e, t) => {
          Object.defineProperty(t, "p", { value: !0 });
        },
        4771: function (e, t, s) {
          var i =
              (this && this.t) ||
              (Object.create
                ? function (e, t, s, i) {
                    void 0 === i && (i = s);
                    var o = Object.getOwnPropertyDescriptor(t, s);
                    (o &&
                      !("get" in o ? !t.p : o.writable || o.configurable)) ||
                      (o = {
                        enumerable: !0,
                        get: function () {
                          return t[s];
                        },
                      }),
                      Object.defineProperty(e, i, o);
                  }
                : function (e, t, s, i) {
                    void 0 === i && (i = s), (e[i] = t[s]);
                  }),
            o =
              (this && this.u) ||
              function (e, t) {
                for (var s in e)
                  "default" === s ||
                    Object.prototype.hasOwnProperty.call(t, s) ||
                    i(t, e, s);
              };
          Object.defineProperty(t, "p", { value: !0 }),
            o(s(373), t),
            o(s(2426), t),
            o(s(3617), t),
            o(s(6465), t),
            o(s(8130), t),
            o(s(6880), t),
            o(s(8402), t),
            o(s(8421), t),
            o(s(3081), t),
            o(s(9131), t),
            o(s(9957), t),
            o(s(8673), t),
            o(s(6781), t),
            o(s(3166), t),
            o(s(4564), t),
            o(s(1259), t),
            o(s(2658), t),
            o(s(3568), t);
        },
        9131: (e, t) => {
          Object.defineProperty(t, "p", { value: !0 });
        },
        9957: (e, t) => {
          Object.defineProperty(t, "p", { value: !0 });
        },
        8673: (e, t) => {
          Object.defineProperty(t, "p", { value: !0 });
        },
        6781: (e, t) => {
          Object.defineProperty(t, "p", { value: !0 }),
            (t.pongMessage =
              t.pingMessage =
              t.TokenType =
              t.StateType =
                void 0),
            (t.StateType = {
              Auth: "auth",
              Ping: "ping",
              Pong: "pong",
              Token: "token",
            }),
            (t.TokenType = { JWT: "jwt" }),
            (t.pingMessage = { state: { type: t.StateType.Ping } }),
            (t.pongMessage = { state: { type: t.StateType.Pong } });
        },
        3166: (e, t) => {
          Object.defineProperty(t, "p", { value: !0 });
        },
        4564: (e, t) => {
          Object.defineProperty(t, "p", { value: !0 });
        },
        1259: (e, t) => {
          Object.defineProperty(t, "p", { value: !0 });
        },
        2658: (e, t) => {
          Object.defineProperty(t, "p", { value: !0 });
        },
        3568: (e, t) => {
          Object.defineProperty(t, "p", { value: !0 });
        },
        8799: (e, t) => {
          Object.defineProperty(t, "p", { value: !0 });
        },
        994: (e, t) => {
          Object.defineProperty(t, "p", { value: !0 }),
            (t.AttachmentType = void 0);
          t.AttachmentType = {
            Image: "image",
            Video: "video",
            Audio: "audio",
            File: "file",
          };
        },
        1168: (e, t) => {
          Object.defineProperty(t, "p", { value: !0 });
        },
        570: (e, t) => {
          Object.defineProperty(t, "p", { value: !0 });
        },
        5187: (e, t) => {
          Object.defineProperty(t, "p", { value: !0 });
        },
        673: (e, t) => {
          Object.defineProperty(t, "p", { value: !0 });
        },
        4426: function (e, t, s) {
          var i =
              (this && this.t) ||
              (Object.create
                ? function (e, t, s, i) {
                    void 0 === i && (i = s);
                    var o = Object.getOwnPropertyDescriptor(t, s);
                    (o &&
                      !("get" in o ? !t.p : o.writable || o.configurable)) ||
                      (o = {
                        enumerable: !0,
                        get: function () {
                          return t[s];
                        },
                      }),
                      Object.defineProperty(e, i, o);
                  }
                : function (e, t, s, i) {
                    void 0 === i && (i = s), (e[i] = t[s]);
                  }),
            o =
              (this && this.u) ||
              function (e, t) {
                for (var s in e)
                  "default" === s ||
                    Object.prototype.hasOwnProperty.call(t, s) ||
                    i(t, e, s);
              };
          Object.defineProperty(t, "p", { value: !0 }),
            o(s(994), t),
            o(s(1168), t),
            o(s(570), t),
            o(s(5187), t),
            o(s(673), t),
            o(s(8934), t);
        },
        8934: (e, t) => {
          Object.defineProperty(t, "p", { value: !0 });
        },
        7485: (e, t) => {
          Object.defineProperty(t, "p", { value: !0 }),
            (t.ReadOnlyDisplayType = t.DisplayType = void 0);
          const s = {
            Text: "text",
            Link: "link",
            Action: "action",
            Media: "media",
          };
          t.ReadOnlyDisplayType = s;
          const i = Object.assign(Object.assign({}, s), {
            SingleSelect: "singleSelect",
            MultiSelect: "multiSelect",
            DatePicker: "datePicker",
            TimePicker: "timePicker",
            Toggle: "toggle",
            TextInput: "textInput",
            NumberInput: "numberInput",
          });
          t.DisplayType = i;
        },
        3592: (e, t) => {
          Object.defineProperty(t, "p", { value: !0 });
        },
        6757: (e, t) => {
          Object.defineProperty(t, "p", { value: !0 });
        },
        125: (e, t) => {
          Object.defineProperty(t, "p", { value: !0 });
        },
        3965: (e, t) => {
          Object.defineProperty(t, "p", { value: !0 });
        },
        9359: (e, t) => {
          Object.defineProperty(t, "p", { value: !0 });
        },
        916: (e, t) => {
          Object.defineProperty(t, "p", { value: !0 });
        },
        3802: (e, t) => {
          Object.defineProperty(t, "p", { value: !0 }),
            (t.ExecuteActionType = void 0),
            (t.ExecuteActionType = {
              NAVIGATE: "navigate",
              QUERY: "query",
              UPDATE_FIELDS: "updateFields",
              CUSTOM: "custom",
            });
        },
        796: (e, t) => {
          Object.defineProperty(t, "p", { value: !0 });
        },
        2813: (e, t) => {
          Object.defineProperty(t, "p", { value: !0 });
        },
        1946: (e, t) => {
          Object.defineProperty(t, "p", { value: !0 }),
            (t.InfoType = void 0),
            (t.InfoType = {
              llmCalls: "llmCalls",
              semanticIndexCalls: "semanticIndexCalls",
              variables: "variables",
              applicationContext: "applicationContext",
              llmConversationHistory: "llmConversationHistory",
            });
        },
        4018: function (e, t, s) {
          var i =
              (this && this.t) ||
              (Object.create
                ? function (e, t, s, i) {
                    void 0 === i && (i = s);
                    var o = Object.getOwnPropertyDescriptor(t, s);
                    (o &&
                      !("get" in o ? !t.p : o.writable || o.configurable)) ||
                      (o = {
                        enumerable: !0,
                        get: function () {
                          return t[s];
                        },
                      }),
                      Object.defineProperty(e, i, o);
                  }
                : function (e, t, s, i) {
                    void 0 === i && (i = s), (e[i] = t[s]);
                  }),
            o =
              (this && this.u) ||
              function (e, t) {
                for (var s in e)
                  "default" === s ||
                    Object.prototype.hasOwnProperty.call(t, s) ||
                    i(t, e, s);
              };
          Object.defineProperty(t, "p", { value: !0 }),
            o(s(8799), t),
            o(s(4426), t),
            o(s(7485), t),
            o(s(3592), t),
            o(s(6757), t),
            o(s(125), t),
            o(s(3965), t),
            o(s(9359), t),
            o(s(916), t),
            o(s(3802), t),
            o(s(796), t),
            o(s(2813), t),
            o(s(1946), t),
            o(s(9985), t),
            o(s(2315), t),
            o(s(5638), t),
            o(s(2715), t),
            o(s(1962), t),
            o(s(6248), t),
            o(s(9274), t),
            o(s(3623), t),
            o(s(2240), t),
            o(s(8193), t),
            o(s(5290), t),
            o(s(431), t);
        },
        9985: (e, t) => {
          Object.defineProperty(t, "p", { value: !0 });
        },
        2315: (e, t) => {
          Object.defineProperty(t, "p", { value: !0 });
        },
        5638: (e, t) => {
          Object.defineProperty(t, "p", { value: !0 }),
            (t.MessageType = void 0);
          t.MessageType = {
            Attachment: "attachment",
            Card: "card",
            Location: "location",
            Postback: "postback",
            Raw: "raw",
            Suggest: "suggest",
            Text: "text",
            CloseSession: "closeSession",
            SessionClosed: "sessionClosed",
            Table: "table",
            Form: "form",
            TableForm: "tableForm",
            Status: "status",
            EditForm: "editForm",
            FormSubmission: "formSubmission",
            InboundEvent: "inboundEvent",
            OutboundEvent: "outboundEvent",
            TextStream: "textStream",
            Command: "command",
            Error: "error",
            UpdateApplicationContextCommand: "updateApplicationContextCommand",
            ExecuteApplicationActionCommand: "executeApplicationActionCommand",
            GetDebugInfoCommand: "getDebugInfoCommand",
          };
        },
        2715: (e, t) => {
          Object.defineProperty(t, "p", { value: !0 });
        },
        1962: (e, t) => {
          Object.defineProperty(t, "p", { value: !0 });
        },
        6248: (e, t) => {
          Object.defineProperty(t, "p", { value: !0 });
        },
        9274: (e, t) => {
          Object.defineProperty(t, "p", { value: !0 });
        },
        3623: (e, t) => {
          Object.defineProperty(t, "p", { value: !0 });
        },
        2240: (e, t) => {
          Object.defineProperty(t, "p", { value: !0 });
        },
        8193: (e, t) => {
          Object.defineProperty(t, "p", { value: !0 });
        },
        5290: (e, t) => {
          Object.defineProperty(t, "p", { value: !0 });
        },
        431: (e, t) => {
          Object.defineProperty(t, "p", { value: !0 }),
            (t.ContextSource = void 0),
            (t.ContextSource = {
              ChatWindow: "chatWindow",
              CompactChat: "compactChat",
              UIWidget: "UIWidget",
              Skill: "skill",
            });
        },
        235: (e, t) => {
          Object.defineProperty(t, "p", { value: !0 }),
            (t.SkillMessageSource = t.SenderType = void 0);
          t.SenderType = { Skill: "bot", User: "user" };
          t.SkillMessageSource = { Agent: "AGENT", Bot: "BOT" };
        },
        7446: (e, t) => {
          Object.defineProperty(t, "p", { value: !0 });
        },
        8256: (e, t) => {
          Object.defineProperty(t, "p", { value: !0 });
        },
        4620: (e, t) => {
          Object.defineProperty(t, "p", { value: !0 });
        },
        97: function (e, t, s) {
          var i =
              (this && this.t) ||
              (Object.create
                ? function (e, t, s, i) {
                    void 0 === i && (i = s);
                    var o = Object.getOwnPropertyDescriptor(t, s);
                    (o &&
                      !("get" in o ? !t.p : o.writable || o.configurable)) ||
                      (o = {
                        enumerable: !0,
                        get: function () {
                          return t[s];
                        },
                      }),
                      Object.defineProperty(e, i, o);
                  }
                : function (e, t, s, i) {
                    void 0 === i && (i = s), (e[i] = t[s]);
                  }),
            o =
              (this && this.u) ||
              function (e, t) {
                for (var s in e)
                  "default" === s ||
                    Object.prototype.hasOwnProperty.call(t, s) ||
                    i(t, e, s);
              };
          Object.defineProperty(t, "p", { value: !0 }),
            o(s(6143), t),
            o(s(6271), t),
            o(s(1866), t);
        },
        6143: (e, t) => {
          Object.defineProperty(t, "p", { value: !0 }),
            (t.RecognitionError = void 0);
          t.RecognitionError = {
            RecognitionNotAvailable: "RecognitionNotAvailable",
            RecognitionNotReady: "RecognitionNotReady",
            RecognitionNoAPI: "RecognitionNoAPI",
            RecognitionProcessingFailure: "RecognitionProcessingFailure",
            RecognitionTooMuchSpeechTimeout: "RecognitionTooMuchSpeechTimeout",
            RecognitionNoSpeechTimeout: "RecognitionNoSpeechTimeout",
            RecognitionMultipleConnection: "RecognitionMultipleConnection",
          };
        },
        6271: (e, t) => {
          Object.defineProperty(t, "p", { value: !0 }),
            (t.SpeechRecognitionServiceEvent = t.RecognitionLocale = void 0),
            (t.isValidLocale = function (e) {
              return i.includes(e);
            });
          const s = {
            DE_DE: "de-de",
            EN_AU: "en-au",
            EN_GB: "en-gb",
            EN_IN: "en-in",
            EN_US: "en-us",
            ES_ES: "es-es",
            FR_FR: "fr-fr",
            HI_IN: "hi-in",
            IT_IT: "it-it",
            PT_BR: "pt-br",
          };
          t.RecognitionLocale = s;
          t.SpeechRecognitionServiceEvent = {
            ASRStart: "asr:start",
            ASRStop: "asr:stop",
            ASRError: "asr:error",
            ASRResponse: "asr:response",
            ASRVisualData: "asr:visualdata",
          };
          const i = Object.keys(s).map((e) => s[e]);
        },
        1866: (e, t) => {
          Object.defineProperty(t, "p", { value: !0 }),
            (t.SpeechSynthesisServiceEvent = void 0);
          t.SpeechSynthesisServiceEvent = {
            TTSStart: "tts:start",
            TTSStop: "tts:stop",
          };
        },
        3743: (e, t, s) => {
          Object.defineProperty(t, "p", { value: !0 }),
            (t.getCurrentPosition = function () {
              if (!c) return a(o.CoreError.LocationNoAPI);
              return new Promise((e, t) => {
                c.getCurrentPosition(
                  (t) => {
                    const s = t.coords,
                      i = Object.assign(Object.assign({}, s), {
                        latitude: h(s.latitude),
                        longitude: h(s.longitude),
                      });
                    e(i);
                  },
                  (e) => {
                    let s;
                    switch (e.code) {
                      case e.POSITION_UNAVAILABLE:
                        s = o.CoreError.LocationNotAvailable;
                        break;
                      case e.TIMEOUT:
                        s = o.CoreError.LocationTimeout;
                        break;
                      case e.PERMISSION_DENIED:
                      default:
                        s = o.CoreError.LocationNoAPI;
                    }
                    t(r(s));
                  },
                  { enableHighAccuracy: !0, timeout: 5e3 }
                );
              });
            }),
            (t.getError = r),
            (t.getRejectPromiseError = a),
            (t.isValidLocation = function (e) {
              const { latitude: t, longitude: s } = e;
              return (
                (0, i.isNumber)(t) &&
                (0, i.isNumber)(s) &&
                (0, i.isBetween)(t, d, p) &&
                (0, i.isBetween)(s, u, g)
              );
            });
          const i = s(6064),
            o = s(1668);
          function r(e) {
            return Error(e);
          }
          function a(e) {
            return Promise.reject(r(e));
          }
          const n = navigator,
            c = null == n ? void 0 : n.geolocation,
            l = 1e5,
            h = (e) => Math.round(e * l) / l;
          const d = -90,
            p = 90,
            u = -180,
            g = 180;
        },
        1340: (e, t, s) => {
          Object.defineProperty(t, "p", { value: !0 }),
            (t.MAX_MB = t.CoreAttachmentService = void 0);
          const i = s(6064),
            o = s(6246);
          t.MAX_MB = 25;
          const r = "channelId",
            a = "userId";
          class n {
            static getInstance() {
              return this._ || (this._ = new n()), this._;
            }
            setParams(e) {
              (this.ae = e),
                e.tokenGenerator
                  ? ((this.V = i.AuthTokenService.getInstance()),
                    this.V.get().then((t) => {
                      (e[r] = t.getClaim(r)),
                        (e[a] = t.getClaim(a)),
                        (this.ne = c(e));
                    }))
                  : (this.ne = c(e));
            }
            upload(e, t) {
              return new Promise((s, r) => {
                const a = e.size;
                if (0 === a) return void r(Error(o.CoreError.UploadZeroSize));
                if (a > 26214400)
                  return void r(Error(o.CoreError.UploadMaxSize));
                const n = new XMLHttpRequest(),
                  c = () => r(Error(o.CoreError.UploadNetworkFail));
                (0, i.requestOn)(n, "readystatechange", () => {
                  if (4 === n.readyState)
                    switch (n.status) {
                      case 200: {
                        const e = JSON.parse(n.responseText);
                        s(e);
                        break;
                      }
                      case 413:
                        r(Error(o.CoreError.UploadMaxSize));
                        break;
                      case 415:
                        r(Error(o.CoreError.UploadBadFile));
                        break;
                      default:
                        c();
                    }
                }),
                  (0, i.requestOn)(n, "abort", c),
                  (0, i.requestOn)(n, "error", c),
                  (0, i.requestOn)(n, "timeout", c),
                  this.ae.tokenGenerator
                    ? this.V.get()
                        .then((s) =>
                          this.ce(n, { file: e, options: t, token: s.token })
                        )
                        .catch((e) => r(e))
                    : this.ce(n, { file: e, options: t });
              });
            }
            ce(e, { file: t, options: s, token: o }) {
              const r = new FormData();
              r.append("attachment", t, encodeURI(t.name)),
                e.open("POST", this.ne),
                (0, i.setRequestHeader)(
                  e,
                  "x-oda-meta-file-size",
                  t.size.toString()
                ),
                o &&
                  ((0, i.setRequestHeader)(e, "Authorization", `Bearer ${o}`),
                  this.ae.enableAttachmentSecurity &&
                    ((0, i.setRequestHeader)(
                      e,
                      "x-oda-meta-file-isProtected",
                      "True"
                    ),
                    (0, i.setRequestHeader)(
                      e,
                      "x-oda-meta-file-authType",
                      "ChannelClientAuth"
                    ))),
                e.send(r),
                s && s.onInitUpload && s.onInitUpload(e);
            }
          }
          function c(e) {
            const t = `http${e.isTLS ? "s" : ""}://`,
              { URI: s, channelId: o, userId: r } = e;
            return (0, i.buildURL)(
              t,
              s,
              { channelId: o, userId: r },
              "/chat/v1/attachments"
            );
          }
          t.CoreAttachmentService = n;
        },
        5383: function (e, t, s) {
          var i =
              (this && this.t) ||
              (Object.create
                ? function (e, t, s, i) {
                    void 0 === i && (i = s);
                    var o = Object.getOwnPropertyDescriptor(t, s);
                    (o &&
                      !("get" in o ? !t.p : o.writable || o.configurable)) ||
                      (o = {
                        enumerable: !0,
                        get: function () {
                          return t[s];
                        },
                      }),
                      Object.defineProperty(e, i, o);
                  }
                : function (e, t, s, i) {
                    void 0 === i && (i = s), (e[i] = t[s]);
                  }),
            o =
              (this && this.u) ||
              function (e, t) {
                for (var s in e)
                  "default" === s ||
                    Object.prototype.hasOwnProperty.call(t, s) ||
                    i(t, e, s);
              };
          Object.defineProperty(t, "p", { value: !0 }),
            o(s(1340), t),
            o(s(2712), t);
        },
        2712: (e, t) => {
          Object.defineProperty(t, "p", { value: !0 }),
            (t.FILE_TYPES = void 0),
            (t.FILE_TYPES = {
              AUDIO:
                ".aac, .amr, .m4a, .mp3, .mp4a, .mpga, .oga, .ogg, .wav, audio/*",
              FILE: ".7z, .csv, .doc, .docx, .eml, .ics, .key, .log, .msg, .neon, .numbers, .odt, .pages, .pdf, .pps, .ppsx, .ppt, .pptx, .rtf, .txt, .vcf, .xls, .xlsx, .xml, .yml, .yaml, application/msword, application/vnd.openxmlformats-officedocument.wordprocessingml.document",
              IMAGE:
                ".gif, .jfif, .jpeg, .jpg, .png, .svg, .tif, .tiff, .webp, image/*",
              VIDEO:
                ".3g2, .3gp, .avi, .m4v, .mov, .mp4, .mpeg, .mpg, .ogv, .qt, .webm, .wmv, video/*",
              ALL: "",
            }),
            (t.FILE_TYPES.ALL = `${t.FILE_TYPES.AUDIO},${t.FILE_TYPES.FILE},${t.FILE_TYPES.IMAGE},${t.FILE_TYPES.VIDEO}`);
        },
        468: (e, t, s) => {
          Object.defineProperty(t, "p", { value: !0 }),
            (t.ChatConnectionController = void 0);
          const i = s(6064),
            o = s(8147),
            r = s(3278);
          t.ChatConnectionController = class {
            constructor(e) {
              (this.le = e),
                e.isLongPoll &&
                  ((this.le.retryInterval = 2e3),
                  (this.le.retryMaxAttempts = 5)),
                (this.N = e.dispatcher),
                (this.he = new r.WebSocketConnection({
                  authService: e.authService,
                  url: (0, i.getWebSocketURL)(
                    e.baseURL,
                    e.searchParams,
                    e.isTLS,
                    e.channel
                  ),
                  retryInterval: e.retryInterval,
                  retryMaxAttempts: e.retryMaxAttempts,
                  dispatcher: this.N,
                })),
                (this.pe = this.he);
            }
            open() {
              return this.le.isLongPoll
                ? new Promise((e, t) => {
                    this.he
                      .open()
                      .then(() => {
                        this.ue(e);
                      })
                      .catch(() => {
                        this.ge(e, t);
                      });
                  })
                : this.pe.open();
            }
            close() {
              return clearTimeout(this.me), this.pe.close();
            }
            send(e) {
              return this.pe.send(e);
            }
            isOpen() {
              return this.pe.isOpen();
            }
            isClosed() {
              return this.pe.isClosed();
            }
            getState() {
              return this.pe.getState();
            }
            updateConnectionUrl(e) {
              var t;
              this.he.updateConnectionUrl(e),
                (this.le = Object.assign(Object.assign({}, this.le), {
                  baseURL: e.URI,
                  searchParams: { channelId: e.channelId, userId: e.userId },
                  isTLS: e.isTLS,
                  channel: e.channel,
                })),
                null === (t = this.be) ||
                  void 0 === t ||
                  t.updateConnectionUrl(e);
            }
            on(e, t) {
              this.N.bind(e, t);
            }
            off(e, t) {
              this.N.unbind(e, t);
            }
            setSuggestionPromise(e) {
              this.he.setSuggestionPromise(e);
            }
            ue(e) {
              var t;
              (this.pe = this.he),
                clearTimeout(this.me),
                (null === (t = this.be) || void 0 === t
                  ? void 0
                  : t.isOpen()) && this.be.close(),
                e();
            }
            ge(e, t) {
              (this.pe = this.fe()),
                this.pe
                  .open()
                  .then(() => {
                    (this.me = this.we()), e();
                  })
                  .catch((e) => {
                    t(e);
                  });
            }
            fe() {
              return (
                this.be ||
                  (this.be = new o.LongPollConnection({
                    url: (0, i.getLongPollURL)(
                      this.le.baseURL,
                      this.le.searchParams,
                      this.le.isTLS
                    ),
                    authService: this.le.authService,
                    dispatcher: this.N,
                  })),
                this.be
              );
            }
            we() {
              return window.setTimeout(() => {
                this.pe.close().then(() => {
                  this.open();
                });
              }, 3e5);
            }
          };
        },
        9694: (e, t, s) => {
          Object.defineProperty(t, "p", { value: !0 }),
            (t.ChatServerService = void 0);
          const i = s(6064),
            o = s(6246),
            r = s(468),
            a = s(7022);
          t.ChatServerService = class {
            constructor(e) {
              (this.ve = (e, t, s) => {
                let i = !1;
                return (
                  ((e && e !== this.U.URI) ||
                    (t && t !== this.U.channelId) ||
                    (s && s !== this.U.userId)) &&
                    (i = !0),
                  i
                );
              }),
                (this.xe = (e, t, s) =>
                  new Promise((i, o) => {
                    e && "string" == typeof e && e.length && (this.U.URI = e),
                      this.V
                        ? this.V.get()
                            .then((e) => {
                              (this.U.channelId = e.getClaim("channelId")),
                                (this.U.userId = e.getClaim("userId")),
                                this.B.updateConnectionUrl({
                                  URI: this.U.URI,
                                  channelId: this.U.channelId,
                                  userId: this.U.userId,
                                  isTLS: this.U.isTLS,
                                  channel: this.U.channel,
                                }),
                                i();
                            })
                            .catch((e) => o(e))
                        : ("string" == typeof t &&
                            t.length &&
                            (this.U.channelId = t),
                          "string" == typeof s &&
                            s.length &&
                            (this.U.userId = s),
                          this.B.updateConnectionUrl({
                            URI: this.U.URI,
                            channelId: this.U.channelId,
                            userId: this.U.userId,
                            isTLS: this.U.isTLS,
                            channel: this.U.channel,
                          }),
                          i());
                  })),
                (this.U = Object.assign(Object.assign({}, a.defaultConfig), e)),
                this.U.tokenGenerator &&
                  (this.V = i.AuthTokenService.getInstance()),
                (this.B = new r.ChatConnectionController({
                  baseURL: this.U.URI,
                  isLongPoll: this.U.isLongPoll,
                  isTLS: this.U.isTLS,
                  channel: this.U.channel,
                  retryInterval:
                    void 0 !== this.U.retryInterval && this.U.retryInterval >= 0
                      ? 1e3 * this.U.retryInterval
                      : 5e3,
                  retryMaxAttempts:
                    void 0 !== this.U.retryMaxAttempts &&
                    this.U.retryMaxAttempts >= 0
                      ? this.U.retryMaxAttempts
                      : 5,
                  searchParams: {
                    channelId: this.U.channelId,
                    userId: this.U.userId,
                  },
                  authService: this.V,
                  dispatcher: this.U.dispatcher,
                })),
                window.addEventListener("online", () => this.open()),
                window.addEventListener("offline", () => this.close());
            }
            open(e) {
              const { URI: t, userId: s, channelId: i } = e || {};
              if (this.isOpen()) {
                if (this.ve(t, i, s)) {
                  const e = t && this.U.URI !== t;
                  return !this.V || e
                    ? this.close().then(() =>
                        this.xe(t, i, s).then(() => this.B.open())
                      )
                    : Promise.resolve();
                }
                return Promise.resolve();
              }
              return this.xe(t, i, s).then(() => this.B.open());
            }
            close() {
              return this.B.close();
            }
            getState() {
              return this.B.getState();
            }
            isOpen() {
              return this.B.isOpen();
            }
            send(e, t, s) {
              let i;
              if (
                ((i =
                  "string" == typeof e
                    ? (0, o.buildUserTextMessage)(e, t)
                    : (0, o.isPostbackPayload)(e)
                    ? (0, o.buildPostbackMessage)(e)
                    : (0, o.isMessagePayload)(e)
                    ? (0, o.buildUserMessage)(e)
                    : e),
                !(0, o.isValidMessage)(i))
              )
                return (0, o.getRejectPromiseError)(o.CoreError.MessageInvalid);
              if (s) {
                const { sdkMetadata: e, threadId: t } = s;
                e && (i = this.ke(i, e)), t && (i.threadId = t);
              }
              return (
                (i.userId = this.U.userId),
                this.U.enableCancelResponse
                  ? (i = (0, o.appendRequestId)(i))
                  : delete i.requestId,
                this.B.send(i)
              );
            }
            updateUser(e, t) {
              let s = e;
              return (
                (null == t ? void 0 : t.sdkMetadata) &&
                  (s = this.ke(e, t.sdkMetadata)),
                this.B.send(s)
              );
            }
            sendDeviceToken(e, t) {
              const s = {
                state: {
                  type: "token",
                  deviceToken: e,
                  deviceType: t,
                  "store.undelivered.messages": !1,
                  "notify.undelivered.skill.messages": !1,
                },
              };
              return this.B.send(s);
            }
            cancelRequest(e) {
              console.debug("Requested to cancel", e);
            }
            getSuggestions(e) {
              const t = new i.Deferred();
              this.B.setSuggestionPromise(t);
              let s = {
                messagePayload: {
                  query: e,
                  threshold: 30,
                  type: o.MessageType.Suggest,
                },
              };
              return (
                this.U.enableCancelResponse && (s = (0, o.appendRequestId)(s)),
                this.B.send(s).catch(null == t ? void 0 : t.reject),
                setTimeout(() => {
                  null == t ||
                    t.reject((0, o.getError)(o.CoreError.SuggestionsTimeout));
                }, 1e4),
                null == t ? void 0 : t.promise
              );
            }
            on(e, t) {
              this.B.on(e, t);
            }
            off(e, t) {
              this.B.off(e, t);
            }
            ke(e, t) {
              return (
                t &&
                  (e.sdkMetadata = Object.assign(
                    Object.assign({}, e.sdkMetadata),
                    t
                  )),
                e
              );
            }
          };
        },
        7022: (e, t) => {
          Object.defineProperty(t, "p", { value: !0 }),
            (t.defaultConfig = void 0);
          t.defaultConfig = { isLongPoll: !1, isTLS: !0 };
        },
        782: function (e, t, s) {
          var i =
              (this && this.t) ||
              (Object.create
                ? function (e, t, s, i) {
                    void 0 === i && (i = s);
                    var o = Object.getOwnPropertyDescriptor(t, s);
                    (o &&
                      !("get" in o ? !t.p : o.writable || o.configurable)) ||
                      (o = {
                        enumerable: !0,
                        get: function () {
                          return t[s];
                        },
                      }),
                      Object.defineProperty(e, i, o);
                  }
                : function (e, t, s, i) {
                    void 0 === i && (i = s), (e[i] = t[s]);
                  }),
            o =
              (this && this.u) ||
              function (e, t) {
                for (var s in e)
                  "default" === s ||
                    Object.prototype.hasOwnProperty.call(t, s) ||
                    i(t, e, s);
              };
          Object.defineProperty(t, "p", { value: !0 }),
            o(s(468), t),
            o(s(9694), t),
            o(s(7022), t),
            o(s(8147), t),
            o(s(3278), t);
        },
        8147: (e, t, s) => {
          Object.defineProperty(t, "p", { value: !0 }),
            (t.LongPollConnection = void 0);
          const i = s(6246),
            o = s(6064);
          class r extends i.BaseChatConnection {
            constructor(e) {
              super(e.dispatcher),
                (this.url = e.url),
                (this.authService = e.authService);
            }
            open() {
              return this.isOpen()
                ? Promise.resolve()
                : navigator.onLine
                ? this.ye()
                : (0, i.getRejectPromiseError)(i.CoreError.NetworkOffline);
            }
            close() {
              return this.isClosed() ? Promise.resolve() : this._e();
            }
            send(e) {
              return new Promise((t, s) => {
                if (this.isOpen()) {
                  const r = new XMLHttpRequest();
                  r.open("POST", this.url),
                    (0, o.setRequestHeader)(
                      r,
                      "Content-Type",
                      "application/json"
                    ),
                    (r.onload = () => {
                      r.status >= 200 && r.status < 300 ? t(e) : s(r.response);
                    }),
                    (r.onerror = () => {
                      s((0, i.getError)(i.CoreError.NetworkFailure));
                    }),
                    this.Oe(r, JSON.stringify(e)).catch(s);
                } else s((0, i.getError)(i.CoreError.ConnectionNone));
              });
            }
            updateConnectionUrl(e) {
              this.url = (0, o.getLongPollURL)(
                e.URI,
                { channelId: e.channelId, userId: e.userId },
                e.isTLS
              );
            }
            ye() {
              return (
                this.Me ||
                  ((this.Me = new o.Deferred()),
                  this.setState(i.ConnectionState.Connecting),
                  this.je()
                    .then(() => {
                      this.R(), this.ze();
                    })
                    .catch((e) => {
                      this.Me && (this.Me.reject(e), (this.Me = null)),
                        this.G();
                    })),
                this.Me.promise
              );
            }
            _e() {
              return (
                this.$e ||
                  (this.Ie.abort(),
                  (this.$e = new o.Deferred()),
                  this.setState(i.ConnectionState.Closing),
                  setTimeout(() => {
                    this.G();
                  }, 100)),
                this.$e.promise
              );
            }
            je() {
              return new Promise((e, t) => {
                const s = new XMLHttpRequest();
                s.open("POST", this.url),
                  (0, o.setRequestHeader)(
                    s,
                    "Content-Type",
                    "application/json"
                  ),
                  (s.onload = () => {
                    s.status >= 200 && s.status < 300 ? e() : t(s.response);
                  }),
                  (s.onerror = () => {
                    t((0, i.getError)(i.CoreError.NetworkFailure));
                  }),
                  this.Oe(s, JSON.stringify(i.pingMessage)).catch((e) => {
                    t(e);
                  });
              });
            }
            ze() {
              let e = 0;
              this.isOpen() &&
                ((this.Ie = new XMLHttpRequest()),
                this.Ie.open("GET", this.url),
                (this.Ie.onload = () => {
                  (e = 0),
                    this.Ie.status &&
                      200 === this.Ie.status &&
                      this.Ce(this.Ie.responseText),
                    this.ze();
                }),
                (this.Ie.onerror = () => {
                  5 === e ? this.close() : (e++, this.ze());
                }),
                this.Oe(this.Ie));
            }
            Oe(e, t) {
              return this.authService
                ? new Promise((s, i) => {
                    var r;
                    null === (r = this.authService) ||
                      void 0 === r ||
                      r
                        .get()
                        .then((i) => {
                          (0, o.setRequestHeader)(
                            e,
                            "Authorization",
                            `Bearer ${i.token}`
                          ),
                            e.send(t),
                            s();
                        })
                        .catch((e) => {
                          i(e);
                        });
                  })
                : (e.send(t), Promise.resolve());
            }
            Ce(e) {
              try {
                JSON.parse(e).forEach((e) => {
                  this.q(JSON.parse(e));
                });
              } catch (e) {
                this.J(e);
              }
            }
            R() {
              this.Me && (this.Me.resolve(), (this.Me = null)),
                this.$e && (this.$e.reject(), (this.$e = null)),
                this.setState(i.ConnectionState.Open),
                this.dispatcher.trigger(i.CoreEvent.Open);
            }
            G() {
              this.$e && (this.$e.resolve(), (this.$e = null)),
                (this.Me = null),
                this.setState(i.ConnectionState.Closed),
                this.dispatcher.trigger(i.CoreEvent.Close);
            }
            q(e) {
              this.dispatcher.trigger(i.CoreEvent.Message, e),
                this.dispatcher.trigger(i.CoreEvent.MessageReceived, e);
              const t = e.messagePayload;
              if (t.type === i.MessageType.ExecuteApplicationActionCommand) {
                const e = t;
                this.dispatcher.trigger(e.actionType, e);
              }
            }
            J(e) {
              this.dispatcher.trigger(i.CoreEvent.Error, e);
            }
          }
          t.LongPollConnection = r;
        },
        3278: (e, t, s) => {
          Object.defineProperty(t, "p", { value: !0 }),
            (t.WebSocketConnection = void 0);
          const i = s(6246),
            o = s(6064),
            r = Promise,
            a = 3e6,
            n = window;
          class c extends i.BaseChatConnection {
            constructor(e) {
              super(e.dispatcher),
                (this.Se = !1),
                (this.Te = !1),
                (this.Ae = !1),
                (this.Ee = 0),
                (this.Pe = !1),
                (this.Le = null),
                (this.url = e.url),
                (this.authService = e.authService),
                (this.Fe = e.retryInterval),
                (this.Ne = e.retryMaxAttempts);
            }
            open() {
              return this.isOpen()
                ? r.resolve()
                : navigator.onLine
                ? this.ye()
                : (0, i.getRejectPromiseError)(i.CoreError.NetworkOffline);
            }
            close() {
              return (
                (this.Se = !0),
                clearTimeout(this.Re),
                this.isClosed() ? r.resolve() : this._e()
              );
            }
            send(e) {
              return new r((t, s) => {
                if (this.Le && this.isOpen()) {
                  this.Ae = !0;
                  try {
                    this.Le.send(JSON.stringify(e)),
                      t(e),
                      (0, i.isPing)(e) ||
                        (this.dispatcher.trigger(i.CoreEvent.Message, e),
                        this.dispatcher.trigger(i.CoreEvent.MessageSent, e));
                  } catch (e) {
                    s((0, i.getError)(i.CoreError.NetworkFailure));
                  }
                } else s((0, i.getError)(i.CoreError.ConnectionNone));
              });
            }
            updateConnectionUrl(e) {
              this.url = (0, o.getWebSocketURL)(
                e.URI,
                { channelId: e.channelId, userId: e.userId },
                e.isTLS,
                e.channel
              );
            }
            setSuggestionPromise(e) {
              this.De = e;
            }
            ye() {
              return (
                this.Me ||
                  ((this.Me = new o.Deferred()),
                  this.setState(i.ConnectionState.Connecting),
                  this.je()),
                this.Me.promise
              );
            }
            _e() {
              var e;
              return (
                this.$e ||
                  (null === (e = this.Le) || void 0 === e || e.close(),
                  (this.$e = new o.Deferred()),
                  this.setState(i.ConnectionState.Closing)),
                this.$e.promise
              );
            }
            je() {
              try {
                (this.Le = new WebSocket(this.url)),
                  (this.Le.onopen = () => {
                    this.setState(i.ConnectionState.Open),
                      (this.Pe = !1),
                      this.authService ? this.He() : this.R();
                  }),
                  (this.Le.onclose = (e) => {
                    this.Ue(),
                      this.Se
                        ? (this.setState(i.ConnectionState.Closed),
                          this.Ve(i.CoreError.ConnectionExplicitClose, e))
                        : this.authService && !this.Ae && 1006 !== e.code
                        ? (this.setState(i.ConnectionState.Closed),
                          this.Ve(i.CoreError.AuthExpiredToken, e))
                        : this.Pe || this.Be(e);
                  }),
                  (this.Le.onmessage = this.q.bind(this)),
                  (this.Le.onerror = () => {
                    this.Be(), (this.Pe = !0), this.J.bind(this);
                  });
              } catch (e) {
                this.Be();
              }
            }
            Be(e) {
              this.setState(i.ConnectionState.Connecting),
                this.Ee < this.Ne
                  ? (this.Ee++,
                    (this.Re = n.setTimeout(this.je.bind(this), this.Fe)))
                  : (this.setState(i.ConnectionState.Closed),
                    this.Ve(i.CoreError.NetworkFailure, e));
            }
            Ve(e, t) {
              this.Me && this.Me.reject((0, i.getError)(e)), this.G(t);
            }
            He() {
              var e;
              (this.Ae = !1),
                null === (e = this.authService) ||
                  void 0 === e ||
                  e
                    .get()
                    .then((e) => {
                      this.send(
                        (function (e) {
                          return {
                            state: {
                              token: e,
                              tokenType: i.TokenType.JWT,
                              type: i.StateType.Auth,
                            },
                          };
                        })(e.token)
                      ).then(() => {
                        setTimeout(() => (this.Ae = !0), 1e4), this.R();
                      });
                    })
                    .catch((e) => {
                      var t;
                      null === (t = this.Me) || void 0 === t || t.reject(e),
                        this.close();
                    });
            }
            R() {
              var e;
              this.Ue(),
                clearTimeout(this.Re),
                (this.We = this.Ze()),
                (this.Ge =
                  ((e = this),
                  n.setTimeout(() => {
                    l(e);
                  }, a))),
                (this.Ee = 0),
                (this.Se = !1),
                (this.Ae = !1),
                this.Me && (this.Me.resolve(), (this.Me = null)),
                this.$e && (this.$e.reject(), (this.$e = null)),
                this.dispatcher.trigger(i.CoreEvent.Open);
            }
            G(e) {
              (this.Ee = 0),
                (this.Se = !1),
                (this.Ae = !1),
                this.$e && (this.$e.resolve(), (this.$e = null)),
                (this.Me = null),
                this.dispatcher.trigger(i.CoreEvent.Close, e);
            }
            q(e) {
              try {
                const t = JSON.parse(e.data);
                if ((0, i.isPong)(t)) this.Te = !0;
                else if (t.suggestions && this.De)
                  this.De.resolve(t.suggestions);
                else {
                  this.dispatcher.trigger(i.CoreEvent.Message, t),
                    this.dispatcher.trigger(i.CoreEvent.MessageReceived, t);
                  const e = t.messagePayload;
                  if (
                    e.type === i.MessageType.ExecuteApplicationActionCommand
                  ) {
                    const t = e;
                    this.dispatcher.trigger(t.actionType, t);
                  }
                }
              } catch (e) {
                this.J(e);
              }
            }
            J(e) {
              this.dispatcher.trigger(i.CoreEvent.Error, e);
            }
            Ze() {
              return n.setInterval(() => {
                this.send(i.pingMessage).then(() => {
                  (this.Te = !1),
                    (this.qe = n.setTimeout(() => {
                      this.isOpen() && !this.Te && l(this);
                    }, 1e4));
                });
              }, 3e4);
            }
            Ue() {
              clearTimeout(this.Ge),
                clearInterval(this.We),
                clearTimeout(this.qe);
            }
          }
          function l(e) {
            e.close().then(() => e.open());
          }
          t.WebSocketConnection = c;
        },
        4261: (e, t, s) => {
          t.c = t.b = t.a = void 0;
          const i = s(6246);
          Object.defineProperty(t, "a", {
            enumerable: !0,
            get: function () {
              return i.RecognitionLocale;
            },
          }),
            Object.defineProperty(t, "b", {
              enumerable: !0,
              get: function () {
                return i.SpeechSynthesisServiceEvent;
              },
            });
          const o = s(6064),
            r = s(8557),
            a = s(1794),
            n = s(6637),
            c = s(5383);
          const l = s(782),
            h = { oracle: "oracle", platform: "platform" };
          const d = h.oracle;
          class p {
            constructor(e) {
              var t, s;
              (this.U = e),
                (this.Ye = null),
                (this.Je = new Map()),
                (null !== (t = (s = this.U).dispatcher) && void 0 !== t) ||
                  (s.dispatcher = (0, o.generateEventDispatcher)()),
                (this.U.URI = (0, o.stripHTTP)(e.URI)),
                this.Ke(e),
                (this.Xe = new l.ChatServerService(e)),
                this.Xe.on(i.CoreEvent.Open, () => {
                  var e, t;
                  const s = this.U;
                  null === (e = this.Qe) || void 0 === e || e.setParams(s),
                    null === (t = this.et) || void 0 === t || t.setConfig(s);
                });
            }
            connect(e) {
              return (
                e &&
                  (e.URI && (e.URI = (0, o.stripHTTP)(e.URI)),
                  (this.U = Object.assign(Object.assign({}, this.U), e))),
                this.Xe.open(e)
              );
            }
            disconnect() {
              const e = this.Xe.close();
              return e.then(this.tt.bind(this)), e;
            }
            getState() {
              return this.Xe.getState();
            }
            isConnected() {
              return this.Xe.isOpen();
            }
            sendMessage(e, t) {
              if (!e)
                return (0, i.getRejectPromiseError)(i.CoreError.MessageInvalid);
              let s = "",
                o = "";
              if ("string" == typeof e) o = e;
              else if ((0, i.isMessagePayload)(e)) {
                o = e.text;
              }
              return (
                this.Ye && this.Ye.text === o && (s = this.Ye.requestId),
                (this.Ye = null),
                this.Xe.send(
                  e,
                  s,
                  Object.assign(Object.assign({}, t), {
                    threadId: (null == t ? void 0 : t.threadId) || this.st,
                  })
                )
              );
            }
            updateChatContext(e, t, s, o) {
              return this.sendMessage(
                {
                  messagePayload: Object.assign(
                    {
                      type: i.MessageType.UpdateApplicationContextCommand,
                      source: i.ContextSource.ChatWindow,
                      context: e,
                    },
                    t
                  ),
                },
                { sdkMetadata: o, threadId: s }
              );
            }
            updateUser(e, t) {
              return (0, i.isValidProfileMessage)(e)
                ? this.Xe.updateUser(
                    e,
                    Object.assign(Object.assign({}, t), { threadId: this.st })
                  )
                : (0, i.getRejectPromiseError)(i.CoreError.ProfileInvalid);
            }
            sendDeviceToken(e, t) {
              return this.Xe.sendDeviceToken(e, t);
            }
            setCurrentThreadId(e) {
              this.st = e;
            }
            uploadAttachment(e, t) {
              return this.isConnected()
                ? this.Qe
                  ? this.Qe.upload(e, t).then((e) =>
                      (0, i.buildUserAttachmentMessage)(
                        e.type,
                        e.url,
                        e.fileName
                      )
                    )
                  : (0, i.getRejectPromiseError)(i.CoreError.UploadNotAvailable)
                : (0, i.getRejectPromiseError)(i.CoreError.ConnectionNone);
            }
            sendAttachment(e, t) {
              return this.uploadAttachment(e, t).then((e) =>
                this.Xe.send(e, "", {
                  sdkMetadata: null == t ? void 0 : t.sdkMetadata,
                })
              );
            }
            sendLocation(e) {
              return this.isConnected()
                ? e
                  ? (0, i.isValidLocation)(e)
                    ? this.Xe.send({
                        messagePayload: {
                          type: i.MessageType.Location,
                          location: e,
                        },
                      })
                    : (0, i.getRejectPromiseError)(i.CoreError.LocationInvalid)
                  : (0, i.getCurrentPosition)().then((e) =>
                      this.Xe.send({
                        messagePayload: {
                          type: i.MessageType.Location,
                          location: {
                            latitude: e.latitude,
                            longitude: e.longitude,
                          },
                        },
                      })
                    )
                : (0, i.getRejectPromiseError)(i.CoreError.ConnectionNone);
            }
            sendUserTypingStatus(e, t) {
              return this.sendMessage(
                (0, i.buildUserMessage)({
                  partyType: "user",
                  source: "sdk",
                  status: e,
                  type: i.MessageType.Status,
                  text: t,
                })
              );
            }
            cancelRequest(e) {
              this.Xe.cancelRequest(e);
            }
            getSuggestions(e) {
              return e
                ? "string" != typeof e
                  ? (0, i.getRejectPromiseError)(
                      i.CoreError.SuggestionsInvalidRequest
                    )
                  : this.Xe.getSuggestions(e)
                : (0, i.getRejectPromiseError)(
                    i.CoreError.SuggestionsEmptyRequest
                  );
            }
            destroy() {
              this.disconnect();
              for (const e in this) this[e] && delete this[e];
            }
            setTTSService(e) {
              this.ot = "string" == typeof e ? this.rt(e) : e;
            }
            getTTSService() {
              return this.ot;
            }
            getTTSVoices() {
              return this.ot
                ? this.ot.getVoices()
                : (0, i.getRejectPromiseError)(i.CoreError.TtsNotAvailable);
            }
            setTTSVoice(e) {
              return this.ot
                ? this.ot.setVoice(e)
                : (0, i.getRejectPromiseError)(i.CoreError.TtsNotAvailable);
            }
            getTTSVoice() {
              if (this.ot) return this.ot.getVoice();
              throw (0, i.getError)(i.CoreError.TtsNotAvailable);
            }
            speakTTS(e, t) {
              if (this.ot) {
                let s;
                if ("string" == typeof e) s = e;
                else {
                  if (!(0, i.isValidMessage)(e)) return;
                  s = (0, i.getUtteranceText)(e, t);
                }
                this.ot.speak(s);
              }
            }
            cancelTTS() {
              this.ot && this.ot.cancel();
            }
            startRecognition(e) {
              if (this.et) {
                if (this.isConnected()) {
                  const t = (t) => {
                      "final" === t.type && (this.Ye = t),
                        null == e || e.onRecognitionText(t);
                    },
                    s = (t) => {
                      var s;
                      null === (s = null == e ? void 0 : e.onVisualData) ||
                        void 0 === s ||
                        s.call(e, t);
                    },
                    o = () => {
                      this.off(i.CoreEvent.ASRResponse, t),
                        this.off(i.CoreEvent.ASRVisualData, s),
                        this.off(i.CoreEvent.ASRStop, o);
                    };
                  return (
                    this.on(i.CoreEvent.ASRResponse, t),
                    this.on(i.CoreEvent.ASRVisualData, s),
                    this.on(i.CoreEvent.ASRStop, o),
                    this.et.startRecognition()
                  );
                }
                return (0, i.getRejectPromiseError)(i.CoreError.ConnectionNone);
              }
              return (0, i.getRejectPromiseError)(
                i.CoreError.RecognitionNotAvailable
              );
            }
            stopRecognition() {
              return this.et
                ? this.et.stopRecognition()
                : (0, i.getRejectPromiseError)(
                    i.CoreError.RecognitionNotAvailable
                  );
            }
            setRecognitionLocale(e) {
              if (e && "string" == typeof e && this.et) {
                const t = e.toLowerCase();
                this.et.setLocale(t);
              }
            }
            on(e, t) {
              var s;
              switch (e) {
                case i.SpeechSynthesisServiceEvent.TTSStart:
                case i.SpeechSynthesisServiceEvent.TTSStop:
                  null === (s = this.ot) || void 0 === s || s.on(e, t);
                  break;
                default:
                  this.Xe.on(e, t);
              }
            }
            off(e, t) {
              var s;
              switch (e) {
                case i.SpeechSynthesisServiceEvent.TTSStart:
                case i.SpeechSynthesisServiceEvent.TTSStop:
                  null === (s = this.ot) || void 0 === s || s.off(e, t);
                  break;
                default:
                  this.Xe.off(e, t);
              }
            }
            getAuthToken() {
              var e;
              return null === (e = this.V) || void 0 === e ? void 0 : e.get();
            }
            tt() {}
            Ke(e) {
              (e.URI = e.URI.replace(
                /^https?:\/\//gi,
                (e) => (console.warn(`Please remove "${e}" from URI.`), "")
              )),
                this.nt(e),
                this.ct(e),
                this.lt(e),
                (this.et = r.CoreSpeechRecognitionService.getInstance());
            }
            nt(e) {
              e.enableAttachment &&
                (this.Qe = c.CoreAttachmentService.getInstance());
            }
            ct(e) {
              e.tokenGenerator &&
                ((this.V = o.AuthTokenService.getInstance()),
                this.V.setFetch(e.tokenGenerator));
            }
            lt(e) {
              if (e.isTTS) {
                let t;
                const s = e.TTSService;
                (t = s ? ("string" == typeof s ? this.rt(s) : s) : this.rt(d)),
                  (this.ot = t);
              }
            }
            rt(e) {
              const t = this.Je.get(e);
              if (t) return t;
              let s;
              try {
                e === h.oracle
                  ? (s = new n.OracleTTSService(this.U))
                  : e === h.platform &&
                    (s = new a.CoreSpeechSynthesisService()),
                  this.Je.set(e, s);
              } catch (e) {
                console.log(e);
              }
              return s;
            }
          }
          (t.c = p), (p.TTS = h);
        },
        6637: function (e, t, s) {
          var i =
            (this && this.v) ||
            function (e, t, s, i) {
              return new (s || (s = Promise))(function (o, r) {
                function a(e) {
                  try {
                    c(i.next(e));
                  } catch (e) {
                    r(e);
                  }
                }
                function n(e) {
                  try {
                    c(i.throw(e));
                  } catch (e) {
                    r(e);
                  }
                }
                function c(e) {
                  var t;
                  e.done
                    ? o(e.value)
                    : ((t = e.value),
                      t instanceof s
                        ? t
                        : new s(function (e) {
                            e(t);
                          })).then(a, n);
                }
                c((i = i.apply(e, t || [])).next());
              });
            };
          Object.defineProperty(t, "p", { value: !0 }),
            (t.OracleTTSService = void 0);
          const o = s(6064),
            r = s(6246),
            a = s(4076),
            n = "speak",
            c = "channelId",
            l = "userId",
            h = /<[\w]+/g,
            d = n;
          t.OracleTTSService = class {
            constructor(e) {
              (this.ht = ""),
                (this.dt = []),
                (this.ut = !1),
                (this.$ = !1),
                (this.gt = new AbortController()),
                (this.N = (0, o.generateEventDispatcher)()),
                (this.U = (e) => {
                  (this.ae = e),
                    (this.ht = `${e.URI}/tts/`),
                    e.tokenGenerator &&
                      (this.V = o.AuthTokenService.getInstance());
                }),
                (this.bt = (e) =>
                  i(this, void 0, void 0, function* () {
                    let t = e;
                    e.match(h) && (t = `<${d}>${e}</${d}>`);
                    const s = Object.assign(
                        { text: encodeURIComponent(t), stream: "chunked" },
                        this.oe && { voice: this.oe.name }
                      ),
                      i = yield this.ft(n, s);
                    return this.wt(i);
                  })),
                (this.ft = (e, ...t) =>
                  i(this, [e, ...t], void 0, function* (e, t = {}) {
                    const s = this.ae;
                    if (s)
                      if (s.tokenGenerator) {
                        const e = yield this.V.get();
                        (t[c] = e.getClaim(c)), (t[l] = e.getClaim(l));
                      } else (t[c] = s.channelId), (t[l] = s.userId);
                    return (0, o.buildURL)("https://", this.ht, t, e);
                  })),
                (this.wt = (e, ...t) =>
                  i(this, [e, ...t], void 0, function* (e, t = !0) {
                    var s;
                    const i = t ? this.gt.signal : void 0,
                      o = {};
                    if (
                      null === (s = this.ae) || void 0 === s
                        ? void 0
                        : s.tokenGenerator
                    ) {
                      const e = yield this.V.get();
                      o.Authorization = `Bearer ${e.token}`;
                    }
                    return fetch(e, { signal: i, headers: o });
                  })),
                (this.vt = (e) => {
                  if (null == e ? void 0 : e.body) {
                    const t = e.body.getReader();
                    this.xt(),
                      this.$ ||
                        ((this.$ = !0),
                        this.N.trigger(r.SpeechSynthesisServiceEvent.TTSStart)),
                      this.kt(t);
                  }
                }),
                (this.kt = (e) =>
                  i(this, void 0, void 0, function* () {
                    try {
                      const { done: t, value: s } = yield e.read();
                      if (t) return void this.yt.next();
                      let i = s.buffer;
                      if (
                        (this.ut ||
                          ((this.ut = !0), this._t.config(m(i)), (i = g(i))),
                        void 0 !== this.Ot)
                      ) {
                        const e = new Uint8Array(i),
                          t = new Uint8Array(e.length + 1);
                        (t[0] = this.Ot),
                          t.set(e, 1),
                          (i = u(t)),
                          (this.Ot = void 0);
                      }
                      if (i.byteLength % 2) {
                        const e = new Uint8Array(i),
                          t = new Uint8Array(e.length - 1);
                        t.set(e.slice(0, e.length - 1)),
                          (i = u(t)),
                          (this.Ot = e[e.length - 1]);
                      }
                      this._t.play(i), this.kt(e);
                    } catch (e) {
                      this.yt.next();
                    }
                  })),
                (this.xt = () => {
                  (this.ut = !1), (this.Ot = void 0);
                }),
                (this.Mt = () => {
                  this.$ &&
                    ((this.$ = !1),
                    this.N.trigger(r.SpeechSynthesisServiceEvent.TTSStop));
                }),
                this.U(e),
                (this.yt = p(this.vt, () => {})),
                (this._t = (0, a.player)({
                  sampleRate: 22050,
                  numChannels: 1,
                })),
                this._t.onEnd(this.Mt),
                this.getVoices()
                  .then((e) => {
                    this.oe = e.find((e) => e.default);
                  })
                  .catch(() => {}),
                window.addEventListener("beforeunload", () => {
                  this.cancel();
                });
            }
            speak(e) {
              "string" == typeof e &&
                e.trim().length &&
                this.yt.push(this.bt(e));
            }
            cancel() {
              this.gt.abort(),
                (this.gt = new AbortController()),
                this.yt.cancel(),
                this.$ && this._t.stop().catch(() => {});
            }
            getVoices() {
              return i(this, void 0, void 0, function* () {
                let e = this.dt;
                if (e.length) return e;
                if (this.jt) return this.jt;
                return (
                  (this.jt = this.ft("voices")
                    .then((t) =>
                      i(this, void 0, void 0, function* () {
                        try {
                          const s =
                            (yield (yield this.wt(t, !1)).json()).voices || [];
                          return (
                            (e = s.map((e) => ({
                              name: e.name,
                              lang: b(e.culture),
                              default: !!e.default,
                            }))),
                            (this.dt = e),
                            e
                          );
                        } catch (t) {
                          return e;
                        }
                      })
                    )
                    .catch(() => e)),
                  setTimeout(() => {
                    this.jt = void 0;
                  }),
                  this.jt
                );
              });
            }
            getVoice() {
              return this.oe;
            }
            setVoice(e) {
              return i(this, void 0, void 0, function* () {
                if (!e || !Array.isArray(e) || !e.length)
                  throw Error("TTSEmptyParam");
                if (
                  this.oe &&
                  1 === e.length &&
                  !e[0].name &&
                  b(e[0].lang) === this.oe.lang
                )
                  return;
                const t = yield this.getVoices();
                if (!t.length) throw Error("TTSNoVoices");
                if (
                  !e.find((e) => {
                    var s;
                    let i,
                      o = !1;
                    if (e.name) {
                      const s = b(e.name);
                      i = t.find((e) => s === b(e.name));
                    }
                    if (!i && e.lang) {
                      const o = b(e.lang);
                      let r = t.filter((e) => o === e.lang);
                      r.length ||
                        (r = t.filter((e) => o === e.lang.split("-")[0])),
                        (i =
                          null !== (s = r.find((e) => e.default)) &&
                          void 0 !== s
                            ? s
                            : r[0]);
                    }
                    return i && ((this.oe = i), (o = !0)), o;
                  })
                )
                  throw Error("TTSNoMatch");
              });
            }
            on(e, t) {
              this.N.bind(e, t);
            }
            off(e, t) {
              this.N.unbind(e, t);
            }
          };
          const p = (e, t) => {
              const s = [],
                i = () => {
                  s.length && s[0].then(e).catch(t);
                };
              return {
                push: (e) => {
                  e.catch(() => {
                    const t = s.indexOf(e);
                    t > 0 && s.splice(t, 1);
                  }),
                    s.push(e),
                    1 === s.length && i();
                },
                cancel: () => {
                  s.length = 0;
                },
                next: () => {
                  s.shift(), i();
                },
              };
            },
            u = (e) =>
              e.buffer.slice(e.byteOffset, e.byteLength + e.byteOffset),
            g = (e) => {
              const t = new Uint8Array(e),
                s = new Uint8Array(t.length - 44);
              return s.set(t.slice(44, t.length)), u(s);
            },
            m = (e) => {
              const t = new DataView(e, 0, 44),
                s = !0;
              return {
                numChannels: t.getUint16(22, s),
                sampleRate: t.getUint32(24, s),
              };
            },
            b = (e) => e.toLowerCase();
        },
        4076: function (e, t) {
          var s =
            (this && this.v) ||
            function (e, t, s, i) {
              return new (s || (s = Promise))(function (o, r) {
                function a(e) {
                  try {
                    c(i.next(e));
                  } catch (e) {
                    r(e);
                  }
                }
                function n(e) {
                  try {
                    c(i.throw(e));
                  } catch (e) {
                    r(e);
                  }
                }
                function c(e) {
                  var t;
                  e.done
                    ? o(e.value)
                    : ((t = e.value),
                      t instanceof s
                        ? t
                        : new s(function (e) {
                            e(t);
                          })).then(a, n);
                }
                c((i = i.apply(e, t || [])).next());
              });
            };
          Object.defineProperty(t, "p", { value: !0 }),
            (t.player = function (e) {
              let t,
                l,
                h,
                d = e,
                p = [],
                u = () => {},
                g = 0,
                m = !0;
              const b = () =>
                  s(this, void 0, void 0, function* () {
                    t || (t = new AudioContext()),
                      t.state === a && (yield t.resume());
                  }),
                f = () => {
                  p.forEach((e) => {
                    e.removeEventListener(r, x), e.stop(), e.disconnect();
                  }),
                    (p = []);
                },
                w = () =>
                  s(this, void 0, void 0, function* () {
                    (null == t ? void 0 : t.state) !== a &&
                      (yield null == t ? void 0 : t.suspend()),
                      (h = new Float32Array()),
                      (m = !0),
                      (g = 0),
                      (p = []);
                  }),
                v = () => {
                  if (!t || !h.length) return;
                  if (m && h.length < i) return void (m = !1);
                  m = !1;
                  const e = h.length,
                    s = new AudioBuffer({
                      sampleRate: d.sampleRate,
                      length: e,
                    });
                  for (let t = 0; t < d.numChannels; t++) {
                    const i = s.getChannelData(t);
                    for (let t = 0; t < e; t++) i[t] = h[t];
                  }
                  g < t.currentTime && (g = t.currentTime),
                    l && l.removeEventListener(r, x),
                    (l = new AudioBufferSourceNode(t, { buffer: s })),
                    l.connect(t.destination),
                    l.addEventListener(r, x),
                    l.start(g),
                    (g += s.duration),
                    p.push(l),
                    (h = new Float32Array());
                },
                x = () => {
                  (g = 0),
                    setTimeout(() => {
                      g || (w().catch(() => {}), u());
                    }, o);
                };
              return (
                (() => {
                  const e = document.body,
                    s = ["touchend", "click"],
                    i = 3;
                  let o = !0,
                    r = 0;
                  const a = () => {
                      o &&
                        ((t = new AudioContext()),
                        "closed" !== t.state &&
                          t
                            .resume()
                            .then(() => {
                              n(), (r = 0);
                            })
                            .catch((e) => {
                              r++, r < i ? a() : console.error(e);
                            }));
                    },
                    n = () => {
                      s.forEach((t) => {
                        e.removeEventListener(t, a);
                      }),
                        (o = !1);
                    };
                  s.forEach((t) => {
                    e.addEventListener(t, a);
                  });
                })(),
                {
                  play: (e) =>
                    s(this, void 0, void 0, function* () {
                      (h = h ? n(h, e) : c(e)), yield b(), v();
                    }),
                  stop: () =>
                    s(this, void 0, void 0, function* () {
                      t && (f(), yield w(), u());
                    }),
                  config: (e) => {
                    d = Object.assign(Object.assign({}, d), e);
                  },
                  onEnd: (e) => {
                    u = e;
                  },
                }
              );
            });
          const i = 4096,
            o = 250,
            r = "ended",
            a = "suspended";
          const n = (e, t) => new Float32Array([...e, ...c(t)]),
            c = (e) => Float32Array.from(new Int16Array(e), (e) => e / 32768);
        },
        1540: (e, t) => {
          Object.defineProperty(t, "p", { value: !0 }),
            (t.stopAudioInput =
              t.getAudioInputUserMedia =
              t.getAudioInput =
              t.isAudioInputAvailable =
              t.AudioInputSourceType =
                void 0),
            (t.AudioInputSourceType = { DEFAULT: 0, VOICE_RECOGNITION: 6 });
          t.isAudioInputAvailable = () => void 0 !== (0, t.getAudioInput)();
          t.getAudioInput = () => window.audioinput;
          t.getAudioInputUserMedia = (e) =>
            new Promise((e, s) => {
              (0, t.getAudioInput)().checkMicrophonePermission((i) => {
                i
                  ? e()
                  : (0, t.getAudioInput)().getMicrophonePermission((t, i) => {
                      t ? e() : s(i);
                    });
              });
            }).then(
              () => ((0, t.getAudioInput)().start(e), (0, t.getAudioInput)())
            );
          t.stopAudioInput = () =>
            new Promise((e) => {
              (0, t.getAudioInput)().isCapturing()
                ? ((0, t.getAudioInput)().stop(e),
                  (0, t.getAudioInput)().disconnect())
                : e();
            });
        },
        1786: (e, t, s) => {
          Object.defineProperty(t, "p", { value: !0 }), (t.ChatEvent = void 0);
          const i = s(6246),
            o = Object.assign(
              Object.assign(Object.assign({}, i.SpeechSynthesisServiceEvent), {
                CHAT_LANG: "chatlanguagechange",
                CLICK_AUDIO_RESPONSE_TOGGLE: "click:audiotoggle",
                CLICK_ERASE: "click:erase",
                CLICK_VOICE_TOGGLE: "click:voicetoggle",
                DESTROY: "destroy",
                CHAT_END: "chatend",
                MESSAGE: "message",
                MESSAGE_RECEIVED: "message:received",
                MESSAGE_SENT: "message:sent",
                NETWORK: "networkstatuschange",
                READY: "ready",
                TYPING: "typing",
                UNREAD: "unreadCount",
                WIDGET_CLOSED: "widget:closed",
                WIDGET_OPENED: "widget:opened",
                WIDGET_SHOW: "widget:show",
                WIDGET_HIDE: "widget:hide",
              }),
              i.ExecuteActionType
            );
          t.ChatEvent = o;
        },
        9268: (e, t) => {
          Object.defineProperty(t, "p", { value: !0 }),
            (t.CONNECTION_STATE = void 0);
          t.CONNECTION_STATE = {
            CONNECTING: 0,
            OPEN: 1,
            CLOSING: 2,
            CLOSED: 3,
          };
        },
        4787: (e, t) => {
          Object.defineProperty(t, "p", { value: !0 }),
            (t.Constants =
              t.SEC_MULTIPLIER =
              t.ATTACHMENT_MAX_HEIGHT =
              t.MESSAGE_BLOCK_THRESOLD =
              t.ATTACHMENT_MAX_SIZE =
              t.BYTE_MULTIPLIER =
              t.SDK_VERSION =
                void 0);
          class s {}
          (t.Constants = s),
            (s.GEOLOCATION_REQUEST_DENIED = 1),
            (s.CHAT_SCROLL_DELAY = 300),
            (s.WEBSOCKET_READY_STATE = [
              "CONNECTING",
              "OPEN",
              "CLOSING",
              "CLOSED",
            ]),
            (s.WEBSOCKET_CLOSE_EVENT = { CODE: { ABNORMAL_CLOSURE: 1006 } }),
            (s.ATTACHMENT_HEADER = {
              AUTHORIZATION: "Authorization",
              FILE_AUTH_TYPE: "x-oda-meta-file-authType",
              FILE_IS_PROTECTED: "x-oda-meta-file-isProtected",
              FILE_SIZE: "x-oda-meta-file-size",
            }),
            (s.MAX_SUGGESTIONS_COUNT = 5),
            (s.MIN_SUGGESTIONS_COUNT = 1),
            (s.SUGGESTIONS_COUNT_THRESHOLD = 30),
            (s.TIME = { MIN_FIFTY: 3e6 });
          (t.SDK_VERSION = "24.08"),
            (t.BYTE_MULTIPLIER = 1024),
            (t.ATTACHMENT_MAX_SIZE =
              25 * t.BYTE_MULTIPLIER * t.BYTE_MULTIPLIER),
            (t.MESSAGE_BLOCK_THRESOLD = 1e4),
            (t.ATTACHMENT_MAX_HEIGHT = 211),
            (t.SEC_MULTIPLIER = 1e3);
        },
        865: (e, t, s) => {
          Object.defineProperty(t, "p", { value: !0 }),
            (t.defaultSettings = void 0);
          const i = s(6246),
            o = s(5430),
            r = "Please try sharing it again, or else type it in.";
          t.defaultSettings = {
            badgePosition: { right: "-5px", top: "-5px" },
            clientAuthEnabled: !1,
            conversationBeginPosition: "bottom",
            disablePastActions: "all",
            displayActionsAsPills: !1,
            searchBarMode: !1,
            sidepanel: !1,
            embedded: !1,
            embeddedVideo: !0,
            enableAgentSneakPreview: !1,
            enableAttachment: !0,
            enableAttachmentSecurity: !1,
            enableHeaderActionCollapse: !0,
            enableAutocomplete: !1,
            enableAutocompleteClientCache: !1,
            enableBotAudioResponse: !1,
            enableDefaultClientResponse: !1,
            enableClearMessage: !1,
            enableEndConversation: !0,
            enableHeadless: !1,
            enableLocalConversationHistory: !1,
            enableLongPolling: !1,
            enableResizableWidget: !1,
            enableSendTypingStatus: !1,
            enableSecureConnection: !0,
            enableSpeech: !1,
            enableSpeechAutoSend: !0,
            enableTabsSync: !0,
            enableTimestamp: !0,
            enableVoiceOnlyMode: !1,
            focusOnNewMessage: "input",
            height: "620px",
            i18n: {
              en: {
                agent: "Agent",
                agentMessage: "{0} says",
                attachment_audio: "Audio attachment",
                attachment_file: "File attachment",
                attachment_image: "Image attachment",
                attachment_video: "Video attachment",
                attachmentAudioFallback:
                  "Your browser does not support embedded audio. However you can {0}download it{/0}.",
                attachmentVideoFallback:
                  "Your browser does not support embedded video. However you can {0}download it{/0}.",
                audioResponseOff: "Turn audio response on",
                audioResponseOn: "Turn audio response off",
                avatarAgent: "Agent icon",
                avatarBot: "Bot icon",
                avatarUser: "User icon",
                cancelResponse: "Cancel response",
                card: "Card {0}",
                cardImagePlaceholder: "Card image",
                cardNavNext: "Next card",
                cardNavPrevious: "Previous card",
                chatTitle: "Chat",
                clear: "Clear conversation",
                close: "Close widget",
                closing: "Closing",
                connected: "Connected",
                connecting: "Connecting",
                connectionFailureMessage:
                  "Sorry, the assistant is unavailable right now. If the issue persists, contact your help desk.",
                connectionRetryLabel: "Try Again",
                copyFailureMessage:
                  "Sorry, copying is not available on this device.",
                copySuccessMessage:
                  "Successfully copied the response text to the clipboard.",
                defaultGreetingMessage:
                  "Hey, Nice to meet you! Allow me a moment to get back to you.",
                defaultWaitMessage:
                  "I'm still working on your request. Thank you for your patience!",
                defaultSorryMessage:
                  "I'm sorry. I can't get you the right content. Please try again.",
                disconnected: "Disconnected",
                download: "Download",
                editFieldErrorMessage: "Field input is invalid",
                editFormErrorMessage: "Some of the fields need your attention",
                endConversation: "End Conversation",
                endConversationConfirmMessage:
                  "Are you sure you want to end the conversation?",
                endConversationDescription:
                  "This will also clear your conversation history.",
                errorSpeechInvalidUrl:
                  "ODA URL for connection is not set. Please pass 'URI' parameter during SDK initialization.",
                errorSpeechMultipleConnection:
                  "Another voice recognition is ongoing. Can't start a new one.",
                errorSpeechTooMuchTimeout:
                  "The voice message is too long to recognize and generate text.",
                errorSpeechUnavailable:
                  "To allow voice messaging, update your browser settings to enable access to your microphone.",
                errorSpeechUnsupportedLocale:
                  "The locale set for voice recognition is not supported. Please use a valid locale in 'speechLocale' setting.",
                inputPlaceholder: "Type a message",
                imageViewerClose: "Close image viewer",
                imageViewerOpen: "Open image viewer",
                itemIterator: "Item {0}",
                language_ar: "Arabic",
                language_de: "German",
                language_detect: "Detect Language",
                language_en: "English",
                language_es: "Spanish",
                language_fr: "French",
                language_hi: "Hindi",
                language_it: "Italian",
                language_nl: "Dutch",
                language_pt: "Portuguese",
                languageSelectDropdown: "Select chat language",
                linkField: "Click on the highlighted text to open Link for {0}",
                noResultText: "No more results",
                noSpeechTimeout:
                  "The voice could not be detected to perform recognition.",
                noText: "No",
                openMap: "Open Map",
                previousChats: "End of previous conversation",
                ratingStar: "Rate {0} star",
                recognitionTextPlaceholder: "Speak your message",
                relTimeDay: "{0}d ago",
                relTimeHr: "{0}hr ago",
                relTimeMin: "{0}min ago",
                relTimeMoment: "A few seconds ago",
                relTimeMon: "{0}mth ago",
                relTimeNow: "Now",
                relTimeYr: "{0}yr ago",
                requestLocation: "Requesting location",
                requestLocationDeniedPermission:
                  "To allow sharing your location, update your browser settings to enable access to your location. You can also type in the location instead.",
                requestLocationDeniedTimeout: `It is taking too long to get your location. ${r}`,
                requestLocationDeniedUnavailable: `Your current location is unavailable. ${r}`,
                retryMessage: "Try again",
                send: "Send message",
                shareAudio: "Share Audio",
                shareFailureMessage:
                  "Sorry, sharing is not available on this device.",
                shareFile: "Share File",
                shareLocation: "Share Location",
                shareVisual: "Share Image/Video",
                skillMessage: "Skill says",
                showOptions: "Show Options",
                speak: "Speak a message",
                typingIndicator: "Waiting for response",
                upload: "Share popup",
                uploadFailed: "Upload Failed.",
                uploadFileNetworkFailure:
                  "Upload not completed due to network failure.",
                uploadFileSizeLimitExceeded:
                  "File size should not be more than {0}MB.",
                uploadFileSizeZeroByte:
                  "Files of size zero bytes can't be uploaded.",
                uploadUnauthorized: "Upload request is unauthorized.",
                uploadUnsupportedFileType: "Unsupported file type.",
                userMessage: "I say",
                utteranceGeneric: "Message from skill.",
                webViewAccessibilityTitle: "In-widget WebView to display links",
                webViewClose: "Done",
                webViewErrorInfoDismiss: "Dismiss",
                webViewErrorInfoText:
                  "Don't see the page? {0}Click here{/0} to open it in a browser.",
                yesText: "Yes",
              },
              ar: { language_ar: "اَلْعَرَبِيَّةُ" },
              de: { language_de: "Deutsch" },
              es: { language_es: "Español" },
              fr: { language_fr: "Français" },
              hi: { language_hi: "हिन्दी" },
              it: { language_it: "Italiano" },
              nl: { language_nl: "Nederlands" },
              pt: { language_pt: "Português" },
            },
            initBotAudioMuted: !0,
            initMessageOptions: { sendAt: "expand" },
            disableInlineCSS: !1,
            isDebugMode: !1,
            locale: "en",
            messageCacheSizeLimit: 2e3,
            name: "oda-chat",
            openChatOnLoad: !1,
            openLinksInNewWindow: !1,
            readMark: "✓",
            reconnectInterval: 5,
            reconnectMaxAttempts: 5,
            shareMenuItems: [
              o.ShareCategory.AUDIO,
              o.ShareCategory.FILE,
              o.ShareCategory.LOCATION,
              o.ShareCategory.VISUAL,
            ],
            showConnectionStatus: !1,
            showPrevConvStatus: !0,
            showTypingIndicator: !0,
            speechLocale: i.RecognitionLocale.EN_US,
            theme: o.WidgetTheme.DEFAULT,
            timestampMode: "default",
            defaultGreetingTimeout: 5,
            defaultWaitMessageInterval: 5,
            typingIndicatorTimeout: 30,
            typingStatusInterval: 3,
            typingDelay: 0,
            upgradeToWebSocketInterval: 300,
            webViewConfig: {},
            width: "375px",
            actionsLayout: "vertical",
            globalActionsLayout: "vertical",
            cardActionsLayout: "vertical",
            formActionsLayout: "vertical",
            wcfsEnableEndConversationButtonToClose: !1,
          };
        },
        9731: (e, t) => {
          Object.defineProperty(t, "p", { value: !0 }), (t.Deferred = void 0);
          t.Deferred = class {
            constructor() {
              (this.promise = new Promise((e, t) => {
                (this.resolve = e), (this.reject = t);
              })),
                Object.freeze(this);
            }
          };
        },
        3010: (e, t, s) => {
          Object.defineProperty(t, "p", { value: !0 }),
            (t.DOMUtil = void 0),
            (t.addChild = function (e, t) {
              e.appendChild(t);
            }),
            (t.on = h),
            (t.off = function (e, t, s, i) {
              e.removeEventListener(t, s, i);
            });
          const i = s(6064),
            o = s(5430),
            r = s(8291),
            a = "aria-expanded",
            n = "aria-activedescendant",
            c = "expand",
            l = !0;
          function h(e, t, s, i) {
            e.addEventListener(t, s, i);
          }
          t.DOMUtil = class {
            get cssPrefix() {
              return this.zt;
            }
            constructor(e) {
              (this.$t = {}), (this.It = []), (this.zt = e.name);
            }
            addCSSClass(e, ...t) {
              e.classList
                ? t.forEach((t) => e.classList.add(`${this.zt}-${t}`))
                : e.setAttribute(
                    "class",
                    t.reduce((e, t) => `${e} ${this.zt}-${t}`, "")
                  );
            }
            createAnchor(e, t, s = [], i = !1, o) {
              const r = this.createElement("a", s, l);
              r.rel = "noreferrer noopener";
              let a = !1;
              return (
                (r.href = e),
                (r.innerText = t),
                o &&
                  (o.onclick && ((r.onclick = o.onclick.bind(r)), (a = !0)),
                  o.target && ((r.target = o.target), (a = !0))),
                a ||
                  (i
                    ? r.addEventListener(
                        "click",
                        (t) => (
                          window.open(
                            e,
                            "",
                            "height=450px,width=800px,menubar,toolbar,personalbar,status,resizable,noopener,noreferrer"
                          ),
                          t.preventDefault(),
                          t.stopPropagation(),
                          !1
                        )
                      )
                    : (r.target = "_blank")),
                r
              );
            }
            createButton(e = []) {
              const t = "button",
                s = this.createElement(t, [...e, "flex"], l);
              return (s.type = t), s;
            }
            createDiv(e = []) {
              return this.createElement("div", e);
            }
            createElement(e, t = [], s = !1) {
              const i = document.createElement(e);
              return this.Ct(i, t), s && (i.dir = "auto"), i;
            }
            createElementFromString(e, t = []) {
              const s = this.createDiv();
              s.innerHTML = e.trim();
              const i = s.firstElementChild;
              return t && this.Ct(s.firstElementChild, t), i;
            }
            createIconButton({ css: e, icon: t, title: s, iconCss: i }) {
              const o = this.createButton(["icon", ...e]);
              (o.innerHTML = ""), (o.title = s);
              const r = this.createImageIcon({ icon: t, iconCss: i });
              return o.appendChild(r), o;
            }
            createImage(e, t = [], s = "") {
              const i = this.createElement("img", t);
              return (
                e && (i.src = e),
                (i.alt = s),
                i.setAttribute("draggable", "false"),
                i
              );
            }
            createImageIcon({ icon: e, iconCss: t }) {
              if ((0, r.isSVG)(e)) {
                const s = this.createElementFromString(e, t);
                return (
                  s.setAttribute("role", "presentation"),
                  s.setAttribute("focusable", "false"),
                  s
                );
              }
              return this.createImage(e, t);
            }
            createInputElement(e, t = []) {
              const s = this.createElement("input", t, !0);
              return this.setAttributes(s, e), s;
            }
            createLabel(e = []) {
              return this.createElement("label", e, l);
            }
            createTextDiv(e = []) {
              return this.createElement("div", e, l);
            }
            createTextSpan(e = []) {
              return this.createElement("span", e, l);
            }
            setAttributes(e, t) {
              const s = ["valueOn", "valueOff"];
              Object.keys(t).forEach((i) => {
                const o = t[i];
                o &&
                  ("errorMsg" === i
                    ? e.setAttribute("data-error", o)
                    : s.includes(i)
                    ? e.setAttribute(i, o)
                    : (e[i] = o));
              });
            }
            createListItem(e, t, s, i, o, r, a = !1, n = !0) {
              const c = this.createElement("li", [o, a && "with-sub-menu"], !0);
              if (
                ((c.id = e),
                (c.tabIndex = -1),
                c.setAttribute("role", "menuitem"),
                s && c.setAttribute("data-value", s),
                i)
              ) {
                const e = this.createImageIcon({
                  icon: i,
                  iconCss: ["icon", `${o}-icon`],
                });
                c.appendChild(e);
              }
              const l = this.createTextSpan([
                "text",
                `${o}-text`,
                n ? "ellipsis" : "",
              ]);
              return (
                (l.innerText = t), c.appendChild(l), r && h(c, "click", r), c
              );
            }
            createMedia(e, t, s = []) {
              const i = this.createElement(e, s, !0);
              return t && (i.src = t), (i.autoplay = !1), i;
            }
            getMenu(e) {
              const t = this.createElement("ul", ["popup", ...e.menuClassList]);
              (t.id = e.menuId),
                (t.tabIndex = -1),
                t.setAttribute("role", "menu"),
                t.setAttribute("aria-labelledby", e.buttonId);
              const s = e.menuItems;
              if ((s.forEach((e) => t.appendChild(e)), e.defaultValue)) {
                const s = t.querySelector(`[data-value="${e.defaultValue}"]`);
                this.addCSSClass(s, "active");
              }
              return (
                h(t, "click", () => this.St(t, e.menuButton)),
                h(t, "keydown", (o) => {
                  let r = !1;
                  if (!(o.ctrlKey || o.altKey || o.metaKey)) {
                    if (o.shiftKey && o.code === i.KeyCode.Tab)
                      this.St(e.menuButton, t);
                    else
                      switch (o.code) {
                        case i.KeyCode.Return:
                        case i.KeyCode.Space:
                          o.target.click(), (r = !0);
                          break;
                        case i.KeyCode.Esc:
                        case i.KeyCode.Tab:
                          this.St(e.menuButton, t),
                            o.code === i.KeyCode.Esc &&
                              (e.menuButton.focus(), (r = !0));
                          break;
                        case i.KeyCode.Up:
                          this.Tt(t), (r = !0);
                          break;
                        case i.KeyCode.Down:
                          this.At(t), (r = !0);
                          break;
                        case i.KeyCode.Home:
                        case i.KeyCode.PageUp:
                          this.Et(t, s), (r = !0);
                          break;
                        case i.KeyCode.End:
                        case i.KeyCode.PageDown:
                          this.Pt(t, s), (r = !0);
                      }
                    r && (o.stopPropagation(), o.preventDefault());
                  }
                }),
                t
              );
            }
            getMenuButton(e) {
              const t = e.button,
                s = e.menu,
                o = s.querySelectorAll("li"),
                r = t.classList.contains(`${this.zt}-with-sub-menu`),
                n = e.widget;
              return (
                t.setAttribute("role", "button"),
                t.setAttribute("aria-haspopup", "true"),
                t.setAttribute(a, "false"),
                t.setAttribute("aria-controls", e.menuId),
                h(t, "click", () => {
                  const s = document.getElementById(e.menuId);
                  "true" === t.getAttribute(a)
                    ? this.St(t, s)
                    : this.Lt(t, s, n, r);
                }),
                h(t, "keydown", (e) => {
                  let a = !1;
                  switch (e.code) {
                    case i.KeyCode.Return:
                    case i.KeyCode.Down:
                    case i.KeyCode.Space:
                      this.Lt(t, s, n, r), this.Et(s, o), (a = !0);
                      break;
                    case i.KeyCode.Up:
                      this.Lt(t, s, n, r), this.Pt(s, o), (a = !0);
                  }
                  a && (e.stopPropagation(), e.preventDefault());
                }),
                t
              );
            }
            getMessage(e, t = !1) {
              const s = "message",
                i = this.createDiv([s]),
                o = this.createDiv([`${s}-wrapper`]),
                r = this.createDiv([`${s}-bubble`, t && "error"]);
              return r.appendChild(e), o.appendChild(r), i.appendChild(o), i;
            }
            wrapMessageBlock(e, t, s = o.MESSAGE_SIDE.LEFT) {
              const i = "message",
                r = this.createDiv([`${i}-block`, "flex", s]),
                a = this.createDiv([`${i}s-wrapper`]),
                n = this.createDiv([`${i}-list`, "flex", "col"]);
              if (t) {
                const e = this.createImageIcon({
                    icon: t,
                    iconCss: ["message-icon"],
                  }),
                  s = this.createDiv(["icon-wrapper"]);
                s.appendChild(e), r.appendChild(s);
              }
              return n.appendChild(e), a.appendChild(n), r.appendChild(a), r;
            }
            getMessageBlock(e, t, s, i = !1) {
              return this.wrapMessageBlock(this.getMessage(t, i), s, e);
            }
            removeCSSClass(e, ...t) {
              var s, i;
              if (e.classList)
                t.forEach((t) => e.classList.remove(`${this.zt}-${t}`));
              else {
                const t = "class",
                  o =
                    null !==
                      (i =
                        null === (s = e.getAttribute(t)) || void 0 === s
                          ? void 0
                          : s.split(" ")) && void 0 !== i
                      ? i
                      : [];
                if (o.length) {
                  const s = o
                    .filter((e) => o.indexOf(`${this.zt}-${e}`) < 0)
                    .join(" ");
                  e.setAttribute(t, s);
                }
              }
            }
            setChatWidgetWrapper(e) {
              this.Ft = e;
              for (const [e, t] of Object.entries(this.$t))
                this.updateCSSVar(e, t);
            }
            updateCSSVar(e, t) {
              (this.$t[e] = t), this.Ft && this.Ft.style.setProperty(e, t);
            }
            Ct(e, t = []) {
              return t && this.addCSSClass(e, ...t), e;
            }
            St(e, t) {
              e.getAttribute(a) &&
                (this.removeCSSClass(t, c), e.setAttribute(a, "false"));
            }
            Et(e, t) {
              this.Nt(t[0], e);
            }
            Pt(e, t) {
              this.Nt(t[t.length - 1], e);
            }
            Tt(e) {
              const t = e.getAttribute(n),
                s = e.querySelector(`#${t}`);
              this.Nt(s.previousSibling || e.lastChild, e);
            }
            At(e) {
              const t = e.getAttribute(n),
                s = e.querySelector(`#${t}`);
              this.Nt(s.nextSibling || e.firstChild, e);
            }
            Nt(e, t) {
              e.focus(), t.setAttribute(n, e.id);
            }
            Lt(e, t, s, i = !1) {
              if ("false" === e.getAttribute(a)) {
                this.addCSSClass(t, c), e.setAttribute(a, "true");
                const o = s.getBoundingClientRect(),
                  r = e.getBoundingClientRect(),
                  n = "rtl" === window.getComputedStyle(t).direction;
                if (i) {
                  const i = 48;
                  (t.style.top = `${e.offsetTop + e.offsetHeight + 60}px`),
                    n ? (t.style.left = `${i}px`) : (t.style.right = `${i}px`),
                    (t.style.maxWidth = s.offsetWidth - i + "px");
                } else {
                  let e = o.right - r.right;
                  n
                    ? ((e = r.left - o.left), (t.style.left = `${e}px`))
                    : (t.style.right = `${e}px`),
                    (t.style.maxWidth = s.offsetWidth - e + "px");
                }
                setTimeout(() => {
                  const s = document.querySelectorAll(
                    `.${this.zt}-with-sub-menu`
                  );
                  document.addEventListener(
                    "click",
                    (i) => {
                      let o = !1;
                      s.forEach((e) => {
                        e.contains(i.target) && (o = !0);
                      }),
                        o
                          ? this.It.push({ menu: t, menuButton: e })
                          : (this.It.length &&
                              (this.It.forEach((e) => {
                                this.St(e.menuButton, e.menu);
                              }),
                              (this.It = [])),
                            this.St(e, t));
                    },
                    { once: !0 }
                  );
                });
              }
            }
          };
        },
        4494: (e, t, s) => {
          Object.defineProperty(t, "p", { value: !0 }),
            (t.DragAndDrop = void 0);
          const i = s(8291),
            o = 100;
          t.DragAndDrop = class {
            constructor(e, t, s) {
              (this.Rt = e),
                (this.handle = t),
                (this.moveElement = s),
                (this.active = !1),
                (this.dragged = !1),
                (this.currentX = 0),
                (this.currentY = 0),
                (this.initialX = 0),
                (this.initialY = 0),
                (this.pointerEventsDefault = null),
                (this.dragBound = this.drag.bind(this)),
                (this.dragEndBound = this.dragEnd.bind(this));
            }
            makeElementDraggable() {
              void 0 === this.moveElement && (this.moveElement = this.handle),
                (this.handle.style.userSelect = "none");
              const e = (0, i.debounce)(() => {
                document.body.contains(this.moveElement)
                  ? (this.moveBackInScreen(0, 0),
                    (this.moveElement.style.transform = `translate(${this.currentX}px, ${this.currentY}px)`))
                  : window.removeEventListener("resize", e);
              }, 500);
              window.addEventListener("resize", e),
                this.handle.addEventListener(
                  "touchstart",
                  this.dragStart.bind(this)
                ),
                this.handle.addEventListener(
                  "mousedown",
                  this.dragStart.bind(this)
                );
            }
            moveBackInScreen(e, t) {
              const s = this.handle.getBoundingClientRect(),
                i = s.width > o ? s.width : o,
                r = s.height > o ? s.height : o;
              s.left - e + (i - o) < 0 &&
                (this.currentX = this.currentX - (s.left - e) - (i - o)),
                s.right - e - (i - o) > document.body.clientWidth &&
                  (this.currentX =
                    this.currentX -
                    (s.right - document.body.clientWidth) +
                    e +
                    (i - o)),
                s.top - t + (r - o) < 0 &&
                  (this.currentY = this.currentY - (s.top - t) - (r - o)),
                s.bottom - t - (r - o) > window.innerHeight &&
                  (this.currentY =
                    this.currentY -
                    (s.bottom - window.innerHeight) +
                    t +
                    (r - o));
            }
            dragStart(e) {
              let t, s;
              "touchstart" === e.type
                ? ((t = e.touches[0].clientX), (s = e.touches[0].clientY))
                : ((t = e.clientX), (s = e.clientY)),
                (this.initialX = t - this.currentX),
                (this.initialY = s - this.currentY),
                (this.active = !0),
                document.addEventListener("touchmove", this.dragBound),
                document.addEventListener("mousemove", this.dragBound),
                document.addEventListener("touchend", this.dragEndBound),
                document.addEventListener("mouseup", this.dragEndBound),
                document.addEventListener("touchend", (e) => {});
            }
            drag(e) {
              let t, s;
              if (this.active) {
                "touchmove" === e.type
                  ? ((t = e.touches[0].clientX), (s = e.touches[0].clientY))
                  : ((t = e.clientX), (s = e.clientY));
                const i = t - this.currentX,
                  o = s - this.currentY,
                  r = this.currentX - (t - this.initialX),
                  a = this.currentY - (s - this.initialY);
                (this.currentX = t - this.initialX),
                  (this.currentY = s - this.initialY),
                  (i >= 5 || o >= 5 || i <= -5 || o <= -5) &&
                    (this.moveBackInScreen(r, a),
                    this.Rt.addCSSClass(this.moveElement, "drag"),
                    (this.moveElement.style.transform = `translate(${this.currentX}px, ${this.currentY}px)`),
                    this.dragged ||
                      ((this.pointerEventsDefault =
                        this.handle.style.pointerEvents),
                      (this.handle.style.pointerEvents = "none")),
                    (this.dragged = !0));
              }
            }
            dragEnd() {
              this.dragged &&
                ((this.handle.style.pointerEvents = this.pointerEventsDefault),
                this.handle.focus(),
                (this.dragged = !1)),
                (this.active = !1),
                document.removeEventListener("touchmove", this.dragBound),
                document.removeEventListener("mousemove", this.dragBound),
                document.removeEventListener("touchend", this.dragEndBound),
                document.removeEventListener("mouseup", this.dragEndBound);
            }
          };
        },
        8098: function (e, t, s) {
          var i =
              (this && this.t) ||
              (Object.create
                ? function (e, t, s, i) {
                    void 0 === i && (i = s);
                    var o = Object.getOwnPropertyDescriptor(t, s);
                    (o &&
                      !("get" in o ? !t.p : o.writable || o.configurable)) ||
                      (o = {
                        enumerable: !0,
                        get: function () {
                          return t[s];
                        },
                      }),
                      Object.defineProperty(e, i, o);
                  }
                : function (e, t, s, i) {
                    void 0 === i && (i = s), (e[i] = t[s]);
                  }),
            o =
              (this && this.u) ||
              function (e, t) {
                for (var s in e)
                  "default" === s ||
                    Object.prototype.hasOwnProperty.call(t, s) ||
                    i(t, e, s);
              };
          Object.defineProperty(t, "p", { value: !0 }),
            o(s(1540), t),
            o(s(1786), t),
            o(s(9268), t),
            o(s(4787), t),
            o(s(865), t),
            o(s(9731), t),
            o(s(3010), t),
            o(s(4494), t),
            o(s(4074), t),
            o(s(9424), t),
            o(s(4914), t),
            o(s(1660), t),
            o(s(8291), t),
            o(s(2436), t);
        },
        4074: function (e, t, s) {
          var i =
            (this && this.v) ||
            function (e, t, s, i) {
              return new (s || (s = Promise))(function (o, r) {
                function a(e) {
                  try {
                    c(i.next(e));
                  } catch (e) {
                    r(e);
                  }
                }
                function n(e) {
                  try {
                    c(i.throw(e));
                  } catch (e) {
                    r(e);
                  }
                }
                function c(e) {
                  var t;
                  e.done
                    ? o(e.value)
                    : ((t = e.value),
                      t instanceof s
                        ? t
                        : new s(function (e) {
                            e(t);
                          })).then(a, n);
                }
                c((i = i.apply(e, t || [])).next());
              });
            };
          Object.defineProperty(t, "p", { value: !0 }),
            (t.linkify = t.getEmbeddedVideo = void 0);
          const o = s(6064),
            r =
              /\b(?:(?:https?|ftp):\/\/|(www\.))[-a-z0-9+&@#/%?=~_|!:,.;]*[-a-z0-9+&@#/%=~_|]/gim;
          t.linkify = (e, t, s) => {
            const i = a(e).replace((0, o.resetRegex)(r), u(s, t)),
              n = O(i, t);
            return h(n);
          };
          const a = (e) => {
              let t;
              try {
                t = (0, o.parseDOM)(e);
              } catch (t) {
                return e;
              }
              return n(t), c(t), (0, o.decodeHTMLEntites)(t.innerHTML);
            },
            n = (e) => (
              e.querySelectorAll("a").forEach((e) => {
                e.outerHTML = l(e.outerHTML);
              }),
              e
            ),
            c = (e) => {
              e.querySelectorAll("*").forEach((e) => {
                if ("A" !== e.tagName) {
                  const t = e.attributes;
                  for (let e = 0; e < t.length; e++) {
                    const s = t[e];
                    s.value = l(s.value);
                  }
                }
              });
            },
            l = (e) => e.replace(/(https?|www)/gim, p),
            h = (e) => {
              let t = e;
              return (
                d.forEach((e, s) => {
                  t = t.replace(new RegExp(s, "g"), e);
                }),
                d.clear(),
                t
              );
            },
            d = new Map(),
            p = (e) => {
              const t =
                performance.now().toString(36).replace(".", "_") +
                Math.random().toString(36).substring(2);
              return d.set(t, e), t;
            },
            u = (e, t) => (s, i) => {
              if (e) {
                const e = g(s, t);
                if (e) return e;
              }
              return `<a href="${
                i ? `https://${s}` : s
              }" target="_blank" rel="noreferrer">${s}</a>`;
            },
            g = (e, t) => {
              let s, i;
              try {
                const t = e.toLowerCase().startsWith("https")
                  ? new URL(e)
                  : new URL(`https://${e}`);
                s = t.hostname.toLowerCase();
              } catch (e) {
                return i;
              }
              return (
                y.some((r) => {
                  const a = s.includes(r.name);
                  if (a) {
                    const s = (0, o.generateID)();
                    "videohub" !== r.name && m(r.url, e, t, s),
                      (i = r.getEmbed(r.getId(e), s, t));
                  }
                  return a;
                }),
                i
              );
            };
          t.getEmbeddedVideo = g;
          const m = (e, t, s, r) =>
              i(void 0, void 0, void 0, function* () {
                const i = `${e}?url=${t}`;
                try {
                  const e = yield fetch(i);
                  if (!e.ok) return;
                  const t = yield e.json();
                  if (t && t.html) {
                    const e = t.html.replace(
                        "<iframe",
                        `<iframe class="${s}-video-wrapper"`
                      ),
                      i = document.getElementById(r);
                    null == i || i.replaceWith((0, o.stringToHTML)(e));
                  }
                } catch (e) {}
              }),
            b =
              /(?:youtu.*be.*)\/(?:watch\?v=|embed\/|v\/|shorts|)(.*?((?=[&#?])|$))/gm,
            f = /(?:https?:\/\/)?videohub\.oracle\.com\/media\/\S+\/([\w]+)/gim,
            w = /^(?:https?:\/\/)?(?:www\.)?vimeo\.com\/(\d+)(?:|\/\?)/gim,
            v =
              /^(?:https?:\/\/)?(?:www\.)?(?:dailymotion\.com\/(?:video|embed)|dai.ly)\/([a-z0-9]+)/gim,
            x = "allow",
            k = `${x}="autoplay *; fullscreen *; encrypted-media *" sandbox="${x}-downloads ${x}-forms ${x}-same-origin ${x}-scripts ${x}-top-navigation ${x}-pointer-lock ${x}-popups ${x}-modals ${x}-orientation-lock ${x}-popups-to-escape-sandbox ${x}-presentation ${x}-top-navigation-by-user-activation" height="auto"`,
            y = [
              {
                name: "youtu",
                url: "https://www.youtube.com/oembed",
                getEmbed: (e, t, s) =>
                  M(
                    `src="https://www.youtube.com/embed/${e}" allow="accelerometer; encrypted-media; gyroscope; picture-in-picture"`,
                    t,
                    s,
                    "youtube"
                  ),
                getId: (e) => _(e, b),
              },
              {
                name: "videohub",
                url: "",
                getEmbed: (e, t, s) => {
                  const i = "flashvars";
                  return M(
                    `src="https://cdnapisec.kaltura.com/p/2171811/sp/217181100/embedIframeJs/uiconf_id/35965902/partner_id/2171811?iframeembed=true&playerId=kaltura_player&entry_id=${e}&${i}[streamerType]=auto&amp;${i}[localizationCode]=en&amp;${i}[sideBarContainer.plugin]=true&amp;${i}[sideBarContainer.position]=left&amp;${i}[sideBarContainer.clickToClose]=true&amp;${i}[chapters.plugin]=true&amp;${i}[chapters.layout]=vertical&amp;${i}[chapters.thumbnailRotator]=false&amp;${i}[streamSelector.plugin]=true&amp;${i}[EmbedPlayer.SpinnerTarget]=videoHolder&amp;${i}[dualScreen.plugin]=true&amp;${i}[hotspots.plugin]=1&amp;${i}[Kaltura.addCrossoriginToIframe]=true&amp;&wid=1_yz4xoltb" ${k}`,
                    t,
                    s,
                    "ovh"
                  );
                },
                getId: (e) => _(e, f),
              },
              {
                name: "vimeo",
                url: "https://vimeo.com/api/oembed.json",
                getEmbed: (e, t, s) =>
                  M(
                    `src="https://player.vimeo.com/video/${e}" allow="fullscreen; picture-in-picture"`,
                    t,
                    s,
                    "vimeo"
                  ),
                getId: (e) => _(e, w),
              },
              {
                name: "dai",
                url: "https://www.dailymotion.com/services/oembed",
                getEmbed: (e, t, s) =>
                  M(
                    `src="https://geo.dailymotion.com/player.html?video=${e}" allow="fullscreen; picture-in-picture; web-share"`,
                    t,
                    s,
                    "dailymotion"
                  ),
                getId: (e) => _(e, v),
              },
            ],
            _ = (e, t) => {
              let s;
              return (
                e.replace(
                  (0, o.resetRegex)(t),
                  (e, t) => (t && t.length && (s = t), e)
                ),
                s
              );
            },
            O = (e, t) => {
              const s = (0, o.parseDOM)(e);
              if (!s) return e;
              const i = s.querySelectorAll("video"),
                r = `${t}-video-wrapper`;
              return (
                i.forEach((e) => {
                  e.classList.add(r);
                }),
                (0, o.decodeHTMLEntites)(s.innerHTML)
              );
            },
            M = (e, t, s, i) =>
              `<div class="${s}-${i}-wrapper"><iframe id="${t}" class="${s}-video-wrapper" ${e} allowfullscreen frameborder="0"></iframe></div>`;
        },
        9424: (e, t) => {
          Object.defineProperty(t, "p", { value: !0 }), (t.Resize = void 0);
          const s = "resize",
            i = [`nw-${s}`, `se-${s}`, `nwse-${s}`, `w-${s}`, `e-${s}`],
            o = [`ne-${s}`, `sw-${s}`, `nesw-${s}`, `e-${s}`, `w-${s}`];
          t.Resize = class {
            constructor(e, t, s) {
              (this.Dt = e),
                (this.Ht = t),
                (this.Rt = s),
                (this.Ut = 200),
                (this.Vt = 375),
                (this.Bt = !1),
                (this.Wt = !1);
            }
            makeWidgetResizable() {
              const e = this.Dt,
                t = this.Rt,
                i = t.createDiv(["resizable", `top-${s}`]);
              i.addEventListener("mousedown", this.Zt()), e.appendChild(i);
              const o = t.createDiv(["resizable", `left-${s}`]);
              o.addEventListener("mousedown", this.Gt()), e.appendChild(o);
              const r = t.createDiv(["resizable", `right-${s}`]);
              r.addEventListener("mousedown", this.Gt(!1)), e.appendChild(r);
              const a = t.createDiv(["resizable", `left-${s}`, "corner"]);
              a.addEventListener("mousedown", this.Gt(!0, !0)),
                a.addEventListener("mousedown", this.Zt(!0)),
                e.appendChild(a);
              const n = t.createDiv(["resizable", `right-${s}`, "corner"]);
              n.addEventListener("mousedown", this.Gt(!1, !0)),
                n.addEventListener("mousedown", this.Zt(!0)),
                e.appendChild(n);
            }
            Gt(e = !0, t = !1) {
              const r = this.Dt,
                a = e ? i : o;
              let n;
              const c = (i) => {
                  const o = parseInt(getComputedStyle(r).maxWidth),
                    c = r.offsetWidth;
                  let l = n - i.x;
                  e || (l = -l);
                  const h = c + l;
                  if (
                    (c < this.Vt && (this.Vt = c),
                    (n = i.x),
                    h <= this.Vt
                      ? (document.body.style.cursor = t
                          ? this.Bt
                            ? a[0]
                            : a[2]
                          : a[3])
                      : (document.body.style.cursor =
                          h >= o
                            ? t
                              ? this.Wt
                                ? a[1]
                                : a[2]
                              : a[4]
                            : t
                            ? a[2]
                            : `col-${s}`),
                    h >= this.Vt && h <= o)
                  ) {
                    const e = `${h}px`;
                    (r.style.width = e), this.Ht(e);
                  }
                  i.preventDefault();
                },
                l = () => {
                  document.removeEventListener("mouseup", l, !1),
                    document.removeEventListener("mousemove", c, !1),
                    document.body.style.removeProperty("cursor");
                };
              return (e) => {
                e.preventDefault(),
                  (n = e.x),
                  document.addEventListener("mouseup", l, !1),
                  document.addEventListener("mousemove", c, !1);
              };
            }
            Zt(e = !1) {
              const t = this.Dt;
              let i;
              const o = (o) => {
                  const r = i - o.y,
                    a = parseInt(getComputedStyle(t).maxHeight),
                    n = t.offsetHeight,
                    c = n + r;
                  n < this.Ut && (this.Ut = n),
                    (i = o.y),
                    c <= this.Ut
                      ? ((this.Bt = !0),
                        e || (document.body.style.cursor = `n-${s}`))
                      : c >= a
                      ? ((this.Wt = !0),
                        e || (document.body.style.cursor = `s-${s}`))
                      : ((this.Bt = !1),
                        (this.Wt = !1),
                        e || (document.body.style.cursor = `row-${s}`)),
                    c >= this.Ut && c <= a && (t.style.height = `${c}px`),
                    o.preventDefault();
                },
                r = () => {
                  document.removeEventListener("mouseup", r, !1),
                    document.removeEventListener("mousemove", o, !1),
                    document.body.style.removeProperty("cursor");
                };
              return (e) => {
                e.preventDefault(),
                  (i = e.y),
                  document.addEventListener("mouseup", r, !1),
                  document.addEventListener("mousemove", o, !1);
              };
            }
          };
        },
        4914: (e, t) => {
          Object.defineProperty(t, "p", { value: !0 }), (t.Response = void 0);
          class s {}
          (t.Response = s), (s.STATUS = { OK: 200 });
        },
        1660: (e, t) => {
          Object.defineProperty(t, "p", { value: !0 }),
            (t.iconStartOver =
              t.iconInlineError =
              t.iconInlineLogo =
              t.iconInlineLaunch =
              t.iconThumbsUp =
              t.iconThumbsDown =
              t.iconSuccess =
              t.iconGenerating =
              t.iconCheck =
              t.iconZoom =
              t.iconWarn =
              t.iconVideo =
              t.iconTTSUnmute =
              t.iconTTSMute =
              t.iconStop =
              t.iconShareMedia =
              t.iconShareLocation =
              t.iconShareFile =
              t.iconShareAudio =
              t.iconSend =
              t.iconSearch =
              t.iconRating =
              t.iconMic =
              t.iconLogo =
              t.iconLaunchButton =
              t.iconLanguage =
              t.iconKeyboard =
              t.iconImage =
              t.iconFile =
              t.iconExternalLink =
              t.iconExpandArrow =
              t.iconExpand =
              t.iconError =
              t.iconDownload =
              t.iconCollapse =
              t.iconClose =
              t.iconClearHistory =
              t.iconChevronPrevious =
              t.iconChevronNext =
              t.iconChevronDown =
              t.iconCaretDown =
              t.iconAudio =
              t.iconAttach =
                void 0);
          const s = U(
            '<path d="M11.007 15.117A1 1 0 0 0 13 15V7l-.005-.176A3 3 0 0 0 7 7v8l.005.217A5 5 0 0 0 17 15V5h2v10a7 7 0 1 1-14 0V7a5 5 0 0 1 10 0v8l-.005.176A3 3 0 0 1 9 15V9h2v6z"/>'
          );
          t.iconAttach = s;
          const i = U(
            '<path d="M4 2h10.414L20 7.586V10h-2V9h-5V4H6v16h12v-1h2v3H4zm11 3.414L16.586 7H15z"/><path d="m7.764 17 1.849-4.87h1.012L12.486 17H11.32l-.32-.998H9.204L8.882 17zm1.722-1.883h1.226l-.617-1.916zm3.278-.415v-2.573h1.045v2.553c0 .531.079.916.235 1.152.156.233.404.349.744.349.344 0 .591-.116.743-.349.157-.236.235-.62.235-1.152v-2.553h1.045v2.573c0 .822-.165 1.427-.496 1.816-.326.384-.835.576-1.527.576s-1.204-.192-1.535-.576c-.326-.389-.489-.994-.489-1.816zM17.686 17v-4.87h1.635c.795 0 1.396.205 1.802.616.407.41.61 1.018.61 1.822 0 .795-.203 1.4-.61 1.816-.402.41-1.002.616-1.802.616zm1.622-4.02h-.577v3.17h.577c.45 0 .786-.128 1.005-.383.223-.259.335-.659.335-1.2s-.11-.94-.329-1.198c-.218-.26-.556-.389-1.011-.389z"/>'
          );
          t.iconAudio = i;
          const o = U('<path fill="#161513" d="m6 9 5.975 6L18 9H6z"/>');
          t.iconCaretDown = o;
          const r = U(
            '<path d="M6.35 8L5 9.739 12 16l7-6.261L17.65 8 12 13.054z"/>'
          );
          t.iconChevronDown = r;
          const a = U(
            '<path d="M8 17.65L9.739 19 16 12 9.739 5 8 6.35 13.054 12z"/>'
          );
          t.iconChevronNext = a;
          const n = U(
            '<path d="M16 17.65L14.261 19 8 12l6.261-7L16 6.35 10.946 12z"/>'
          );
          t.iconChevronPrevious = n;
          const c = U(
            '<path d="M6 11h8v2H6zm0-4h12v2H6z"/><path d="M2 2v20h3.5l3-4H14v-2H7.5l-3 4H4V4h16v6h2V2z"/><path d="M20.3 12.3L19 13.6l-1.3-1.3-1.4 1.4 1.3 1.3-1.3 1.3 1.4 1.4 1.3-1.3 1.3 1.3 1.4-1.4-1.3-1.3 1.3-1.3z"/>'
          );
          t.iconClearHistory = c;
          const l = U(
            '<path d="M17.524 5 19 6.476 13.475 12 19 17.524 17.524 19 12 13.475 6.476 19 5 17.524 10.525 12 5 6.476 6.476 5 12 10.525z"/>'
          );
          t.iconClose = l;
          const h = U(
            '<path d="M11 13v9H9v-5.586l-6.293 6.293-1.414-1.414L7.586 15H2v-2zM21.293 1.293l1.414 1.414L16.414 9H22v2h-9V2h2v5.586z"/>'
          );
          t.iconCollapse = h;
          const d = U(
            '<path d="M4 15v5h16v-5h2v7H2v-7zm9-13v10.587l3.293-3.294 1.414 1.414L12 16.414l-5.707-5.707 1.414-1.414L11 12.585V2z"/>'
          );
          t.iconDownload = d;
          const p = U(
            '<path d="M12 2C6.477 2 2 6.477 2 12s4.477 10 10 10 10-4.477 10-10S17.523 2 12 2zM8.707 7.293l8 8-1.414 1.414-8-8z"/></svg>'
          );
          t.iconError = p;
          t.iconExpand =
            '<svg xmlns="http://www.w3.org/2000/svg" height="20" width="20" viewBox="0 0 20 20"><path d="M4.99935 9.99967C4.99935 10.9201 4.25316 11.6663 3.33268 11.6663C2.41221 11.6663 1.66602 10.9201 1.66602 9.99967C1.66602 9.0792 2.41221 8.33301 3.33268 8.33301C4.25316 8.33301 4.99935 9.0792 4.99935 9.99967Z" fill="#161513"/><path d="M11.666 9.99967C11.666 10.9201 10.9198 11.6663 9.99935 11.6663C9.07887 11.6663 8.33268 10.9201 8.33268 9.99967C8.33268 9.0792 9.07887 8.33301 9.99935 8.33301C10.9198 8.33301 11.666 9.0792 11.666 9.99967Z" fill="#161513"/><path d="M18.3327 9.99967C18.3327 10.9201 17.5865 11.6663 16.666 11.6663C15.7455 11.6663 14.9993 10.9201 14.9993 9.99967C14.9993 9.0792 15.7455 8.33301 16.666 8.33301C17.5865 8.33301 18.3327 9.0792 18.3327 9.99967Z" fill="#161513"/></svg';
          t.iconExpandArrow =
            '<svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg"><path fill-rule="evenodd" clip-rule="evenodd" d="M6 9L11.9746 15L18 9H6Z" fill="#161513"/></svg>';
          const u = U(
            '<path class="st0" d="M20 20H4V4h7V2H2v20h20v-9h-2z"/><path xmlns="http://www.w3.org/2000/svg" class="st0" d="M14 2v2h4.6L8.3 14.3l1.4 1.4L20 5.4V10h2V2z"/>'
          );
          t.iconExternalLink = u;
          const g = U(
            '<path d="M14.414 2 21 8.584V22H3V2.009zM13 3.999l-8 .007v15.995h14V9.996l-6 .001zm4.585 3.998L15 5.413v2.585z"/>'
          );
          t.iconFile = g;
          const m = U(
            '<path d="M4 2h10.414L20 7.586V22H4zm2 2v16h12V9h-5V4zm9 1.414L16.586 7H15z"/><path d="M16 12a1 1 0 11-2 0 1 1 0 012 0zm-6.143 1L7 19h10l-2.857-4.5L12 16.75z"/>'
          );
          t.iconImage = m;
          const b = U(
            '<path d="M22 5v14H2V5zm-2 2H4v10h16zM7 13v2H5v-2zm12 0v2h-2v-2zm-4 0v2H9v-2zM7 9v2H5V9zm12 0v2h-2V9zm-4 0v2h-2V9zm-4 0v2H9V9z" />'
          );
          t.iconKeyboard = b;
          const f = U(
            '<path d="M13 14c-1.5 0-2.9-.4-4-1.1 1.1-2.4 1.7-5 1.9-6.9h9V4H7V2H5v2H2v2h6.9c-.2 1.7-.7 3.7-1.5 5.6C6.5 10.5 6 9.2 6 8H4c0 1.9.9 4 2.5 5.5C5.3 15.5 3.8 17 2 17v2c2.6 0 4.6-1.9 6.1-4.3 1.4.8 3 1.3 4.9 1.3zm7.6 4.6L17 10.5l-3.6 8.1-1.3 3 1.8.8L15 20h4l1.1 2.4 1.8-.8zm-4.7-.6l1.1-2.5 1.1 2.5z"/>'
          );
          t.iconLanguage = f;
          t.iconLaunchButton =
            '<svg width="36" height="36" viewBox="0 0 36 36"><path fill-rule="evenodd" clip-rule="evenodd" d="M7.875 8.625a2.25 2.25 0 00-2.25 2.25v16c0 .621.504 1.125 1.125 1.125h.284c.298 0 .585-.119.796-.33l2.761-2.76a2.25 2.25 0 011.59-.66h15.944a2.25 2.25 0 002.25-2.25V10.875a2.25 2.25 0 00-2.25-2.25H7.875zM24.75 18a2.25 2.25 0 100-4.5 2.25 2.25 0 000 4.5zm-4.5-2.25a2.25 2.25 0 11-4.5 0 2.25 2.25 0 014.5 0zm-9 2.25a2.25 2.25 0 100-4.5 2.25 2.25 0 000 4.5z" fill="#fff"/></svg>';
          const w = U(
            '<path d="M4.014 3C2.911 3 2 3.888 2 4.992v15c0 .6.408 1.008 1.007 1.008h.6a.887.887 0 0 0 .695-.288l3.094-3.12c.407-.384.91-.6 1.415-.6h11.175C21.089 16.992 22 16.104 22 15V4.992C22 3.888 21.089 3 19.986 3zm3.981 7.008A1.986 1.986 0 0 1 6.005 12c-1.103 0-1.99-.888-1.99-1.992s.887-2.016 1.99-2.016 1.99.912 1.99 2.016zm5.995 0C13.99 11.112 13.103 12 12 12s-1.99-.888-1.99-1.992.887-2.016 1.99-2.016 1.99.912 1.99 2.016zm5.996 0c0 1.104-.888 1.992-1.99 1.992s-1.991-.888-1.991-1.992.887-2.016 1.99-2.016 1.99.912 1.99 2.016z" fill="#fff"/>'
          );
          t.iconLogo = w;
          const v = U(
            '<path d="M7 22v-2h4v-2.062C7.06 17.444 4 14.073 4 10h2c0 3.309 2.691 6 6 6s6-2.691 6-6h2c0 4.072-3.059 7.444-7 7.938V20h4v2h-6zm5-20c2.206 0 4 1.794 4 4v4c0 2.206-1.794 4-4 4s-4-1.794-4-4V6c0-2.206 1.794-4 4-4zm0 2c-1.103 0-2 .897-2 2v4c0 1.103.897 2 2 2s2-.897 2-2V6c0-1.103-.897-2-2-2z"/>'
          );
          t.iconMic = v;
          const x = U(
            '<path d="M19.33 23.02l-7.332-3.666-7.332 3.666 1.418-7.995L1 9.555l7.331-1.222L11.998 1l3.666 7.333 7.332 1.222-5.084 5.47z"/>'
          );
          t.iconRating = x;
          const k = U(
            '<path d="M10 2a8 8 0 016.317 12.91l5.383 5.384-1.414 1.414-5.386-5.384A8 8 0 1110 2zm0 2a6 6 0 100 12 6 6 0 000-12z" fill="rgb(22, 21, 19)"/>'
          );
          t.iconSearch = k;
          const y = U(
            '<path d="M13 22V5.414l5.293 5.293 1.414-1.414L12 1.585 4.293 9.293l1.414 1.414L11 5.414V22h2z" fill="#161513"/>'
          );
          t.iconSend = y;
          const _ = U(
            '<path d="M22 2v20H2V2zm-2 2H4v16h16zm-3 1.674V14a2 2 0 11-2.15-1.995L15 12V8.326l-5 1.428V16a2 2 0 11-2.15-1.995L8 14V8.246z"/>'
          );
          t.iconShareAudio = _;
          const O = U(
            '<path d="M13.414 2L17 5.586V7h.414L21 10.586V22H7v-4H3V2zM17 9.414V18H9v2h10v-8.586zm-2-3L12.586 4H5v12h10zM13 11v2H7v-2zm-2-4v2H7V7z"/>'
          );
          t.iconShareFile = O;
          const M = U(
            '<path d="M12 2c3.874 0 6.994 3.28 6.99 7.214l.011.285c.008.927-.202 2.23-.787 3.837-.96 2.639-2.73 5.452-5.49 8.353L12 22.45l-.724-.761c-2.76-2.901-4.53-5.714-5.49-8.353-.627-1.722-.823-3.095-.782-4.03l.006-.252C5.134 5.147 8.205 2 12 2zm0 2C9.254 4 7.006 6.362 7.002 9.386L7 9.529c-.004.694.168 1.753.667 3.123.741 2.036 2.038 4.221 4.014 6.507l.32.365.32-.365c1.867-2.159 3.127-4.228 3.886-6.166l.128-.34c.535-1.469.694-2.58.664-3.259l-.008-.32C16.879 6.244 14.676 4 12 4zm0 2a3 3 0 1 1-.001 6A3 3 0 0 1 12 6zm0 2a1 1 0 1 0 .001 2A1 1 0 0 0 12 8z"/>'
          );
          t.iconShareLocation = M;
          const j = U(
            '<path d="M22 2v16h-4v4H2V6h4V2zm-9.036 12.378L6.93 20H16v-2.585zM16 8H4v11.999l9.036-8.377L16 14.585zm4-4H8v2h10v10h2zM7 9a2 2 0 110 4 2 2 0 010-4z"/>'
          );
          t.iconShareMedia = j;
          const z = U(
            '<path fill="#161513" d="M2 12C2 6.477 6.477 2 12 2s10 4.477 10 10-4.477 10-10 10S2 17.523 2 12zm15.207-2.793-1.414-1.414L10 13.586l-2.293-2.293-1.414 1.414L10 16.414z"/>'
          );
          t.iconSuccess = z;
          const $ = U(
            '<path d="M1.707.293l22 22-1.414 1.414L12 13.414V21l-6.35-5.114H1V7.954h4.65l.5-.39L.293 1.707zM19.67 4.446c2.119 1.967 3.302 4.613 3.33 7.452a10.363 10.363 0 01-1.392 5.295l-1.476-1.476c.58-1.18.88-2.472.868-3.8-.023-2.29-.981-4.43-2.697-6.025zM7.583 8.996l-1.232.955H3v3.964h3.351L10 16.875v-5.461zm8.051-1.68C17.15 8.547 17.991 10.21 18 11.999c.003.482-.055.956-.17 1.416l-1.86-1.86c-.133-1.017-.691-1.964-1.604-2.706zM12 3v4.586L9.424 5.01z"/>'
          );
          t.iconTTSMute = $;
          const I = U(
            '<path d="M13 3v18l-6.35-5.114H2V7.954h4.65zm5.67 1.446c2.119 1.967 3.302 4.613 3.33 7.452.029 2.904-1.15 5.658-3.316 7.75l-1.396-1.421c1.772-1.71 2.735-3.95 2.712-6.31-.023-2.29-.981-4.43-2.697-6.025zM11 7.125L7.351 9.95H4v3.964h3.351L11 16.875zm4.634.19C17.15 8.548 17.991 10.212 18 12c.01 1.806-.828 3.5-2.358 4.771l-1.284-1.519c1.065-.885 1.65-2.037 1.642-3.242-.006-1.187-.587-2.309-1.634-3.16z"/>'
          );
          t.iconTTSUnmute = I;
          const C = U(
            '<path d="M4 2h10.414L20 7.586V10h-2V9h-5V4H6v16h12v-1h2v3H4zm11 3.414L16.586 7H15z"/><path d="m12.36 17-1.796-4.87h1.18l1.138 3.584 1.153-3.585h1.132L13.37 17zm3.33 0v-4.87h1.046V17zm1.996 0v-4.87h1.635c.795 0 1.396.205 1.802.616.407.41.61 1.018.61 1.822 0 .795-.203 1.4-.61 1.816-.402.41-1.002.616-1.802.616zm1.622-4.02h-.577v3.17h.577c.45 0 .786-.128 1.005-.383.223-.259.335-.659.335-1.2s-.11-.94-.329-1.198c-.218-.26-.556-.389-1.011-.389z"/>'
          );
          t.iconVideo = C;
          const S = U(
            '<path fill="#161513" d="m12 2 10 18H2zm-1 12h2v-4h-2zm0 1v2h2v-2z"/>'
          );
          t.iconWarn = S;
          const T = U(
            '<path d="M11 2a9 9 0 017.032 14.617l3.675 3.676-1.414 1.414-3.676-3.675A9 9 0 1111 2zm0 2a7 7 0 100 14 7 7 0 000-14zm1 3v3h3v2h-3v3h-2v-3H7v-2h3V7z"/>'
          );
          t.iconZoom = T;
          const A = U(
            '<path fill="#161513" fill-rule="evenodd" d="M21.205 6.707 8.998 18.914l-6.707-6.707 1.414-1.414 5.293 5.293L19.791 5.293l1.414 1.414Z" clip-rule="evenodd"/>'
          );
          t.iconCheck = A;
          const E = U(
            '<path fill="#161513" d="M10.998 3c0-.55.45-1 1-1s1 .44 1 1c0 .55-.44 1-.99 1a.999.999 0 0 1-1.01-1Zm0 18c0-.55.45-1 1-1s1 .44 1 1c0 .55-.44 1-.99 1a.999.999 0 0 1-1.01-1Zm11-9c0-.55-.45-1-1-1-.56 0-1 .45-1 1.01 0 .55.45.99 1 .99.56 0 1-.45 1-1Zm-19-1c.55 0 1 .45 1 1s-.44 1-1 1c-.55 0-1-.44-1-.99 0-.56.44-1.01 1-1.01Zm1.93-6.072a1.004 1.004 0 0 0 0 1.415.998.998 0 0 0 1.42-.007.995.995 0 0 0-.007-1.408.997.997 0 0 0-1.414 0Zm12.727 14.143a1.004 1.004 0 0 1 0-1.415.997.997 0 0 1 1.414 0 .995.995 0 0 1 .007 1.408.998.998 0 0 1-1.421.007ZM6.34 17.657a1.003 1.003 0 0 0-1.414 0 .998.998 0 0 0 .007 1.42.994.994 0 0 0 1.407-.005.997.997 0 0 0 0-1.415ZM3.336 9.359a1.004 1.004 0 0 1-.523-1.314.997.997 0 0 1 1.314-.523.995.995 0 0 1 .527 1.305 1 1 0 0 1-1.318.532Zm16.01 5.806a1 1 0 1 0 1.841.782.994.994 0 0 0-.527-1.305.997.997 0 0 0-1.314.523ZM7.52 19.87a1.003 1.003 0 0 1 1.314-.523.996.996 0 0 1 .523 1.314.995.995 0 0 1-1.305.527 1 1 0 0 1-.532-1.318Zm-4.18-5.23a.995.995 0 0 0-.527 1.305 1 1 0 1 0 .527-1.305Zm5.488-9.984a.995.995 0 0 1-1.305-.527.997.997 0 0 1 .523-1.314.999.999 0 1 1 .782 1.841Zm5.814 16.005c.218.505.8.744 1.305.527a.999.999 0 1 0-.782-1.841.997.997 0 0 0-.523 1.314Z"/>'
          );
          t.iconGenerating = E;
          const P = U(
            '<path fill="#161513" d="M3.47 1.667h14.862v9.166h-4.459l-3.333 7.5h-.542c-1.157 0-2.002-.324-2.566-.846-.551-.511-.767-1.152-.767-1.654V12.5H1.5L3.47 1.667Zm10.695 7.5h2.5V3.333h-2.5v5.834Zm-1.667-5.834H4.86l-1.363 7.5h4.835v5c0 .055.034.247.232.43.143.132.412.298.908.369l3.026-6.809v-6.49Z"/>',
            "20"
          );
          t.iconThumbsDown = P;
          const L = U(
            '<path fill="#161513" d="M3.47 18.333h14.862V9.167h-4.459l-3.333-7.5h-.542c-1.157 0-2.002.324-2.566.847-.551.51-.767 1.151-.767 1.653V7.5H1.5l1.97 10.833Zm10.695-7.5h2.5v5.834h-2.5v-5.834Zm-1.667 5.834H4.86l-1.363-7.5h4.835v-5c0-.055.034-.247.232-.43.143-.132.412-.298.908-.369l3.026 6.809v6.49Z"/>',
            "20"
          );
          t.iconThumbsUp = L;
          const F = U(
            '<path fill="#C74634" d="M3.345 2.5c-.92 0-1.679.74-1.679 1.66v12.5c0 .5.34.84.84.84h.499c.26 0 .42-.08.58-.24l2.577-2.6c.34-.32.76-.5 1.18-.5h9.312c.92 0 1.679-.74 1.679-1.66V4.16c0-.92-.76-1.66-1.679-1.66H3.344Zm3.317 5.84c0 .92-.74 1.66-1.659 1.66s-1.658-.74-1.658-1.66c0-.92.74-1.68 1.658-1.68.92 0 1.659.76 1.659 1.68Zm4.996 0c0 .92-.74 1.66-1.659 1.66s-1.658-.74-1.658-1.66c0-.92.74-1.68 1.658-1.68.92 0 1.659.76 1.659 1.68Zm4.996 0c0 .92-.74 1.66-1.659 1.66s-1.658-.74-1.658-1.66c0-.92.74-1.68 1.658-1.68.92 0 1.659.76 1.659 1.68Z"/>',
            "20"
          );
          t.iconInlineLaunch = F;
          const N = U(
            '<path fill="#C74634" d="M2.677 2c-.736 0-1.343.592-1.343 1.328v10c0 .4.272.672.671.672h.4a.591.591 0 0 0 .464-.192l2.062-2.08c.272-.256.608-.4.943-.4h7.45c.736 0 1.343-.592 1.343-1.328V3.328c0-.736-.607-1.328-1.343-1.328H2.677ZM5.33 6.672C5.33 7.408 4.739 8 4.004 8a1.324 1.324 0 0 1-1.327-1.328c0-.736.591-1.344 1.327-1.344.735 0 1.327.608 1.327 1.344Zm3.997 0C9.328 7.408 8.736 8 8 8a1.324 1.324 0 0 1-1.327-1.328c0-.736.591-1.344 1.327-1.344.735 0 1.327.608 1.327 1.344Zm3.996 0c0 .736-.591 1.328-1.326 1.328a1.324 1.324 0 0 1-1.327-1.328c0-.736.591-1.344 1.327-1.344.735 0 1.326.608 1.326 1.344Z"/>',
            "16"
          );
          t.iconInlineLogo = N;
          const R = U(
            '<path fill="#8F520A" d="M1.332 14.667 7.998 1.333l6.667 13.334H1.332Zm6-7.334V10h1.333V7.333H7.332Zm0 4v1.334h1.333v-1.334H7.332Z"/>',
            "16"
          );
          t.iconInlineError = R;
          const D = U(
            '<path fill="#211e1c" fill-rule="evenodd" d="M10.364 4c4.665 0 8.492 3.29 8.632 7.747L19 12v1.585l1.293-1.292 1.414 1.414L18 17.414l-3.707-3.707 1.414-1.414L17 13.585V12c0-3.419-2.935-6-6.636-6C6.853 6 4 8.906 4 12.5S6.853 19 10.364 19a6.243 6.243 0 0 0 3.764-1.258l.228-.18 1.272 1.544A8.25 8.25 0 0 1 10.364 21C5.74 21 2 17.19 2 12.5 2 7.81 5.74 4 10.364 4z"/>'
          );
          t.iconStartOver = D;
          const H = U('<path d="M3 3h18v18H3zm2 2v14h14V5z"/>');
          function U(e, t) {
            return `<svg xmlns="http://www.w3.org/2000/svg" height="20" width="20" viewBox="0 0 ${
              t || "24"
            } ${t || "24"}">${e}</svg>`;
          }
          t.iconStop = H;
        },
        8291: (e, t, s) => {
          Object.defineProperty(t, "p", { value: !0 }),
            (t.syncTTSLocaleIfUnavailable =
              t.isSVG =
              t.isInteger =
              t.convertBreakTagsToNewLines =
                void 0),
            (t.addDefaultSettings = function (e) {
              const t = Object.assign(Object.assign({}, a.defaultSettings), e);
              e.i18n &&
                Object.keys(e.i18n).length &&
                (t.i18n = k(a.defaultSettings.i18n, e.i18n));
              (t.colors = Object.assign(
                Object.assign({}, a.defaultSettings.colors),
                e.colors
              )),
                (t.userId = e.userId || (0, o.generateID)({ prefix: "user" })),
                (t.icons = (function (e) {
                  const t = e.icons || {};
                  for (const s in v) {
                    const i = s,
                      o = v[i];
                    o in e && (t[i] = e[o]);
                  }
                  return t;
                })(t)),
                (t.locale = b(t.locale, t.i18n)),
                e.typingStatusInterval &&
                  e.typingStatusInterval <
                    a.defaultSettings.typingStatusInterval &&
                  (t.typingStatusInterval =
                    a.defaultSettings.typingStatusInterval);
              t.enableVoiceOnlyMode &&
                ((t.enableBotAudioResponse = !0),
                (t.initBotAudioMuted = !1),
                (t.enableSpeech = !0));
              if (!t.position) {
                const e =
                  "rtl" === window.getComputedStyle(document.body).direction;
                t.position = e
                  ? { left: "20px", bottom: "20px" }
                  : { right: "20px", bottom: "20px" };
              }
              return t;
            }),
            (t.configureColorCustomization = function (e, t) {
              if (e) {
                const s = ["headerBackground", "visualizer", "ratingStarFill"],
                  i = ["botText", "userText"],
                  o = Object.assign({}, e);
                s.forEach((t) => {
                  o[t] = e[t] || e.branding;
                }),
                  i.forEach((t) => {
                    o[t] = e[t] || e.text;
                  }),
                  Object.keys(o).forEach((e) => {
                    const s = o[e];
                    if (s)
                      if ("shareMenuText" === e)
                        t.updateCSSVar("--color-popup-button-text", s);
                      else {
                        const i = `--color-${e
                          .replace(/([A-Z&])/g, "-$1")
                          .toLowerCase()}`;
                        t.updateCSSVar(i, s);
                      }
                  });
              }
            }),
            (t.configureLocale = b),
            (t.debounce = function (e, t) {
              let s;
              return function () {
                const i = this,
                  o = arguments;
                clearTimeout(s),
                  (s = setTimeout(function () {
                    (s = null), e.apply(i, o);
                  }, t));
              };
            }),
            (t.getColor = function (e, t) {
              const s = document.querySelector(`.${t}-wrapper`);
              return getComputedStyle(s).getPropertyValue(e);
            }),
            (t.getFieldInputValues = function (e) {
              const t = {};
              e &&
                Object.keys(e).forEach((s) => {
                  var i;
                  t[s] =
                    null === (i = document.getElementById(e[s])) || void 0 === i
                      ? void 0
                      : i.value;
                });
              return t;
            }),
            (t.getFooterFormComponent = function (e, t, s, o) {
              const a = r.MessageComponentFactory.fromMessage(
                s,
                e,
                { messagePayload: { type: i.MessageType.Form, forms: [t] } },
                o
              );
              return (a.onActionClick = o.onMessageActionClicked), a;
            }),
            (t.getFormShareText = f),
            (t.getPopupContent = function (e, t, s, a) {
              const c = "none",
                h = e.createDiv(["wrapper", "popup-content-wrapper", c]),
                d = e.createDiv(["popup-dialog"]),
                p = r.MessageComponentFactory.fromMessage(
                  s,
                  e,
                  { messagePayload: t },
                  a
                ),
                u = p.render(),
                g = u.querySelector(
                  `.${s.name}-form-message-header:first-child`
                ),
                m = e.createIconButton({
                  css: ["header-button"],
                  icon: s.icons.close || l.iconClose,
                  iconCss: [],
                  title: "close",
                });
              if (
                ((0, n.on)(m, "click", () => e.addCSSClass(h, c)),
                (h.tabIndex = 0),
                (p.onActionClick = (t) => {
                  (t.type !== i.ActionType.SubmitForm || p.validateForm()) &&
                    (e.addCSSClass(h, c), a.onMessageActionClicked(t));
                }),
                (0, n.on)(h, "click", (t) => {
                  d.contains(t.target) || e.addCSSClass(h, c);
                }),
                (0, n.on)(h, "keyup", (t) => {
                  t.code === o.KeyCode.Esc &&
                    (e.addCSSClass(h, c), t.stopPropagation());
                }),
                g)
              )
                g.appendChild(m);
              else {
                const t = e.createDiv(["popup-header", "flex"]);
                t.appendChild(m), d.appendChild(t);
              }
              return d.appendChild(u), h.appendChild(d), h;
            }),
            (t.getShareText = function (e) {
              let t = h;
              switch (e.type) {
                case i.MessageType.Card:
                  return (
                    e.cards.forEach((e) => {
                      var s;
                      t += `${
                        (e.title ? `${e.title} - ` : h) +
                        (e.description ? `${e.description} - ` : h) +
                        (null !== (s = e.url) && void 0 !== s ? s : h)
                      }\n`;
                    }),
                    t
                  );
                case i.MessageType.Text:
                  return e.text;
                case i.MessageType.Attachment:
                  return e.attachment.url;
                case i.MessageType.Location:
                  const s = e.location;
                  return `${s.title ? `${s.title} - ` : h}${s.latitude}, ${
                    s.longitude
                  }`;
                case i.MessageType.Table:
                  e.rows.forEach((e) => {
                    e.fields.forEach((e) => {
                      t += w(e);
                    });
                  });
                  break;
                case i.MessageType.Form:
                  e.forms.forEach((e) => {
                    const s = f(e);
                    t += s ? `${s} - ` : h;
                  });
                  break;
                case i.MessageType.EditForm:
                  const o = e;
                  (t = o.title ? `${o.title} - ` : h),
                    (0, i.isEditFormPayloadWithFields)(o)
                      ? o.fields.forEach((e) => {
                          t += w(e);
                        })
                      : o.formRows.forEach((e) => {
                          e.columns.forEach((e) => {
                            e.fields.forEach((e) => {
                              t += w(e);
                            });
                          });
                        });
                  break;
                case i.MessageType.TableForm:
                  const r = e;
                  r.rows.forEach((e, s) => {
                    e.fields.forEach((e) => {
                      t += w(e);
                    }),
                      (t += f(r.forms[s]));
                  });
              }
              return y(t);
            }),
            (t.isAnyVoiceAvailable = function (e, t) {
              if (!t) return Promise.resolve(!1);
              Array.isArray(t) || (t = [t]);
              if (!t.length) return Promise.resolve(!1);
              const s = t.map((e) => {
                var t;
                return null === (t = e.lang) || void 0 === t
                  ? void 0
                  : t.toLowerCase();
              });
              return e.getVoices().then((e) => {
                let t = !1;
                const i = e.map((e) => e.lang.toLowerCase());
                for (const e of s)
                  if (i.indexOf(e) >= 0) {
                    t = !0;
                    break;
                  }
                return t;
              });
            }),
            (t.isFeedbackComponent = function (e) {
              return void 0 !== e.ratingId;
            }),
            (t.matchStringIgnoreCase = function (e, t) {
              const s = e.toLowerCase(),
                i = t.toLowerCase();
              return s === i;
            }),
            (t.mergeTranslationStrings = k),
            (t.sanitizeText = function (e) {
              return (
                p.forEach((t) => {
                  e = e.replace((0, o.resetRegex)(t.match), t.replace);
                }),
                e
              );
            }),
            (t.setAttributes = function (e, t) {
              for (const [s, i] of Object.entries(t)) e.setAttribute(s, i);
            }),
            (t.setEmbeddedLinksHandler = function e(t, s) {
              for (let i = 0; i < t.childElementCount; i++) {
                const o = t.children[i];
                if ("a" === o.tagName.toLowerCase()) {
                  const e = o;
                  (e.rel = "noreferrer noopener"),
                    s.onclick && (e.onclick = s.onclick.bind(e)),
                    s.target && (e.target = s.target);
                }
                o.hasChildNodes() && e(o, s);
              }
            }),
            (t.setLinksOpenInNewWindow = function e(t) {
              for (let s = 0; s < t.childElementCount; s++) {
                const i = t.children[s];
                "a" === i.tagName.toLowerCase() &&
                  (i.onclick = (e) => (
                    window.open(
                      i.href,
                      h,
                      "height=450px,width=800px,menubar,toolbar,personalbar,status,resizable,noopener,noreferrer"
                    ),
                    e.preventDefault(),
                    e.stopPropagation(),
                    !1
                  )),
                  i.hasChildNodes() && e(i);
              }
            }),
            (t.throttle = function (e, t) {
              let s = !1;
              return function () {
                const i = this;
                s ||
                  (e.apply(i, arguments),
                  (s = !0),
                  setTimeout(() => {
                    s = !1;
                  }, t));
              };
            }),
            (t.updatePosition = function (e, t) {
              t.updateCSSVar("--position-top", e.top || "unset"),
                t.updateCSSVar("--position-left", e.left || "unset"),
                t.updateCSSVar("--position-right", e.right || "unset"),
                t.updateCSSVar("--position-bottom", e.bottom || "unset"),
                e.bottom &&
                  t.updateCSSVar(
                    "--widget-max-height",
                    `calc(100vh - 60px - ${e.bottom})`
                  );
            });
          const i = s(6246),
            o = s(6064),
            r = s(5430),
            a = s(865),
            n = s(3010),
            c = s(2436),
            l = s(1660),
            h = "";
          t.isInteger = (e) =>
            "number" == typeof e && isFinite(e) && Math.floor(e) === e;
          t.isSVG = (e) => {
            const t = e.match(/<svg\s/gi);
            return t && t.length > 0;
          };
          const d = /<br\s*\/?>/g;
          t.convertBreakTagsToNewLines = (e) => e.replace(d, "\n");
          const p = [
            { match: /<([a-z])/gi, replace: (e, t) => `&#x3c;${t}` },
            { match: /<\/([a-z])/gi, replace: (e, t) => `&#x3c;&#47;${t}` },
          ];
          const u = (() => {
            let e = !1;
            return (
              t = {
                hasRecognition: !1,
                hasSynthesis: !1,
                isReset: !1,
                recognitionLocale: h,
                synthesisLocales: [],
              }
            ) => {
              var s;
              t.isReset && (e = !1);
              let i = t.synthesisLocales;
              return (
                Array.isArray(i) || (i = []),
                t.hasRecognition &&
                  t.hasSynthesis &&
                  (null === (s = t.recognitionLocale) || void 0 === s
                    ? void 0
                    : s.length) &&
                  ((!e && t.synthesisLocales.length) ||
                    ((e = !0), (i = [{ lang: t.recognitionLocale }]))),
                i
              );
            };
          })();
          function g(e, t) {
            const s = e.toLowerCase();
            for (const e in t) if (s === e.toLowerCase()) return !0;
            return !1;
          }
          function m(e, t) {
            const s = e.toLowerCase().split("-")[0];
            for (const e in t) if (s === e.toLowerCase()) return !0;
            return !1;
          }
          function b(e, t) {
            let s = [e.toLowerCase()],
              i = "en";
            (s = s.concat((0, c.getLocales)())), s.indexOf(i) < 0 && s.push(i);
            for (const e of s) {
              if (g(e, t)) {
                i = e;
                break;
              }
              if (m(e, t)) {
                i = e.split("-")[0];
                break;
              }
            }
            return i;
          }
          function f(e, t = !1) {
            let s = e.title ? `${e.title} - ` : h;
            return (
              (0, i.isFormEntityWithFields)(e)
                ? e.fields.forEach((e) => {
                    s += w(e);
                  })
                : e.formRows.forEach((e) => {
                    e.columns.forEach((e) => {
                      e.fields.forEach((e) => {
                        (0, i.isReadOnlyField)(e) && (s += w(e));
                      });
                    });
                  }),
              t ? y(s) : s
            );
          }
          function w(e) {
            const t = e.value || e.label;
            return t ? `${t} - ` : h;
          }
          t.syncTTSLocaleIfUnavailable = u;
          const v = {
            avatarAgent: "agentAvatar",
            avatarBot: "botIcon",
            avatarUser: "personIcon",
            fileAudio: "audioIcon",
            fileImage: "imageIcon",
            fileGeneric: "fileIcon",
            fileVideo: "videoIcon",
            clearHistory: "clearMessageIcon",
            close: void 0,
            collapse: "closeIcon",
            download: "downloadIcon",
            error: "errorIcon",
            expandImage: "expandImageIcon",
            keyboard: "keyboardIcon",
            logo: "logoIcon",
            launch: "botButtonIcon",
            mic: "micIcon",
            rating: void 0,
            send: "sendIcon",
            shareMenu: "attachmentIcon",
            shareMenuAudio: void 0,
            shareMenuFile: void 0,
            shareMenuLocation: void 0,
            shareMenuVisual: void 0,
            ttsOff: "audioResponseOffIcon",
            ttsOn: "audioResponseOnIcon",
            typingIndicator: "chatBubbleIcon",
          };
          function x(e) {
            const t = {},
              s = Object.keys(e);
            for (const i of s) t[i.toLowerCase()] = e[i];
            return t;
          }
          function k(e, t) {
            (e = x(e)), (t = x(t));
            const s = new Set();
            Object.keys(e).forEach((e) => {
              s.add(e);
            }),
              Object.keys(t).forEach((e) => {
                s.add(e);
              });
            const i = {};
            return (
              s.forEach((s) => {
                i[s] = Object.assign(
                  Object.assign(Object.assign({}, e.en), e[s]),
                  t[s]
                );
              }),
              i
            );
          }
          function y(e) {
            return e.length ? e.slice(0, e.length - 3) : e;
          }
        },
        2436: (e, t) => {
          Object.defineProperty(t, "p", { value: !0 }),
            (t.isStorageAvailable = t.getLocales = t.getBrowserLocale = void 0);
          t.getBrowserLocale = () => navigator.language.toLowerCase();
          t.getLocales = () => {
            var e;
            return (
              (null === (e = navigator.languages) || void 0 === e
                ? void 0
                : e.map((e) => e.toLowerCase())) || []
            );
          };
          t.isStorageAvailable = (e) => s(e);
          const s = (e) => {
            let t;
            try {
              t = window[e];
              const s = "__storage_test__";
              return t.setItem(s, s), t.removeItem(s), !0;
            } catch (e) {
              return (
                e instanceof DOMException &&
                (22 === e.code ||
                  1014 === e.code ||
                  "QuotaExceededError" === e.name ||
                  "NS_ERROR_DOM_QUOTA_REACHED" === e.name) &&
                t &&
                0 !== t.length
              );
            }
          };
        },
        4413: (e, t, s) => {
          Object.defineProperty(t, "p", { value: !0 }),
            (t.AlertDialog = void 0);
          const i = s(6064),
            o = s(8098);
          t.AlertDialog = class {
            constructor(e) {
              (this.qt = e),
                (this.Yt = !1),
                (this.Jt = (e) => {
                  h(e) ||
                    (e.code === i.KeyCode.Esc &&
                      (this.close(), e.stopPropagation()));
                }),
                (this.Kt = (e) => {
                  h(e) ||
                    (e.code === i.KeyCode.Tab &&
                      (e.target !== this.Xt || e.shiftKey
                        ? e.target === this.Qt &&
                          e.shiftKey &&
                          (e.preventDefault(), this.Xt.focus())
                        : (e.preventDefault(), this.Qt.focus())));
                });
            }
            open() {
              if (this.Yt) return;
              const { parent: e, autoDismiss: t } = this.qt;
              if (
                ((this.ts = document.activeElement),
                (this.Yt = !0),
                e.append(this.render()),
                this.os(),
                this.rs(),
                t)
              ) {
                setTimeout(() => {
                  this.close();
                }, 1e4);
              }
            }
            close() {
              if (!this.Yt) return;
              const { domUtil: e, fallbackFocus: t } = this.qt,
                s = "dialog-out";
              e.addCSSClass(this.ns, s),
                setTimeout(() => {
                  this.cs(),
                    e.removeCSSClass(this.ns, s),
                    this.ls.remove(),
                    this.ts && this.ts.offsetParent ? this.ts.focus() : t(),
                    (this.Yt = !1);
                }, 200);
            }
            render() {
              const {
                  title: e,
                  description: t,
                  domUtil: s,
                  icon: i,
                  actions: a,
                  showDismiss: n,
                  dismissLabel: h,
                  modeless: d,
                } = this.qt,
                p = "dialog",
                u = s.createDiv.bind(s),
                g = s.cssPrefix,
                m = u([`${p}-wrapper`]);
              let b;
              d && s.addCSSClass(m, "modeless"),
                d || (b = u([`${p}-backdrop`]));
              const f = u([`${p}-icon-content-wrapper`, "flex"]),
                w = u([`${p}-content`]),
                v = u([p, "flex"]);
              if ((d || s.addCSSClass(v, "col"), i)) {
                const e = s.createImageIcon({ icon: i }),
                  t = u([`${p}-icon`]);
                l(t, e), l(f, t);
              }
              const x = `${p}-title`,
                k = s.createTextDiv([x]);
              if (((k.id = `${g}-${x}`), (k.textContent = e), l(w, k), t)) {
                const e = `${p}-description`,
                  i = s.createTextDiv([e]);
                (i.id = `${g}-${e}`),
                  (i.textContent = t),
                  l(w, i),
                  v.setAttribute("aria-describedby", i.id);
              }
              if ((l(f, w), l(v, f), n)) {
                const e = `${p}-close-button`,
                  t = s.createIconButton({
                    css: [e],
                    icon: o.iconClose,
                    title: h,
                    iconCss: [`${e}-icon`],
                  });
                (0, o.on)(t, c, this.close.bind(this)), l(v, t);
              }
              if (a && a.length) {
                const e = u(["action-wrapper", "flex"]);
                a.forEach((t) => {
                  const i = ["popup-action"];
                  t.type === r && i.push(r);
                  const a = s.createButton(i);
                  (a.innerHTML = t.label),
                    (0, o.on)(a, c, (e) => {
                      t.handler(e);
                    }),
                    e.appendChild(a);
                }),
                  l(v, e);
              }
              return (
                d || l(m, b),
                l(m, v),
                (0, o.setAttributes)(v, {
                  role: "alertDialog",
                  "aria-modal": (!d).toString(),
                  "aria-labelledby": k.id,
                }),
                (this.ns = v),
                (this.ls = m),
                this.hs(v),
                m
              );
            }
            hs(e) {
              const t = e.querySelectorAll(
                "[tabIndex]:not([tabIndex^='-']), button"
              );
              (this.Qt = t[0]), (this.Xt = t[t.length - 1]);
            }
            os() {
              this.Qt.focus();
            }
            rs() {
              const e = this.ns;
              (0, o.on)(e, a, this.Kt), (0, o.on)(e, n, this.Jt);
            }
            cs() {
              const e = this.ns;
              (0, o.off)(e, a, this.Kt, !0), (0, o.off)(e, n, this.Jt, !0);
            }
          };
          const r = "filled",
            a = "keydown",
            n = "keyup",
            c = "click",
            l = (e, ...t) => {
              e.append(...t);
            },
            h = (e) => e.ctrlKey || e.metaKey || e.altKey;
        },
        7739: (e, t, s) => {
          Object.defineProperty(t, "p", { value: !0 }),
            (t.CancelResponseComponent = void 0);
          const i = s(8098),
            o = s(4557),
            r = s(9780);
          class a extends o.Component {
            constructor(e) {
              super(),
                (this.U = e),
                (this.ds = new r.Logger("CancelResponseComponent")),
                (this.ps = !1),
                (this.us = () => {
                  this.U.onClick(), this.hide();
                }),
                this.render();
            }
            show() {
              if (!this.ps) {
                this.ps = !0;
                try {
                  this.appendToElement(this.U.parent);
                } catch (e) {
                  this.ds.debug("No parent to add cancel response button");
                }
              }
            }
            hide() {
              if (!this.ps) return;
              this.ps = !1;
              const { domUtil: e } = this.U,
                t = this.element;
              e.addCSSClass(t, c),
                setTimeout(() => {
                  e.removeCSSClass(t, c), this.remove();
                }, n),
                this.U.onHide();
            }
            isVisible() {
              return this.ps;
            }
            focus() {
              const e = this.element;
              (e.contentEditable = "true"),
                e.focus(),
                (e.contentEditable = "false");
            }
            render() {
              const { domUtil: e, i18n: t } = this.U;
              if (this.element)
                return void (this.element.title = t.cancelResponse);
              const s = "cancel-response-button",
                o = e.createIconButton({
                  css: [s],
                  icon: i.iconStop,
                  iconCss: [`${s}-icon`],
                  title: t.cancelResponse,
                });
              (0, i.on)(o, "click", this.us), (this.element = o);
            }
            setLocale(e) {
              (this.U.i18n = e), this.render();
            }
          }
          t.CancelResponseComponent = a;
          const n = 210,
            c = "hide";
        },
        28: function (e, t, s) {
          var i =
            (this && this.v) ||
            function (e, t, s, i) {
              return new (s || (s = Promise))(function (o, r) {
                function a(e) {
                  try {
                    c(i.next(e));
                  } catch (e) {
                    r(e);
                  }
                }
                function n(e) {
                  try {
                    c(i.throw(e));
                  } catch (e) {
                    r(e);
                  }
                }
                function c(e) {
                  var t;
                  e.done
                    ? o(e.value)
                    : ((t = e.value),
                      t instanceof s
                        ? t
                        : new s(function (e) {
                            e(t);
                          })).then(a, n);
                }
                c((i = i.apply(e, t || [])).next());
              });
            };
          Object.defineProperty(t, "p", { value: !0 }),
            (t.rejectErrorTextStream = t.WidgetComponent = void 0);
          const o = s(6246),
            r = s(5229),
            a = s(6064),
            n = s(8098),
            c = s(2366),
            l = s(9780),
            h = s(5915),
            d = s(2854),
            p = s(4413),
            u = s(4557),
            g = s(7739),
            m = s(4810),
            b = window.BroadcastChannel,
            f = "collapsed",
            w = "expanded",
            v = "large",
            x = "none",
            k = window.setTimeout,
            y = [
              o.MessageType.Suggest,
              o.MessageType.SessionClosed,
              o.MessageType.CloseSession,
              o.MessageType.Status,
            ],
            _ = [
              o.MessageType.Text,
              o.MessageType.Attachment,
              o.MessageType.Location,
              o.MessageType.FormSubmission,
            ];
          class O extends u.Component {
            constructor(e, t, s) {
              var i, r, d;
              super(),
                (this.skillMessages = []),
                (this.contextWidgetMap = {}),
                (this.gs = []),
                (this.ds = new l.Logger("ChatComponent")),
                (this.bs = []),
                (this.fs = 0),
                (this.ws = []),
                (this.vs = !0),
                (this.xs = !0),
                (this.ks = !1),
                (this.ys = !1),
                (this._s = !1),
                (this.Os = !0),
                (this.Ms = !1),
                (this.js = []),
                (this.zs = !1),
                (this.$s = 1e4),
                (this.Is = new Map()),
                (this.Cs = !1),
                (this.Ss = ""),
                (this.Ts = () => {
                  const e = this.As.searchBarMode
                    ? this.Es.element
                    : this.Ps.element;
                  (0, a.isVisible)(e) &&
                    ((this.Cs = !0),
                    this.Ps.setRecognitionRequested(!0),
                    this.Ps.setVoiceRecording(!0),
                    this.Ls(),
                    (this.Ss = (0, n.getColor)(
                      "--color-visualizer",
                      this.As.name
                    )));
                }),
                (this.Fs = () => {
                  (this.Cs = !1), this.Ps.setVoiceRecording(!1);
                }),
                (this.Ns = (e) => {
                  const t = this.Rs;
                  let s = "";
                  switch (null == e ? void 0 : e.message) {
                    case o.CoreError.RecognitionMultipleConnection:
                      s = t.errorSpeechMultipleConnection;
                      break;
                    case o.CoreError.RecognitionNotReady:
                      s = t.errorSpeechInvalidUrl;
                      break;
                    case o.CoreError.RecognitionTooMuchSpeechTimeout:
                    case o.CoreError.RecognitionProcessingFailure:
                      s = t.errorSpeechTooMuchTimeout;
                      break;
                    default:
                      s = t.errorSpeechUnavailable;
                  }
                  this.Ds(s, n.iconWarn), this.Fs();
                }),
                (this.Hs = (e) => {
                  this.Cs && this.Us(e);
                }),
                (this.Vs = (e) => {
                  this.Cs && this.Ps.updateVisualizer(e, this.Ss);
                }),
                (this.Bs = (e) => {
                  this.ds.warn("[sendMessage] Failed to send message", e);
                }),
                (this.Ws = () => {
                  (this.Zs = null),
                    "action" !== this.As.focusOnNewMessage &&
                      this.Ps.focusTextArea();
                }),
                (this.Gs = () => {
                  const e = this.Zs;
                  e && (this.qs.add(e), this.Ys.cancelRequest(e)),
                    this.Js(),
                    this.Ks(),
                    this.Xs(),
                    this.hideTypingIndicator(),
                    this.Ps.disable(!1);
                }),
                (this.Ys = e),
                (this.As = t),
                (this.ye =
                  s && (0, a.isFunction)(s.connect)
                    ? s.connect
                    : () => {
                        this.Ys.connect().catch((e) =>
                          this.ds.error("Failed to connect to backend:", e)
                        );
                      }),
                (this.Qs =
                  s && (0, a.isFunction)(s.openChat) ? s.openChat : () => {}),
                (this.ei =
                  s && (0, a.isFunction)(s.closeChat) ? s.closeChat : () => {}),
                (this.ti =
                  (null == s ? void 0 : s.eventDispatcher) ||
                  (0, a.generateEventDispatcher)()),
                (this.si =
                  s && (0, a.isFunction)(s.handleSessionEnd)
                    ? s.handleSessionEnd
                    : () => {}),
                (this.ii =
                  s && (0, a.isFunction)(s.receivedMessage)
                    ? s.receivedMessage
                    : (e) => {
                        this.ti.trigger(n.ChatEvent.MESSAGE_RECEIVED, e),
                          this.ti.trigger(n.ChatEvent.MESSAGE, e);
                      }),
                (this.oi =
                  s && (0, a.isFunction)(s.sentMessage)
                    ? s.sentMessage
                    : (e) => {
                        this.ti.trigger(n.ChatEvent.MESSAGE_SENT, e),
                          this.ti.trigger(n.ChatEvent.MESSAGE, e);
                      }),
                (this.ri =
                  s && (0, a.isFunction)(s.onConnectionStatusChange)
                    ? s.onConnectionStatusChange
                    : () => {}),
                (this.ai =
                  s && (0, a.isFunction)(s.getUnreadMessagesCount)
                    ? s.getUnreadMessagesCount
                    : () => this.getUnreadMsgsCount()),
                (this.ni =
                  (null == s ? void 0 : s.util) || new n.DOMUtil(this.As)),
                (this.zt = this.As.name),
                (this.ci = this.As.locale),
                (this.Rs = Object.assign(
                  Object.assign({}, this.As.i18n.en),
                  this.As.i18n[this.As.locale]
                )),
                (this.isOpen = !1),
                (this.ys =
                  "init" ===
                    (null === (i = this.As.initMessageOptions) || void 0 === i
                      ? void 0
                      : i.sendAt) ||
                  this.As.openChatOnLoad ||
                  this.As.embedded),
                (this.ks = this.As.enableHeadless),
                (this.li =
                  !this.As.embedded &&
                  !this.As.sidepanel &&
                  this.As.enableResizableWidget),
                (this.di = this.As.enableDefaultClientResponse),
                (this.pi =
                  this.As.enableLocalConversationHistory &&
                  this.As.storageType !== l.StorageType.CUSTOM),
                (this.ui = "default"),
                (this.gi = {
                  webviewLinkHandler: this.mi,
                  webCore: this.Ys,
                  onMessageActionClicked:
                    this.onMessageActionClicked.bind(this),
                }),
                this.As.enableTabsSync || (this.bi = () => {}),
                this.As.threadId &&
                  ((this.st = this.As.threadId),
                  this.Ys.setCurrentThreadId(this.As.threadId)),
                (this.fi = () => this.wi()),
                (this.xi = (e) => this.ki(e)),
                (this.yi = (e) => {
                  var t;
                  if (!(0, l.isBotMessage)(e)) return;
                  const {
                    endOfTurn: s,
                    messagePayload: i,
                    requestId: r,
                    threadId: a,
                  } = e;
                  if (this.qs.has(r)) return;
                  s && (null === (t = this._i) || void 0 === t || t.hide());
                  const n = Boolean(
                    null == a
                      ? void 0
                      : a.startsWith(`${o.ContextSource.UIWidget}:`)
                  );
                  let c;
                  if ((n && (c = this.contextWidgetMap[a]), i)) {
                    if (
                      i.type === o.MessageType.ExecuteApplicationActionCommand
                    ) {
                      const e = i;
                      return (
                        n ? c.showFullSizeWidget() : this.Oi(Boolean(s)),
                        void this.ti.trigger(e.actionType, e)
                      );
                    }
                    if (n) c.onMessageReceived(e);
                    else {
                      const t =
                        i.type === o.MessageType.Command &&
                        "noReply" === i.command;
                      a !== this.st
                        ? this.Mi(a).then(() => {
                            t || this.ji(e);
                          })
                        : t || this.ji(e);
                    }
                  } else console.warn("Message Payload Not available");
                }),
                this.Ys.on(o.CoreEvent.Open, this.fi),
                this.Ys.on(o.CoreEvent.State, this.xi),
                this.Ys.on(o.CoreEvent.MessageReceived, this.yi),
                this.Ys.on(o.CoreEvent.ASRStart, this.Ts),
                this.Ys.on(o.CoreEvent.ASRStop, this.Fs),
                this.Ys.on(o.CoreEvent.ASRError, this.Ns),
                this.Ys.on(o.CoreEvent.ASRResponse, this.Hs),
                this.Ys.on(o.CoreEvent.ASRVisualData, this.Vs),
                this.As.enableVoiceOnlyMode &&
                  ((this.zi = () => this.$i(!0, this.As.enableVoiceOnlyMode)),
                  this.Ys.on(o.CoreEvent.TTSStop, this.zi)),
                this.As.enableBotAudioResponse &&
                  (this.xs = this.As.initBotAudioMuted),
                this.As.searchBarMode
                  ? ((this.Es = new m.SearchBarWidgetComponent(
                      this.As,
                      this.ni,
                      this.Ys,
                      this,
                      this.ye,
                      this.ti
                    )),
                    (this.Ps = this.Es.footer),
                    (this.Ii = this.Es.typingIndicator),
                    (this.Ls = () => {}),
                    (this.updateNotificationBadge = () => {}),
                    (this.Ci = () => {}),
                    (this.Si = () => {}))
                  : ((this.Ti = new c.ChatHeaderComponent(
                      this.As,
                      this.ni,
                      null === (r = this.ei) || void 0 === r
                        ? void 0
                        : r.bind(this),
                      this.clearConversationHistory.bind(this),
                      this.onToggleNarration.bind(this),
                      this.Ys,
                      this.Ai.bind(this),
                      this.Ei.bind(this),
                      this
                    )),
                    (this.Ps = new c.ChatFooterComponent(
                      this.ni,
                      this.sendMessage.bind(this),
                      this.uploadFile.bind(this),
                      this.As,
                      this.getSuggestions.bind(this),
                      this.$i.bind(this),
                      this.Pi.bind(this),
                      this.Li.bind(this),
                      this.ti,
                      this,
                      this.Ei.bind(this)
                    )),
                    this.As.showTypingIndicator &&
                      (this.Ii = new h.TypingIndicatorComponent(
                        h.MESSAGE_SIDE.LEFT,
                        this.As,
                        this.ni
                      )),
                    !this.As.enableTimestamp ||
                    ("relative" !== this.As.timestampMode &&
                      "default" !== this.As.timestampMode)
                      ? ((this.Si = () => {}), (this.Ci = () => {}))
                      : (this.Fi = new h.RelativeTimestampComponent(
                          this.As,
                          this.ni
                        ))),
                "action" !==
                  (null === (d = this.As.focusOnNewMessage) || void 0 === d
                    ? void 0
                    : d.toLowerCase()) && (this.Ni = () => {}),
                this.configureStorage(),
                this.Ri(),
                this.Ys.isConnected() && this.wi();
            }
            render() {
              const e = this.As,
                t = this.ni;
              "undefined" != typeof window &&
                (this.Di(),
                (0, n.updatePosition)(e.position, t),
                e.font && t.updateCSSVar("font", e.font),
                e.fontFamily && t.updateCSSVar("font-family", e.fontFamily),
                e.fontSize && t.updateCSSVar("font-size", e.fontSize)),
                e.searchBarMode
                  ? (this.Hi = this.Es.render())
                  : ((this.element = this.Ui()),
                    this.Vi(),
                    e.multiLangChat && this.Bi()),
                this.Wi(e),
                this.Zi(),
                this.ki(this.Ys.getState());
            }
            embedInElement(e) {
              const t = document.getElementById(e);
              if (!t) throw new Error("Can not embed chat widget.");
              this.ni.addCSSClass(t, "wrapper", this.As.theme, "embedded"),
                this.appendToElement(t);
            }
            showChat() {
              if (!this.isOpen) {
                const e = this.ni;
                e.removeCSSClass(this.element, f),
                  e.addCSSClass(this.element, w),
                  e.removeCSSClass(this.chatWidgetDiv, x),
                  this.As.embedded ||
                    k(() => {
                      e.addCSSClass(this.Gi, x);
                    }, 250),
                  (this.isOpen = !0),
                  (this.ys = !0),
                  this.updateNotificationBadge(0),
                  this.Ls(),
                  this.Ps.focusTextArea(),
                  this.wi();
              }
            }
            onClose() {
              if (this.isOpen) {
                const e = this.ni;
                this.Js(),
                  e.removeCSSClass(this.element, w),
                  e.addCSSClass(this.element, f),
                  this.As.embedded ||
                    (e.removeCSSClass(this.Gi, x),
                    k(() => {
                      e.addCSSClass(this.chatWidgetDiv, x), this.Gi.focus();
                    }, 250),
                    this.updateNotificationBadge(this.ai())),
                  (this.isOpen = !1);
              }
            }
            sendExitEvent() {
              const e = {
                messagePayload: { type: o.MessageType.CloseSession },
                userId: this.As.userId,
              };
              if (
                this.As.delegate &&
                this.As.delegate.beforeEndConversation &&
                (0, a.isFunction)(this.As.delegate.beforeEndConversation)
              )
                try {
                  this.As.delegate.beforeEndConversation(e).then((e) => {
                    e &&
                      this.sendMessage(e, { hidden: !0, delegate: !1 }).catch(
                        this.Bs
                      );
                  });
                } catch (e) {
                  this.ds.error(e);
                }
              else
                this.sendMessage(e, { hidden: !0, delegate: !1 }).catch(
                  this.Bs
                );
              this.ks = !1;
            }
            updateNotificationBadge(e) {
              var t;
              (this.fs = e),
                e > 0
                  ? this.qi &&
                    ((this.qi.innerText = `${e}`), this.Gi.appendChild(this.qi))
                  : (null === (t = this.qi) || void 0 === t
                      ? void 0
                      : t.parentElement) && this.qi.remove();
            }
            onToggleNarration(e) {
              this.Yi(e),
                this.ti.trigger(n.ChatEvent.CLICK_AUDIO_RESPONSE_TOGGLE, e);
            }
            remove() {
              var e;
              super.remove(),
                null === (e = this.Ti) || void 0 === e || e.remove(),
                this.Ys.off(o.CoreEvent.Open, this.fi),
                this.Ys.off(o.CoreEvent.State, this.xi),
                this.Ys.off(o.CoreEvent.MessageReceived, this.yi),
                this.Ys.off(o.CoreEvent.ASRStart, this.Ts),
                this.Ys.off(o.CoreEvent.ASRStop, this.Fs),
                this.Ys.off(o.CoreEvent.ASRError, this.Ns),
                this.Ys.off(o.CoreEvent.ASRResponse, this.Hs),
                this.Ys.off(o.CoreEvent.ASRVisualData, this.Vs),
                this.zi && this.Ys.off(o.CoreEvent.TTSStop, this.zi),
                this.As.embedded &&
                  window.removeEventListener("resize", this.Ji);
              const t = this.Ki;
              t && t.remove();
            }
            clearConversationHistory(e = !1) {
              e
                ? this.Xi(e)
                : (this.clearMessages(this.As.userId),
                  this.Xi(),
                  this.Qi({ type: "actionClearHistory" })),
                (this.eo = null),
                (this.js = []),
                (this.skillMessages = []),
                this.Oi(),
                this.updateNotificationBadge(0);
            }
            clearMessages(e, t) {
              const s = this.As;
              if (s.storageType === l.StorageType.CUSTOM) {
                const e = s.conversationHistoryProvider;
                (0, a.isFunction)(null == e ? void 0 : e.deleteMessages)
                  ? e.deleteMessages({ threadId: s.threadId })
                  : this.ds.warn(
                      "Can not clear conversation history. Pass conversationHistoryProvider object with deleteMessages function when custom storage is enabled."
                    );
              } else {
                const i = `${s.name}-${e}-messages`;
                (t ? window[t] : this.so).getItem(i) && this.so.removeItem(i);
              }
            }
            clearAllMessage() {
              const e =
                  null === window || void 0 === window
                    ? void 0
                    : window.localStorage,
                t = (null == e ? void 0 : e.length) || 0;
              if (t) {
                const s = /oda-chat-.*-messages/g;
                for (let i = 0; i < t; i++) {
                  const t = e.key(i);
                  (null == t ? void 0 : t.match(s)) && e.removeItem(t);
                }
              }
            }
            setUserInputMessage(e) {
              this.Ps.setUserInputText(e);
            }
            setUserInputPlaceholder(e) {
              this.Ps.setUserInputPlaceholder(e);
            }
            getWebViewComponent() {
              return this.io;
            }
            refreshWebView(e) {
              this.io.setProps(e),
                this.oo.remove(),
                (this.oo = this.io.render()),
                this.chatWidgetDiv.appendChild(this.oo);
            }
            orientWidgetAnimation() {
              const e = this.element,
                t = Math.floor(window.innerWidth / 2),
                s = e.offsetLeft;
              s < 0
                ? (e.style.left = "10px")
                : s > window.innerWidth && (e.style.right = "10px"),
                s < t && this.ni.addCSSClass(e, "pos-left");
            }
            updateFullScreenWidth(e) {
              const t = this.As.sidepanel
                  ? this.chatWidgetWrapper
                  : this.chatWidgetDiv,
                s = this.ni;
              if ((s.updateCSSVar("--width-full-screen", e), t)) {
                const i = "default",
                  o = "medium",
                  r = "size",
                  a = parseInt(e);
                if (a >= 1024) {
                  if (this.ui === v) return;
                  const e = this.As.icons;
                  s.addCSSClass(t, `${v}-${r}`),
                    s.addCSSClass(
                      this.Ps.element,
                      e.avatarBot || e.avatarAgent ? "left" : "",
                      e.avatarUser ? "right" : ""
                    ),
                    s.removeCSSClass(t, `${o}-${r}`),
                    (this.ui = v);
                } else if (a >= 600) {
                  if (this.ui === o) return;
                  s.addCSSClass(t, `${o}-${r}`),
                    s.removeCSSClass(t, `${v}-${r}`),
                    (this.ui = o);
                } else {
                  if (this.ui === i) return;
                  s.removeCSSClass(t, `${o}-${r}`),
                    s.removeCSSClass(t, `${v}-${r}`),
                    (this.ui = i);
                }
                this.Ps.updateInputHeight(),
                  this.skillMessages
                    .filter((e) => e instanceof h.CardMessageComponent)
                    .forEach((e) => {
                      e.setCardsScrollAttributes(this.ui);
                    }),
                  this.Ls();
              }
            }
            setHeight(e) {
              const t = this.chatWidgetDiv;
              t &&
                !this.As.sidepanel &&
                ((t.style.height = e), (this.As.height = e));
            }
            setWidth(e) {
              const t = this.As.sidepanel
                ? this.chatWidgetWrapper
                : this.chatWidgetDiv;
              t &&
                ((t.style.width = e),
                (this.As.width = e),
                this.updateFullScreenWidth(e));
            }
            setSize(e, t) {
              this.setHeight(t), this.setWidth(e);
            }
            setMessagePadding(e) {
              this.ro("message-bubble", { padding: e }),
                (this.As.messagePadding = e);
            }
            setChatBubbleIconHeight(e) {
              this.ro("typing-cue-wrapper", { height: e }),
                (this.As.height = e);
            }
            setChatBubbleIconWidth(e) {
              this.ro("typing-cue-wrapper", { width: e }), (this.As.width = e);
            }
            setChatBubbleIconSize(e, t) {
              this.ro("typing-cue-wrapper", { height: t, width: e }),
                (this.As.width = e),
                (this.As.height = t);
            }
            onMessageActionClicked(e) {
              const t = this.ni,
                s = this.Rs;
              switch ((this.$i(!1), e.type)) {
                case o.ActionType.Postback:
                  this.ao(this.ws),
                    this.Ls(),
                    e.getPayload().then((s) => {
                      const { label: i, imageUrl: r } = e;
                      this.sendMessage(
                        (0, o.buildUserMessage)({
                          postback: s,
                          text: r
                            ? t.createImageIcon({ icon: r }).outerHTML
                            : i,
                          type: o.MessageType.Postback,
                        })
                      ).catch(() => {
                        this.no(this.ws);
                      });
                    });
                  break;
                case o.ActionType.Location:
                  this.Pi();
                  break;
                case o.ActionType.Share:
                  navigator.share
                    ? e
                        .getPayload()
                        .then((t) =>
                          navigator.share({ text: t, title: e.label })
                        )
                    : this.Ds(s.shareFailureMessage, n.iconWarn);
                  break;
                case o.ActionType.SubmitForm:
                  const i = e.messageComponent;
                  if (!i.validateForm()) break;
                  const r = i.getSubmittedFields();
                  if (this.pi) {
                    const e = this.getMessages();
                    for (let t = e.length - 1; t >= 0; t--) {
                      const s = e[t];
                      if (
                        s.msgId === i.msgId &&
                        s.messagePayload.type === o.MessageType.EditForm
                      ) {
                        const e = s.messagePayload;
                        (0, o.isEditFormPayloadWithFields)(e)
                          ? e.fields.forEach((e) => {
                              (0, o.isReadOnlyField)(e) ||
                                (e.defaultValue = r[e.id]);
                            })
                          : e.formRows.forEach((e) => {
                              e.columns.forEach((e) => {
                                e.fields.forEach((e) => {
                                  (0, o.isReadOnlyField)(e) ||
                                    (e.defaultValue = r[e.id]);
                                });
                              });
                            });
                        break;
                      }
                    }
                    this.so.setItem(this.co, JSON.stringify(e));
                  }
                  this.Ls(),
                    e.getPayload().then((e) => {
                      const t = {
                        postback: e,
                        submittedFields: r,
                        type: o.MessageType.FormSubmission,
                      };
                      e || delete t.postback,
                        this.sendMessage((0, o.buildUserMessage)(t), {
                          hidden: !0,
                        }).catch(this.Bs);
                    });
                  break;
                case o.ActionType.Call:
                  e.getPayload().then((e) => {
                    t.createAnchor(`tel:${e}`, "").click();
                  });
                  break;
                case o.ActionType.Client:
                  e.getPayload().then((e) => {
                    "string" == typeof e
                      ? navigator.clipboard
                        ? navigator.clipboard.writeText(e).then(() => {
                            this.Ds(s.copySuccessMessage, n.iconSuccess);
                          })
                        : this.Ds(s.copyFailureMessage, n.iconWarn)
                      : this.ti.trigger(e.actionType, e);
                  });
                  break;
                default:
                  e.getPayload().then((s) => {
                    t.createAnchor(
                      s,
                      "",
                      [],
                      this.As.openLinksInNewWindow,
                      e.type === o.ActionType.Url
                        ? this.As.linkHandler
                        : this.mi
                    ).click();
                  });
              }
            }
            applyDelegates(e) {
              var t;
              let s;
              s =
                "string" == typeof e
                  ? (0, o.buildUserTextMessage)(
                      e,
                      null === (t = this.speechFinalResult) || void 0 === t
                        ? void 0
                        : t.speechId
                    )
                  : (0, o.isPostbackPayload)(e)
                  ? (0, o.buildPostbackMessage)(e)
                  : (0, o.isMessagePayload)(e)
                  ? (0, o.buildUserMessage)(e)
                  : e;
              const i = s.messagePayload.type,
                r = this.As.delegate,
                n = r.beforePostbackSend,
                c = r.beforeSend;
              return (
                i === o.MessageType.Postback && (0, a.isFunction)(n)
                  ? (s = this.lo(s, n))
                  : _.includes(i) &&
                    (0, a.isFunction)(c) &&
                    (s = this.lo(s, c)),
                s
              );
            }
            sendMessage(e, s) {
              if (this.ho) return (0, t.rejectErrorTextStream)();
              this.Oi(),
                !this.As.enableSpeechAutoSend &&
                  this.speechFinalResult &&
                  "string" == typeof e &&
                  e
                    .toLowerCase()
                    .indexOf(this.speechFinalResult.text.toLowerCase()) >= 0 &&
                  (e = (0, o.buildUserTextMessage)(
                    e,
                    this.speechFinalResult.speechId
                  )),
                this.Ps.focusTextArea(),
                this.Js(),
                void 0 === (s = s || {}).delegate && (s.delegate = !0),
                s.delegate && this.As.delegate && (e = this.applyDelegates(e));
              const i = this.As.sdkMetadata
                ? Object.assign({ version: n.SDK_VERSION }, this.As.sdkMetadata)
                : { version: n.SDK_VERSION };
              return (
                e &&
                this.Ys.sendMessage(e, { sdkMetadata: i }).then((t) => {
                  this.ds.debug("onMessageSent", e),
                    (0, o.isEventPayload)(t.messagePayload) ||
                      ((this.Zs = t.requestId),
                      this.oi && this.oi(t),
                      this.do(),
                      (this.Ms = !1),
                      this.di && this.po(),
                      (this.speechFinalResult = null),
                      (null == s ? void 0 : s.hidden)
                        ? (this.eo = o.SenderType.User)
                        : this.uo(t),
                      this.getAgentDetails() || this.showTypingIndicator());
                })
              );
            }
            uploadFile(e, s) {
              if (this.ho) return (0, t.rejectErrorTextStream)();
              const i = this.Rs;
              this.Js(), this.do();
              const r = new Promise((t, r) => {
                var c;
                if (this.As.enableHeadless) {
                  const s = this.As.sdkMetadata
                    ? Object.assign(
                        { version: n.SDK_VERSION },
                        this.As.sdkMetadata
                      )
                    : { version: n.SDK_VERSION };
                  this.Ys.uploadAttachment(e, { sdkMetadata: s })
                    .then((e) =>
                      this.Ys.sendMessage(
                        this.As.delegate ? this.applyDelegates(e) : e,
                        { sdkMetadata: s }
                      )
                    )
                    .then(t)
                    .catch(r);
                } else {
                  this.Ls();
                  const l =
                      null === (c = e.name) || void 0 === c
                        ? void 0
                        : c.replace(
                            /[\s:'"\\/[\]~,.;^`()@#%*+=$&!{}?<>|]/g,
                            ""
                          ),
                    d = (0, a.generateID)({ prefix: l }),
                    p = this.ni.createDiv();
                  if (
                    ((p.id = d),
                    this.bs.push({ divId: d, fileName: e.name }),
                    this.Si(new Date()),
                    this.mo(p),
                    (this.bo = this.customFileMaxSize
                      ? this.customFileMaxSize
                      : s
                      ? s.maxSize
                      : n.ATTACHMENT_MAX_SIZE),
                    e.size > this.bo)
                  ) {
                    this.Ls();
                    const t = this.bo / (n.BYTE_MULTIPLIER * n.BYTE_MULTIPLIER);
                    let s = t.toString();
                    (0, n.isInteger)(t) || (s = t.toFixed(3));
                    const a = `${e.name} - ${i.uploadFailed}`,
                      c = i.uploadFileSizeLimitExceeded.replace("{0}", s);
                    this.fo(a, c, d),
                      this.Ci(o.SenderType.User),
                      r(new Error(c));
                  } else if (0 === e.size) {
                    this.Ls();
                    const t = `${e.name} - ${i.uploadFailed}`,
                      s = i.uploadFileSizeZeroByte;
                    this.fo(t, s, d),
                      this.Ci(o.SenderType.User),
                      r(new Error(s));
                  } else {
                    const s = new h.LoadingMessageComponent(
                        e.name,
                        h.MESSAGE_SIDE.RIGHT,
                        this.As,
                        this.ni
                      ),
                      i = this.As.sdkMetadata
                        ? Object.assign(
                            { version: n.SDK_VERSION },
                            this.As.sdkMetadata
                          )
                        : { version: n.SDK_VERSION };
                    this.Ci(o.SenderType.User),
                      p.appendChild(s.render()),
                      this.Ls(),
                      this.Ys.uploadAttachment(e, { sdkMetadata: i })
                        .then((e) =>
                          this.Ys.sendMessage(
                            this.As.delegate ? this.applyDelegates(e) : e,
                            { sdkMetadata: i }
                          )
                        )
                        .then((s) => {
                          (s.messagePayload.attachment.title = e.name),
                            p.remove(),
                            (this.bs = this.bs.filter((e) => e.divId !== d)),
                            (this.Os = !1),
                            this.oi && this.oi(s),
                            this.uo(s),
                            t(s);
                        })
                        .catch((t) => {
                          this.wo(e.name, t.message, d), r(t);
                        });
                  }
                }
              });
              return (
                r.catch((e) => {
                  this.ds.error(e);
                }),
                r
              );
            }
            refreshTTS() {
              this.Ti.showTTSButton(!!this.As.ttsService);
            }
            getSuggestions(e) {
              if (this.ho) return (0, t.rejectErrorTextStream)();
              if (
                !this.As.enableAutocompleteClientCache ||
                (this.As.enableAutocompleteClientCache &&
                  !this.Ps.getSuggestionsValid())
              )
                return this.Ys.getSuggestions(e)
                  .then((e) => (this.Ps.displaySuggestions(e), e))
                  .catch(
                    (e) => (
                      this.ds.debug(
                        "[getSuggestions] Failed to receive suggestions, reset list:",
                        e
                      ),
                      []
                    )
                  );
              const s = this.vo(this.Ps.getSuggestions(), e);
              return (
                null !== this.Ps && this.Ps.displaySuggestions(s),
                Promise.resolve(s)
              );
            }
            getUnreadMsgsCount() {
              return this.fs;
            }
            getMessages() {
              const e = this.so.getItem(this.co);
              let t = [];
              if (e)
                try {
                  t = JSON.parse(e).map((e) => Object.assign({}, e));
                } catch (e) {
                  this.ds.error("Failed to parse saved chat.");
                }
              return t;
            }
            getAgentDetails() {
              return this.xo;
            }
            setAgentDetails(e) {
              (this.xo = Object.assign(Object.assign({}, this.xo), e)),
                this.ko(),
                this.so.setItem(this.yo, JSON.stringify(this.xo));
            }
            setUserAvatar(e) {
              (this.As.icons.avatarUser = e), this.so.setItem(this._o, e);
              document
                .querySelectorAll(`.${this.zt}-right .${this.zt}-message-icon`)
                .forEach((t) => {
                  t.parentElement.replaceWith(this.Oo(e, this.Rs.avatarUser));
                });
            }
            Mo(e) {
              const t = Object.assign({ date: Date.now() }, e);
              if (
                (this.gs.push(t), this.As.storageType === l.StorageType.CUSTOM)
              ) {
                const e = this.As.conversationHistoryProvider;
                (0, a.isFunction)(null == e ? void 0 : e.saveMessage)
                  ? e.saveMessage(t)
                  : this.ds.warn(
                      "Can not save conversation history. Pass conversationHistoryProvider object with saveMessage function when custom storage is enabled."
                    );
              } else if (this.pi) {
                const e = this.getMessages();
                e.length >= this.As.messageCacheSizeLimit &&
                  e.splice(0, e.length - (this.As.messageCacheSizeLimit - 1)),
                  e.push(t),
                  this.so.setItem(this.co, JSON.stringify(e));
              }
            }
            configureStorage() {
              const e = this.As,
                { storageType: t, userId: s } = e;
              this.pi &&
                (s
                  ? t !== l.StorageType.LOCAL &&
                    t !== l.StorageType.SESSION &&
                    (e.storageType = l.StorageType.LOCAL)
                  : (e.storageType = l.StorageType.SESSION)),
                (this.so = new l.StorageService(e.storageType));
            }
            setVoiceRecognitionService(e) {
              this.Ps.disableVoiceModeButton(!e, { src: "lang" });
            }
            enableSpeechSynthesisService(e) {
              this.Ti.disableTTSButton(!e);
            }
            onShareLocation() {
              this.Pi();
            }
            setPrimaryChatLanguage(e) {
              this.jo.setTag(e);
            }
            onLanguageUpdate(e, t = !0) {
              var s;
              const i = this.As.i18n,
                o = Object.assign(
                  Object.assign(Object.assign({}, i.en), i[this.As.locale]),
                  i[e]
                );
              t && this.Qi({ type: "actionLanguage", tag: e }),
                (this.ci = e),
                (this.Gi.title = o.chatButtonTitle || o.chatTitle),
                this.Ti.setLocale(o),
                this.Ps.setLocale(o),
                this.As.showTypingIndicator &&
                  this.Ii.updateTypingCueLocale(o.typingIndicator);
              document
                .querySelectorAll(`.${this.zt}-message-icon`)
                .forEach((e) => {
                  const t =
                    e.parentElement.parentElement.className.indexOf(
                      `${this.zt}-left`
                    ) < 0
                      ? o.avatarUser
                      : o.avatarBot;
                  "img" === e.localName
                    ? (e.alt = t)
                    : e.setAttribute("aria-label", t);
                }),
                this.refreshWebView({
                  accessibilityTitle: o.webViewAccessibilityTitle,
                  closeButtonLabel: o.webViewClose,
                  errorInfoDismissLabel: o.webViewErrorInfoDismiss,
                  errorInfoText: o.webViewErrorInfoText,
                }),
                this.jo && this.jo.setLocale(o),
                this.zo &&
                  (this.zo.textContent = (0, a.formatDate)(this.$o, {
                    pattern: this.As.timestampFormat,
                    locale: e,
                  })),
                this.Fi && this.Fi.setLocale(o),
                this.Io && (this.Io.innerText = o.previousChats),
                null === (s = this._i) || void 0 === s || s.setLocale(o),
                (this.Rs = o);
            }
            showTypingIndicator() {
              const e = document.getElementById(`${this.zt}-connection-error`);
              e && e.remove(),
                this.As.showTypingIndicator &&
                  (this.As.searchBarMode
                    ? this.Ii.append(this.Hi)
                    : (this.Ii.append(this.Co), this.Ls()));
            }
            hideTypingIndicator() {
              this.As.showTypingIndicator && this.Ii.remove();
            }
            showConnectionError() {
              const e = {
                  messagePayload: {
                    type: o.MessageType.Text,
                    text: (0, a.safeHTML)(this.Rs.connectionFailureMessage),
                    globalActions: [
                      {
                        type: o.ActionType.Postback,
                        label: this.Rs.connectionRetryLabel,
                      },
                    ],
                  },
                  source: o.SkillMessageSource.Bot,
                },
                t = l.MessageComponentFactory.fromMessage(
                  this.As,
                  this.ni,
                  e,
                  Object.assign(Object.assign({}, this.gi), { locale: this.ci })
                );
              (t.onActionClick = () => {
                this.ye();
              }),
                this.showMessage(`${this.zt}-connection-error`, t);
            }
            showMessage(e, t) {
              var s;
              if (this.As.searchBarMode) this.Es.showMessage(e, t);
              else {
                const s = this.ni.wrapMessageBlock(
                  t.render(),
                  this.As.icons.avatarBot,
                  h.MESSAGE_SIDE.LEFT
                );
                (s.id = e), this.Co.appendChild(s);
              }
              (null === (s = this.Ii) || void 0 === s
                ? void 0
                : s.isVisible()) && this.hideTypingIndicator(),
                this.Ls();
            }
            showWidget() {
              this.So(!0);
            }
            hideWidget() {
              this.So(!1);
            }
            So(e) {
              const t = this.As;
              if (t.embedded || t.enableHeadless) return;
              const s = this.chatWidgetWrapper,
                i = `${this.ni.cssPrefix}-none`;
              s &&
                s.classList.contains(i) === e &&
                (s.classList.toggle(i),
                this.ti.trigger(
                  e ? n.ChatEvent.WIDGET_SHOW : n.ChatEvent.WIDGET_HIDE
                ));
            }
            To(e) {
              if (((this.Os = !1), !this.Ms)) {
                const t = {
                  source: o.SkillMessageSource.Bot,
                  messagePayload: { type: o.MessageType.Text, text: e },
                  userId: this.As.userId,
                  msgId: `${Date.now()}`,
                };
                this.Mo(t), this.Ao(e), this.Eo([t]);
              }
            }
            po() {
              const e = this.Rs;
              this.Po = k(() => {
                this.Os && this.To(e.defaultGreetingMessage),
                  (this.Lo = window.setInterval(() => {
                    this.To(e.defaultWaitMessage);
                  }, this.As.defaultWaitMessageInterval * n.SEC_MULTIPLIER)),
                  (this.Fo = k(() => {
                    window.clearInterval(this.Lo);
                  }, (this.As.typingIndicatorTimeout - 1) * n.SEC_MULTIPLIER)),
                  (this.Po = k(() => {
                    this.hideTypingIndicator(), this.To(e.defaultSorryMessage);
                  }, this.As.typingIndicatorTimeout * n.SEC_MULTIPLIER));
              }, this.As.defaultGreetingTimeout * n.SEC_MULTIPLIER);
            }
            ki(e) {
              return i(this, void 0, void 0, function* () {
                var t, s;
                if (Number.isInteger(e) && e !== o.ConnectionState.Open) {
                  this.No(),
                    this.Ps.isDisabled() ||
                      (this.Ps.disable(),
                      null === (t = this.Ti) || void 0 === t || t.disable(),
                      this.ds.debug(
                        "WebSocket not open, send message button disabled"
                      )),
                    this.Ro(),
                    e === o.ConnectionState.Connecting
                      ? this.showTypingIndicator()
                      : this.hideTypingIndicator();
                  for (const e of this.bs)
                    this.wo(e.fileName, o.CoreError.UploadNetworkFail, e.divId);
                  this.jo && this.jo.disableComponent(!0);
                } else yield this.Ho(), (this.Uo = void 0), (this.Vo = `${this.As.userId}-canceled-requests`), (this.qs = new Set(this.Bo())), this.hideTypingIndicator(), this.bi(), this.Ps.isDisabled() && (this.Ps.disable(!1), null === (s = this.Ti) || void 0 === s || s.disable(!1), this.ds.debug("Connection established, send message button enabled")), this.Wo();
                this.ri(e);
              });
            }
            Ho() {
              return i(this, void 0, void 0, function* () {
                if (this.As.clientAuthEnabled)
                  try {
                    const e = yield this.Ys.getAuthToken();
                    (this.As.channelId = e.getClaim("channelId")),
                      (this.As.userId = e.getClaim("userId"));
                  } catch (e) {
                    return;
                  }
                const { name: e, userId: t } = this.As,
                  s = `${e}-${t}`;
                (this.co = `${s}-messages`),
                  (this.yo = `${s}-agent-details`),
                  (this._o = `${s}-user-avatar`);
              });
            }
            Bi() {
              const e = this.As;
              (this.jo = new c.MultiLangChatComponent(
                e.multiLangChat,
                {
                  webCore: this.Ys,
                  chatWidget: this,
                  eventDispatcher: this.ti,
                  settings: e,
                  synthesisVoices: e.ttsVoice,
                  storageService: new l.StorageService(e.storageType),
                  util: this.ni,
                },
                this
              )),
                this.Ti.addLanguageSelect(this.jo);
            }
            Pi() {
              const e = this.Rs;
              if (navigator && navigator.geolocation) {
                const t = new h.LoadingMessageComponent(
                  e.requestLocation,
                  h.MESSAGE_SIDE.RIGHT,
                  this.As,
                  this.ni
                );
                this.mo(t.render()),
                  this.Ls(),
                  (0, o.getCurrentPosition)().then(
                    (e) => {
                      const s = (0, o.buildUserMessage)({
                        location: {
                          latitude: e.latitude,
                          longitude: e.longitude,
                          title: void 0,
                        },
                        type: o.MessageType.Location,
                      });
                      t.remove(), this.sendMessage(s).catch(this.Bs);
                    },
                    (s) => {
                      let i;
                      switch (s.code) {
                        case s.PERMISSION_DENIED:
                          i = e.requestLocationDeniedPermission;
                          break;
                        case s.POSITION_UNAVAILABLE:
                          i = e.requestLocationDeniedUnavailable;
                          break;
                        case s.TIMEOUT:
                          i = e.requestLocationDeniedTimeout;
                          break;
                        default:
                          i = e.requestLocationDeniedPermission;
                      }
                      this.Ds(i, n.iconWarn), t.remove();
                    }
                  );
              } else this.Ds(e.requestLocationDeniedUnavailable, n.iconWarn);
            }
            vo(e, t) {
              const s = [];
              for (const i of e) i.search(new RegExp(t, "i")) >= 0 && s.push(i);
              return s;
            }
            wo(e, t, s) {
              const i = this.Rs,
                r = `${e} - ${i.uploadFailed}`;
              let a = "";
              switch (t) {
                case o.CoreError.UploadMaxSize:
                  a = i.uploadFileSizeLimitExceeded.replace(
                    "{0}",
                    this.bo.toString()
                  );
                  break;
                case o.CoreError.UploadZeroSize:
                  a = i.uploadFileSizeZeroByte;
                  break;
                case o.CoreError.UploadBadFile:
                  a = i.uploadUnsupportedFileType;
                  break;
                case o.CoreError.UploadNetworkFail:
                  a = i.uploadFileNetworkFailure;
                  break;
                case o.CoreError.UploadUnauthorized:
                  a = i.uploadUnauthorized;
              }
              this.fo(r, a, s);
            }
            lo(e, t) {
              var s;
              const i = (0, a.clone)(e);
              let r,
                n = (0, a.clone)(e);
              e.messagePayload.type === o.MessageType.Text &&
                (null === (s = e.sdkMetadata) || void 0 === s
                  ? void 0
                  : s.speechId) &&
                (r = (e.messagePayload.text || "").toLowerCase());
              try {
                n = t(i);
              } catch (e) {
                this.ds.error(e);
              }
              if (
                ((n && n.messagePayload) || (n = null),
                n &&
                  !(0, o.isValidMessage)(n) &&
                  (this.ds.error(
                    "The generated delegate message is invalid. Sending original message instead."
                  ),
                  (n = e)),
                r && n)
              )
                if (n.messagePayload) {
                  if (n.messagePayload.type === o.MessageType.Text) {
                    const e = n.messagePayload.text;
                    (null == e ? void 0 : e.toLowerCase().indexOf(r)) < 0 &&
                      delete n.sdkMetadata;
                  } else delete n.sdkMetadata;
                } else delete n.sdkMetadata;
              return n;
            }
            fo(e, t, s) {
              const i = document.getElementById(s);
              if (i) {
                i.firstElementChild && i.removeChild(i.firstElementChild),
                  (this.bs = this.bs.filter((e) => e.divId !== s));
                const o = new h.MessageStringComponent(
                    e,
                    t,
                    h.MESSAGE_SIDE.RIGHT,
                    this.As,
                    this.ni,
                    !0
                  ),
                  r = this.As.icons.error || n.iconError;
                i.appendChild(o.render(r));
              }
            }
            addHeaderAction(e) {
              this.Ti.addAction(e);
            }
            updateHeaderAction(e) {
              this.Ti.Zo(e);
            }
            on(e, t) {
              switch (e) {
                case o.SpeechSynthesisServiceEvent.TTSStart:
                case o.SpeechSynthesisServiceEvent.TTSStop:
                  this.Ys.on(e, t);
                  break;
                default:
                  this.ti.bind(e, t);
              }
            }
            off(e, t) {
              switch (e) {
                case o.SpeechSynthesisServiceEvent.TTSStart:
                case o.SpeechSynthesisServiceEvent.TTSStop:
                  this.Ys.off(e, t);
                  break;
                default:
                  this.ti.unbind(e, t);
              }
            }
            Ui() {
              var e, t, s, i, o, r;
              const a = this.As,
                l = this.ni,
                h = this.Rs,
                p = l.createDiv(
                  a.embedded
                    ? []
                    : ["wrapper", a.theme, a.enableHeadless ? "none" : ""]
                );
              (this.chatWidgetDiv = l.createDiv(["widget", "flex", "col"])),
                this.chatWidgetDiv.setAttribute("role", "region"),
                this.chatWidgetDiv.setAttribute(
                  "aria-labelledby",
                  `${this.zt}-title`
                ),
                this.ni.setChatWidgetWrapper(p);
              const u = this.Ti.render();
              this.chatWidgetDiv.appendChild(this.Ti.element),
                a.embedTopStickyId &&
                  this.Go(a.embedTopStickyId, this.chatWidgetDiv, [
                    "embed-sticky-top",
                  ]),
                (this.qo = new c.WidgetMainComponent(l)),
                !a.enableCancelResponse ||
                  a.enableHeadless ||
                  a.searchBarMode ||
                  (this._i = new g.CancelResponseComponent({
                    parent: this.qo.element,
                    i18n: this.Rs,
                    domUtil: this.ni,
                    onHide: this.Ws,
                    onClick: this.Gs,
                  })),
                (this.Yo = l.createDiv([
                  "conversation-pane",
                  a.icons.avatarBot ? "bot-icon" : "",
                  a.icons.avatarUser ? "user-icon" : "",
                ])),
                "bottom" === a.conversationBeginPosition &&
                  (this.Yo.style.marginTop = "auto"),
                a.embedTopScrollId &&
                  this.Go(a.embedTopScrollId, this.Yo, ["embed-scroll-top"]),
                (this.Co = l.createDiv(["conversation-container"])),
                this.Co.setAttribute("role", "log"),
                this.Co.setAttribute("aria-live", "polite"),
                this.Co.setAttribute("aria-atomic", "false"),
                this.Yo.appendChild(this.Co),
                this.qo.element.appendChild(this.Yo),
                a.embedBottomScrollId &&
                  this.Go(a.embedBottomScrollId, this.qo.element, [
                    "embed-scroll-bottom",
                  ]),
                this.chatWidgetDiv.appendChild(this.qo.element),
                a.embedBottomStickyId &&
                  this.Go(a.embedBottomStickyId, this.chatWidgetDiv, [
                    "embed-sticky-bottom",
                  ]),
                this.Ps.render(),
                this.chatWidgetDiv.appendChild(this.Ps.element),
                (t = a.webViewConfig).accessibilityTitle ||
                  (t.accessibilityTitle = h.webViewAccessibilityTitle),
                (s = a.webViewConfig).closeButtonLabel ||
                  (s.closeButtonLabel = h.webViewClose),
                (i = a.webViewConfig).errorInfoDismissLabel ||
                  (i.errorInfoDismissLabel = h.webViewErrorInfoDismiss),
                (o = a.webViewConfig).errorInfoText ||
                  (o.errorInfoText = h.webViewErrorInfoText),
                (r = a.webViewConfig).closeButtonIcon ||
                  (r.closeButtonIcon = a.icons.close),
                (this.io = new d.WebViewComponent(a.webViewConfig, l, a)),
                (this.oo = this.io.render()),
                this.chatWidgetDiv.appendChild(this.oo);
              const m = this.io,
                b = `${this.zt}-webview`;
              if (
                ((this.mi = {
                  target: b,
                  onclick: function () {
                    m.open(this.href);
                  },
                }),
                a.linkHandler &&
                  a.linkHandler.target === b &&
                  (a.linkHandler = this.mi),
                p.appendChild(this.chatWidgetDiv),
                a.embedded)
              )
                (this.isOpen = !0), l.addCSSClass(p, "open");
              else {
                const t =
                    a.icons.launch ||
                    (a.colors && a.colors.branding
                      ? n.iconLaunchButton.replace("#025e7e", a.colors.branding)
                      : n.iconLaunchButton),
                  s = "button",
                  i = l.createIconButton({
                    css: [s],
                    icon: t,
                    iconCss: [`${s}-icon`],
                    title: h.chatButtonTitle || h.chatTitle,
                  });
                i.classList.remove(`${this.zt}-icon`),
                  (this.Gi = i),
                  (this.Gi.onclick =
                    null === (e = this.Qs) || void 0 === e
                      ? void 0
                      : e.bind(this)),
                  (this.qi = l.createTextDiv(["notification-badge"])),
                  p.appendChild(i),
                  this.Is.set("launch", i),
                  a.enableDraggableButton &&
                    new n.DragAndDrop(this.ni, i).makeElementDraggable(),
                  a.enableDraggableWidget &&
                    new n.DragAndDrop(
                      this.ni,
                      u,
                      this.chatWidgetDiv
                    ).makeElementDraggable(),
                  a.openChatOnLoad || l.addCSSClass(p, f),
                  l.addCSSClass(this.chatWidgetDiv, x);
              }
              if (((this.chatWidgetWrapper = p), a.sidepanel)) {
                const e = (e) => {
                  const t = document.body.clientWidth - e.x;
                  if (
                    (l.addCSSClass(this.chatWidgetWrapper, "drag"),
                    (document.body.style.cursor =
                      t <= 375
                        ? "w-resize"
                        : t >= 800
                        ? "e-resize"
                        : "col-resize"),
                    t >= 375 && t <= 800)
                  ) {
                    const e = `${t}px`;
                    (this.chatWidgetWrapper.style.width = e),
                      this.updateFullScreenWidth(e);
                  }
                  e.preventDefault();
                };
                p.addEventListener(
                  "mousedown",
                  (t) => {
                    t.offsetX < 4 &&
                      document.addEventListener("mousemove", e, !1);
                  },
                  !1
                ),
                  document.addEventListener(
                    "mouseup",
                    () => {
                      document.removeEventListener("mousemove", e, !1),
                        l.removeCSSClass(this.chatWidgetWrapper, "drag"),
                        this.chatWidgetWrapper.style.removeProperty("cursor"),
                        document.body.style.removeProperty("cursor");
                    },
                    !1
                  );
              } else if (this.li) {
                new n.Resize(
                  this.chatWidgetDiv,
                  this.updateFullScreenWidth.bind(this),
                  l
                ).makeWidgetResizable();
              }
              return this.chatWidgetWrapper;
            }
            Di() {
              const e = this.As;
              if (!e.disableInlineCSS) {
                let e = !1;
                const t = document.head.children,
                  s = document.createElement("style");
                s.appendChild(
                  document.createTextNode(
                    r.redwoodStyles.replace(
                      /(\.)([a-zA-Z_-]+)(?=[^}]+{)/gi,
                      `$1${this.zt}-$2`
                    )
                  )
                );
                for (let i = 0; i < t.length; i++) {
                  const o = t.item(i);
                  if ("style" === o.nodeName.toLowerCase()) {
                    document.head.insertBefore(s, o), (e = !0);
                    break;
                  }
                }
                e || document.head.appendChild(s), (this.styleSheet = s);
              }
              (0, n.configureColorCustomization)(e.colors, this.ni);
            }
            Vi() {
              var e;
              const t = this.As,
                s = this.ni;
              if (t.embedded)
                try {
                  const e = document.getElementById(t.targetElement);
                  this.embedInElement(t.targetElement),
                    this.updateFullScreenWidth(`${e.clientWidth}px`),
                    window.addEventListener(
                      "resize",
                      (0, n.debounce)(() => {
                        this.updateFullScreenWidth(`${e.clientWidth}px`);
                      }, 500)
                    );
                } catch (e) {
                  this.ds.error("Target Element not specified", e);
                }
              else if (t.sidepanel)
                try {
                  const e = document.getElementById(t.targetElement),
                    i = e.parentNode,
                    o = s.createDiv(["sidepanel-content-wrapper"]);
                  i.replaceChild(o, e),
                    s.addCSSClass(this.chatWidgetDiv, "sidepanel"),
                    o.appendChild(e),
                    o.appendChild(this.chatWidgetWrapper);
                } catch (e) {
                  this.ds.error("Target Element not specified", e);
                }
              else {
                try {
                  this.appendToElement(document.body);
                } catch (e) {
                  return void this.ds.error(
                    "Initialisation failed as page is not completely loaded. Make sure to initialise the SDK after document.body is available."
                  );
                }
                k(() => {
                  this.orientWidgetAnimation();
                }, 0),
                  window.addEventListener(
                    "resize",
                    (0, n.debounce)(() => {
                      this.orientWidgetAnimation();
                    }, 500)
                  );
                const s = t.width,
                  i = t.height;
                s && this.setWidth(s),
                  i && this.setHeight(i),
                  t.openChatOnLoad &&
                    k(
                      null === (e = this.Qs) || void 0 === e
                        ? void 0
                        : e.bind(this),
                      0
                    );
              }
            }
            mo(e) {
              var t;
              this.As.searchBarMode
                ? this.Es.appendMessageToConversation(e)
                : this.Co.appendChild(e),
                (null === (t = this.Ii) || void 0 === t
                  ? void 0
                  : t.isVisible()) &&
                  (this.hideTypingIndicator(), this.showTypingIndicator());
            }
            Ls() {
              const e = this.qo.element;
              k(() => {
                e && (e.scrollTop = e.scrollHeight);
              }, n.Constants.CHAT_SCROLL_DELAY);
            }
            Eo(e, t = !0) {
              if (!e || !e.length) return Promise.resolve();
              const s = this.As.threadId,
                i = e.filter((e) => !e.threadId || !s || e.threadId === s);
              return i.length
                ? new Promise((e) => {
                    const s = { isFresh: t };
                    this.As.clientAuthEnabled &&
                    this.As.enableAttachmentSecurity
                      ? this.Ys.getAuthToken()
                          .then((t) => {
                            (s.authToken = t.token),
                              this.Jo(i, s),
                              e(),
                              this.Ls();
                          })
                          .catch(() => {
                            this.Jo(i, s), e(), this.Ls();
                          })
                      : (this.Jo(i, s), e(), this.Ls());
                  })
                : Promise.resolve();
            }
            Ko(e, t) {
              var s, i, r, a;
              let n;
              if ((0, l.isBotMessage)(e)) {
                let c = "";
                if (e.source === o.SkillMessageSource.Agent) {
                  const i = this.As.icons;
                  (null === (s = e.messagePayload.channelExtensions) ||
                  void 0 === s
                    ? void 0
                    : s.agentSession) ||
                    (e.messagePayload.channelExtensions
                      ? (e.messagePayload.channelExtensions.agentSession =
                          this.xo)
                      : (e.messagePayload.channelExtensions = {
                          agentSession: this.xo,
                        })),
                    !this.xo.avatarImage &&
                      i.avatarBot &&
                      t.appendChild(this.Xo()),
                    (c = this.xo.name);
                } else if (
                  e.source === o.SkillMessageSource.Bot &&
                  (null === (i = e.messagePayload.channelExtensions) ||
                  void 0 === i
                    ? void 0
                    : i.agentSession)
                ) {
                  c = (
                    null === (r = e.messagePayload.channelExtensions) ||
                    void 0 === r
                      ? void 0
                      : r.agentSession
                  ).name;
                }
                c &&
                  ((n = this.ni.createTextDiv(["agent-name"])),
                  (n.title = c),
                  (n.innerHTML = c),
                  n.setAttribute("aria-hidden", "true"),
                  (null === (a = this.xo) || void 0 === a
                    ? void 0
                    : a.nameTextColor) &&
                    (n.style.color = this.xo.nameTextColor));
              }
              return n;
            }
            Xo() {
              const e = this.xo || {},
                t = e.name.split(" ").filter((e) => e);
              let s = t[0][0];
              return (
                t.length > 1 && (s += t[t.length - 1][0]),
                this.Oo(s.toUpperCase(), e.name, !0)
              );
            }
            ko() {
              if (this.As.showTypingIndicator) {
                const e = this.xo || {},
                  t = this.As.icons,
                  s = this.Rs;
                t.avatarBot &&
                  (!e.avatarImage && e.name
                    ? this.Ii.updateTypingCueIcon(this.Xo())
                    : this.Ii.updateTypingCueIcon(
                        this.Oo(
                          e.avatarImage || t.avatarBot,
                          s.avatarAgent || s.avatarBot
                        )
                      ));
              }
            }
            Oo(e, t, s = !1) {
              const i = this.ni,
                o = i.createDiv(["icon-wrapper", s ? "agent-avatar" : ""]),
                r = this.xo || {};
              let a;
              return (
                s
                  ? ((a = i.createTextDiv(["agent-icon"])),
                    (a.innerText = e),
                    this.ui === v && i.addCSSClass(this.Ps.element, "left"),
                    r.avatarTextColor && (a.style.color = r.avatarTextColor),
                    r.avatarBackgroundColor &&
                      (o.style.background = r.avatarBackgroundColor))
                  : (a = i.createImageIcon({
                      icon: e,
                      iconCss: ["message-icon"],
                    })),
                o.appendChild(a),
                o.setAttribute("aria-label", t),
                o
              );
            }
            Qo(e) {
              const t = e ? new Date(e) : new Date(),
                s = (0, a.formatDate)(t, {
                  pattern: this.As.timestampFormat,
                  locale: this.ci,
                }),
                i = this.ni.createTextDiv(["message-date"]);
              return (
                i.setAttribute("aria-live", "off"),
                i.setAttribute("aria-hidden", "true"),
                (i.innerText = `${s}`),
                i
              );
            }
            Jo(e, t) {
              const { isFresh: s, authToken: i } = t,
                r = this.As,
                a = this.ni,
                c = Object.assign(Object.assign({}, this.gi), {
                  locale: this.ci,
                  isFresh: s,
                });
              (null == i ? void 0 : i.length) &&
                ((c.authToken = i), (c.uri = r.URI)),
                e.forEach((e) => {
                  var t, s, i, d, p;
                  if (e.messagePayload.type === o.MessageType.Error) return;
                  if ((0, l.isBotMessage)(e)) {
                    const t = (0, l.getMessageDigest)(e);
                    if (this.js.indexOf(t) >= 0) return;
                    this.js.push(t);
                  }
                  const u = l.MessageComponentFactory.fromMessage(r, a, e, c);
                  if (!u) return;
                  if (u instanceof h.TextStreamMessageComponent) {
                    this.er = e;
                    const t = e.messagePayload;
                    switch (t.streamState) {
                      case "start":
                        this.Ps.disable(), (this.ho = u);
                        break;
                      case "running":
                        if (this.ho)
                          return (
                            this.ho.update(t),
                            clearTimeout(this.tr),
                            void (this.tr = k(() => {
                              this.Ps.disable(!1), (this.ho = null);
                            }, this.$s))
                          );
                        this.Ps.disable(), (this.ho = u);
                        break;
                      case "end":
                        if (
                          (clearTimeout(this.tr), this.Ps.disable(!1), this.ho)
                        )
                          return (
                            this.ho.update(t),
                            (this.ho = null),
                            void (this.er = null)
                          );
                    }
                  } else
                    (this.ho = null), (this.er = null), clearTimeout(this.tr);
                  u.onActionClick = this.onMessageActionClicked.bind(this);
                  const g = (0, l.isBotMessage)(e)
                      ? o.SenderType.Skill
                      : o.SenderType.User,
                    m = this.sr(e.messagePayload, g),
                    b = m || this.ir(e, g);
                  let f;
                  if (
                    ((u.msgId = e.msgId),
                    (this.eo = g),
                    (this.Uo = Date.now()),
                    (this.zs =
                      e.messagePayload.globalActions &&
                      0 !== e.messagePayload.globalActions.length),
                    (this.rr =
                      (null ===
                        (s =
                          null === (t = e.messagePayload.channelExtensions) ||
                          void 0 === t
                            ? void 0
                            : t.agentSession) || void 0 === s
                        ? void 0
                        : s.name) || ""),
                    (0, l.isBotMessage)(e) && (this.nr = e.source),
                    b ||
                      ((f = a.createDiv(["message-block", "flex"])),
                      (this.cr = f)),
                    (0, n.isFeedbackComponent)(u) && (this.lr = u),
                    (0, l.isBotMessage)(e))
                  )
                    this.vs && this.hr(u),
                      this.skillMessages.push(u),
                      e.source === o.SkillMessageSource.Agent
                        ? ((null === (i = e.messagePayload.channelExtensions) ||
                          void 0 === i
                            ? void 0
                            : i.agentName) &&
                            this.setAgentDetails({
                              name: e.messagePayload.channelExtensions
                                .agentName,
                              avatarImage: r.icons.avatarAgent,
                              nameTextColor: null,
                              avatarTextColor: null,
                              avatarBackgroundColor: null,
                            }),
                          (null === (d = e.messagePayload.channelExtensions) ||
                          void 0 === d
                            ? void 0
                            : d.agentSession) &&
                            this.setAgentDetails(
                              e.messagePayload.channelExtensions.agentSession
                            ))
                        : (this.so.removeItem(this.yo), (this.xo = null)),
                      this.Ni(u);
                  else if (this.lr) {
                    const t = e;
                    if (
                      t.messagePayload.type === o.MessageType.Text ||
                      t.messagePayload.type === o.MessageType.Postback
                    ) {
                      const e = t.messagePayload;
                      this.lr.highlightRating(e.text);
                    }
                    this.lr = null;
                  }
                  if (r.searchBarMode)
                    return void this.Es.renderMessage(e, u, m);
                  const w = e.date ? new Date(e.date) : new Date();
                  this.Si(w), f && (this.dr(e, f), this.mo(f));
                  const v = this.cr.querySelector('[class*="message-list"]'),
                    x = this.pr(e, u, v);
                  if (x) {
                    if (e.messagePayload.type === o.MessageType.Card) {
                      const e = v.querySelectorAll('[class*="message-bubble"]');
                      if (e.length) {
                        e[e.length - 1].classList.add(`${this.zt}-before-card`);
                      }
                    }
                    m && v.lastElementChild
                      ? (this.Js(),
                        this.isOpen || this.updateNotificationBadge(--this.fs),
                        null === (p = v.lastElementChild) ||
                          void 0 === p ||
                          p.replaceWith(x))
                      : v.appendChild(x),
                      u instanceof h.CardMessageComponent &&
                        u.setCardsScrollAttributes(this.ui);
                  }
                  this.Ci(g);
                });
            }
            sr(e, t) {
              var s, i;
              if (
                t === o.SenderType.Skill &&
                (this.As.searchBarMode ||
                  (null === (s = this.cr) || void 0 === s
                    ? void 0
                    : s.className.includes(`${this.zt}-left`)))
              ) {
                const t =
                  null === (i = e.channelExtensions) || void 0 === i
                    ? void 0
                    : i.replaceMessage;
                return (
                  !0 === t ||
                  (t && "true" === (null == t ? void 0 : t.toLowerCase()))
                );
              }
              return !1;
            }
            ir(e, t) {
              var s, i;
              if (!(Date.now() - this.Uo < n.MESSAGE_BLOCK_THRESOLD)) return !1;
              if (
                (0, l.isBotMessage)(e) &&
                e.source === o.SkillMessageSource.Agent &&
                (null === (s = e.messagePayload.channelExtensions) ||
                void 0 === s
                  ? void 0
                  : s.agentSession)
              ) {
                const t =
                  null === (i = e.messagePayload.channelExtensions) ||
                  void 0 === i
                    ? void 0
                    : i.agentSession;
                return this.rr === t.name;
              }
              return !(
                this.eo !== t ||
                ((0, l.isBotMessage)(e) && e.source !== this.nr) ||
                this.zs
              );
            }
            dr(e, t) {
              const s = this.As.icons,
                i = this.Rs,
                r = this.ni,
                a = this.xo || {};
              let n, c, h;
              if ((0, l.isBotMessage)(e)) {
                if (
                  ((n = this.Ko(e, t)),
                  e.source === o.SkillMessageSource.Agent
                    ? ((c =
                        s.avatarBot &&
                        (a.avatarImage || !a.name) &&
                        (a.avatarImage || s.avatarAgent || s.avatarBot)),
                      (h = i.agentMessage.replace(
                        "{0}",
                        `${a.name || i.agent}`
                      )))
                    : (this.nr === o.SkillMessageSource.Agent &&
                        this.As.showTypingIndicator &&
                        this.Ii.resetTypingCueIcon(),
                      (c = s.avatarBot),
                      (h = i.skillMessage)),
                  r.addCSSClass(t, "left"),
                  c)
                ) {
                  this.ui === v && r.addCSSClass(this.Ps.element, "left");
                  const s = this.Oo(
                    c,
                    (e.source === o.SkillMessageSource.Agent &&
                      i.avatarAgent) ||
                      i.avatarBot
                  );
                  (s.style.marginTop = n && "16px"), t.appendChild(s);
                }
              } else
                r.addCSSClass(t, "right"),
                  (h = i.userMessage),
                  s.avatarUser &&
                    (this.ui === v && r.addCSSClass(this.Ps.element, "right"),
                    t.appendChild(this.Oo(s.avatarUser, i.avatarUser)));
              const d = r.createDiv(["messages-wrapper", "flex", "col"]);
              n && d.appendChild(n);
              const p = this.ni.createTextSpan(["screen-reader-only"]);
              (p.innerText = h), d.appendChild(p);
              const u = r.createDiv(["message-list", "flex", "col"]);
              if (
                (d.appendChild(u),
                this.As.enableTimestamp && "absolute" === this.As.timestampMode)
              ) {
                const t = this.Qo(e.date);
                d.appendChild(t);
              }
              t.appendChild(d);
            }
            pr(e, t, s) {
              const i = this.As.delegate;
              if (i && i.render) {
                const t = this.ni.createDiv(["message"]);
                (t.id = e.msgId), (t.lang = this.ci), s.appendChild(t);
                if (i.render(e)) return null;
                t.remove();
              }
              return t.render();
            }
            Si(e) {
              (0, a.isSameDay)(this.$o, e) ||
                ((this.$o = new Date(e)), this.mo(this.ur(this.$o)));
            }
            ur(e) {
              const t = this.ni.createTextDiv(["timestamp-header"]);
              return (
                (t.textContent = (0, a.formatDate)(e, {
                  pattern: this.As.timestampFormat,
                  locale: this.ci,
                })),
                (this.zo = t),
                t
              );
            }
            Ci(e) {
              this.gr || (this.gr = this.Fi.render()),
                this.gr.remove(),
                this.Fi.refresh(e),
                this.mo(this.gr);
            }
            Ni(e) {
              e.hasActions() &&
                k(() => {
                  e.focusFirstAction();
                }, 290);
            }
            Go(e, t, s) {
              const i = document.querySelector(`#${e}`);
              if (i) {
                const e = this.ni.createDiv(s);
                e.appendChild(i), t.appendChild(e);
              } else
                this.ds.error(
                  `Could not find element with ID '${e}'. No element embedded to the chat conversation pane.`
                );
            }
            $i(e, t = !1) {
              const s = this.Rs;
              t ||
                (this.Js(), this.ti.trigger(n.ChatEvent.CLICK_VOICE_TOGGLE, e)),
                this.As.enableSpeech &&
                  (e
                    ? (this.mr(),
                      this.As.speechLocale &&
                      !(0, o.isValidLocale)(this.As.speechLocale)
                        ? this.Ds(s.errorSpeechUnsupportedLocale, n.iconWarn)
                        : this.Ys.startRecognition().catch(this.Ns))
                    : (this.Ys.stopRecognition(),
                      this.Ps.setVoiceRecording(!1)));
            }
            Us(e) {
              if (e)
                switch (e.type) {
                  case "partial":
                    let t = e.text;
                    t.length > 0 &&
                      (this.speechFinalResult &&
                        (t = `${this.speechFinalResult.text} ${t}`),
                      this.Ps.setUserInputText(t));
                    break;
                  case "final":
                    let s = e.text;
                    s.length > 0
                      ? (this.speechFinalResult &&
                          (s = `${this.speechFinalResult.text} ${s}`),
                        this.Ps.setUserInputText(s),
                        this.As.enableSpeechAutoSend
                          ? k(() => {
                              const t = (0, o.buildUserTextMessage)(
                                s,
                                e.requestId
                              );
                              this.sendMessage(t)
                                .then(() => {
                                  this.Ps.setUserInputText(""), this.br();
                                })
                                .catch(this.Bs);
                            }, 200)
                          : (this.speechFinalResult = {
                              speechId: e.requestId,
                              text: s,
                            }))
                      : this.Ps.setUserInputText(this.speechFinalResult.text);
                    break;
                  case "error":
                    this.Ns(new Error(e.text));
                }
            }
            ao(e) {
              switch (this.As.disablePastActions) {
                case "all":
                  e.forEach((e) => {
                    e.disableActions();
                  });
                  break;
                case "postback":
                  e.forEach((e) => {
                    e.disablePostbacks();
                  });
              }
            }
            no(e) {
              switch (this.As.disablePastActions) {
                case "all":
                  e.forEach((e) => {
                    e.enableActions();
                  });
                  break;
                case "postback":
                  e.forEach((e) => {
                    e.enablePostbacks();
                  });
              }
            }
            wr() {
              this.ao(this.skillMessages);
            }
            hr(e) {
              "none" !== this.As.disablePastActions && this.ws.push(e);
            }
            do() {
              var e;
              this.ao(this.ws),
                (this.ws = []),
                null === (e = this._i) || void 0 === e || e.show(),
                this.br();
            }
            Wo() {
              ("none" === this.As.disablePastActions
                ? this.skillMessages
                : this.ws
              ).forEach((e) => {
                e.enablePostbacks();
              });
            }
            Ro() {
              ("none" === this.As.disablePastActions
                ? this.skillMessages
                : this.ws
              ).forEach((e) => {
                e.disablePostbacks();
              });
            }
            Xi(e = !1) {
              var t;
              const s = this.As.searchBarMode ? this.Hi : this.Co;
              let i = !1;
              for (
                (null === (t = this.Ii) || void 0 === t
                  ? void 0
                  : t.isVisible()) && ((i = !0), this.hideTypingIndicator());
                s.firstChild;

              )
                s.removeChild(s.lastChild);
              i && this.showTypingIndicator(),
                (this.Os = !0),
                (this.$o = null),
                this.Js(),
                e ? (this._s = !0) : this.ti.trigger(n.ChatEvent.CLICK_ERASE);
            }
            bi() {
              const { userId: e, channelId: t } = this.As;
              b &&
                (this.No(),
                (this.vr = new b(`${e}-${t}`)),
                (this.vr.onmessage = this.kr.bind(this)));
            }
            No() {
              this.vr && (this.vr.close(), (this.vr = null));
            }
            yr(e) {
              if (this.vr) {
                const t = { type: "message", message: e };
                if ((0, l.isBotMessage)(e)) {
                  const s = (0, l.getMessageDigest)(e);
                  if (this.js.indexOf(s) >= 0) return;
                  t.digest = s;
                }
                this.vr.postMessage(t);
              }
            }
            Qi(e) {
              this.vr && this.vr.postMessage(e);
            }
            kr(e) {
              var t;
              const s = e.data;
              switch (s.type) {
                case "message":
                  const e = s.message.messagePayload;
                  if (e.type === o.MessageType.Status) {
                    const t = e;
                    return void ("RESPONDING" === t.status
                      ? this.showTypingIndicator()
                      : "LISTENING" === t.status && this.hideTypingIndicator());
                  }
                  if (e.type === o.MessageType.SessionClosed)
                    return void (this.si && this.si());
                  if (s.digest) {
                    if (this.js.indexOf(s.digest) >= 0) return;
                    this.ii && this.ii(s.message);
                  } else
                    this.oi && this.oi(s.message),
                      this.do(),
                      this.showTypingIndicator();
                  this.hideTypingIndicator(), this.Eo([s.message]);
                  break;
                case "actionClearHistory":
                  this.Xi();
                  break;
                case "actionLanguage":
                  null === (t = this.jo) || void 0 === t || t.setTag(s.tag, !1);
              }
            }
            Ai() {
              if (
                this.As.wcfsEnableEndConversationButtonToClose &&
                this.Ys.getState() === o.ConnectionState.Closed
              )
                this.si();
              else {
                const e = this.Rs;
                this.mr();
                const t = new p.AlertDialog({
                  title: e.endConversationConfirmMessage || "",
                  description: e.endConversationDescription || "",
                  parent: this.chatWidgetDiv,
                  domUtil: this.ni,
                  actions: [
                    { label: e.noText, handler: this.mr.bind(this) },
                    {
                      label: e.yesText,
                      handler: this._r.bind(this),
                      type: "filled",
                    },
                  ],
                });
                t.open(), (this.Or = t);
              }
            }
            _r() {
              this.sendExitEvent(), this.mr();
            }
            Ds(e, t) {
              this.mr();
              const s = new p.AlertDialog({
                title: e,
                icon: t,
                parent: this.As.searchBarMode ? this.Hi : this.chatWidgetDiv,
                domUtil: this.ni,
                fallbackFocus: () => {
                  this.Ps.focusTextArea();
                },
                showDismiss: !0,
                autoDismiss: !0,
                dismissLabel: this.Rs.webViewErrorInfoDismiss,
                modeless: !0,
              });
              s.open(), (this.Or = s);
            }
            mr() {
              this.Or && (this.Or.close(), (this.Or = void 0));
            }
            Oi(e = !0) {
              window.clearTimeout(this.Po),
                window.clearInterval(this.Lo),
                window.clearTimeout(this.Fo),
                this.As.showTypingIndicator &&
                  (e
                    ? (this.hideTypingIndicator(), this.Ii.setAutoTimeout(!0))
                    : (this.Ii.setAutoTimeout(!1), this.showTypingIndicator()));
            }
            ji(e) {
              const t = this.As.delegate;
              if (
                (this.ds.debug("onMessageReceived", e),
                this.Ls(),
                (this.Ms = !0),
                (this.Os = !1),
                this.As.enableDefaultClientResponse &&
                  (e.source === o.SkillMessageSource.Agent
                    ? (this.di = !1)
                    : this.di || (this.di = !0)),
                e)
              ) {
                if (
                  t &&
                  t.beforeDisplay &&
                  (0, a.isFunction)(t.beforeDisplay) &&
                  M(e)
                ) {
                  let s = (0, a.clone)(e);
                  try {
                    s = t.beforeDisplay(s);
                  } catch (e) {
                    this.ds.error(e);
                  }
                  if (!s) return;
                  (0, o.isValidMessage)(s)
                    ? (e = s)
                    : this.ds.error(
                        "The generated delegate message is invalid. Displaying original message instead."
                      );
                }
                switch (
                  (this.ii && this.ii(e), this.yr(e), e.messagePayload.type)
                ) {
                  case o.MessageType.Status: {
                    const t = e.messagePayload;
                    "RESPONDING" === t.status
                      ? this.showTypingIndicator()
                      : "LISTENING" === t.status && this.hideTypingIndicator();
                    break;
                  }
                  case o.MessageType.SessionClosed:
                    this.si && this.si();
                    break;
                  case o.MessageType.TextStream:
                    this.Eo([e]);
                    switch (e.messagePayload.streamState) {
                      case "start":
                        this.isOpen || this.updateNotificationBadge(++this.fs);
                        break;
                      case "end":
                        this.Ao(e), this.Mo(e);
                    }
                    break;
                  default:
                    this.Eo([e]),
                      this.Ao(e),
                      this.Mo(e),
                      this.isOpen || this.updateNotificationBadge(++this.fs);
                }
                this.Oi(Boolean(e.endOfTurn));
              }
            }
            uo(e) {
              this.Mo(e),
                this.Ls(),
                e &&
                  (this.yr(e),
                  e.messagePayload &&
                    y.indexOf(e.messagePayload.type) < 0 &&
                    (this.isOpen || this.updateNotificationBadge(++this.fs),
                    this.Eo([e])));
            }
            Yi(e) {
              e || this.Js(), (this.xs = !e);
            }
            Mi(e) {
              const t = this.gs.filter((t) => t.threadId === e);
              return (
                (this.st = e),
                this.Ys.setCurrentThreadId(e),
                this.clearConversationHistory(!0),
                this.Mr(t, !1)
              );
            }
            Ri() {
              this.Ho().then(() => {
                const e = this.so.getItem(this._o);
                e && (this.As.icons.avatarUser = e);
                const t = this.so.getItem(this.yo);
                t && ((this.xo = JSON.parse(t)), this.ko());
              });
            }
            jr(e) {
              const t = this.As.threadId;
              (this.gs = e.slice()),
                t ? this.Mr(e.filter((e) => e.threadId === t)) : this.Mr(e);
            }
            Zi() {
              const e = this.As;
              if (e.storageType === l.StorageType.CUSTOM) {
                const t = e.conversationHistoryProvider;
                (0, a.isFunction)(null == t ? void 0 : t.getMessages)
                  ? t
                      .getMessages({ threadId: e.threadId })
                      .then((e) => this.jr(e.messages))
                      .catch((e) =>
                        this.ds.error(
                          "Failed to fetch conversation history with provider.",
                          e
                        )
                      )
                  : this.ds.warn(
                      "Can not load conversation history. Pass conversationHistoryProvider object with getMessages function when custom storage is enabled."
                    );
              } else
                e.enableLocalConversationHistory &&
                  (this.As.clientAuthEnabled && !this.co
                    ? this.Ho().then(() => {
                        this.jr(this.getMessages());
                      })
                    : this.jr(this.getMessages()));
            }
            Mr(e, t = !0) {
              return e.length
                ? ((this.vs = !1),
                  this.Eo(e.slice(), !1).then(() => {
                    (this.vs = !0),
                      t || this.eo !== o.SenderType.Skill
                        ? this.wr()
                        : this.ao(
                            this.skillMessages.slice(
                              0,
                              this.skillMessages.length - 1
                            )
                          ),
                      this.As.searchBarMode ||
                        (!t && !this._s) ||
                        (this.Fi &&
                          (this.Fi.setRelativeTime(
                            new Date(e[e.length - 1].date)
                          ),
                          (this.gr = this.Fi.render()),
                          this.mo(this.gr)),
                        this.As.showPrevConvStatus &&
                          ((this.Io = this.ni.createTextDiv(["hr", "flex"])),
                          (this.Io.innerText = this.Rs.previousChats),
                          this.mo(this.Io)),
                        this._s && (this._s = !1));
                  }))
                : Promise.resolve();
            }
            wi() {
              var e;
              if (
                this.Ys.isConnected() &&
                this.ys &&
                (this.jo &&
                  (this.jo.disableComponent(!1), this.jo.initLanguage()),
                !this.ks)
              ) {
                const t = this.As.initUserProfile;
                if (t) {
                  const e = this.As.sdkMetadata
                    ? Object.assign(
                        { version: n.SDK_VERSION },
                        this.As.sdkMetadata
                      )
                    : { version: n.SDK_VERSION };
                  this.Ys.updateUser(t, { sdkMetadata: e })
                    .then(() => {
                      this.ks = !0;
                    })
                    .catch((e) => {
                      this.ds.error(
                        "[sendInitMessages] Failed to update user profile:",
                        e
                      );
                    });
                }
                if (this.As.initUserHiddenMessage) {
                  const e = this.As.initUserHiddenMessage;
                  this.sendMessage(e, { hidden: !0, delegate: !1 })
                    .then(() => {
                      this.ks = !0;
                    })
                    .catch(this.Bs);
                }
                if (
                  null === (e = this.As.deviceToken) || void 0 === e
                    ? void 0
                    : e.length
                ) {
                  const e = (0, a.getDeviceType)();
                  this.Ys.sendDeviceToken(
                    this.As.deviceToken,
                    this.As.deviceType || e
                  )
                    .then(() => {
                      this.ks = !0;
                    })
                    .catch((e) => {
                      this.ds.error(
                        "[sendInitMessages] Failed to send device token:",
                        e
                      );
                    });
                }
              }
            }
            Ao(e) {
              this.xs || this.Ys.speakTTS(e, this.Rs);
            }
            Js() {
              this.Ys.cancelTTS();
            }
            Li(e, t) {
              this.getAgentDetails() &&
                this.Ys.sendUserTypingStatus(e, t).catch((e) => {
                  this.ds.error(
                    "[sendUserTypingStatusMessage] Failed to send user typing status:",
                    e
                  );
                });
            }
            Wi(e) {
              if (e.hotkeys) {
                const t = new l.HotkeysManager(e);
                t.setWidget(this.chatWidgetDiv);
                const s = e.hotkeys;
                Object.keys(s).forEach((e) => {
                  const i = this.Is.get(e);
                  i && t.add(s[e], i, "launch" !== e);
                }),
                  (this.Ki = t);
              }
            }
            ro(e, t) {
              const s = document.getElementsByClassName(`${this.zt}-${e}`);
              for (const e of Array.from(s))
                for (const [s, i] of Object.entries(t)) e.style[s] = i;
            }
            br() {
              var e, t;
              (0, a.isVisible)(
                null === (e = this.Ps) || void 0 === e ? void 0 : e.element
              ) &&
                (null === (t = this._i) || void 0 === t
                  ? void 0
                  : t.isVisible()) &&
                this._i.focus();
            }
            Ks() {
              try {
                sessionStorage.setItem(this.Vo, Array.from(this.qs).toString());
              } catch (e) {
                this.ds.warn("Failed to save canceled requests in session", e);
              }
            }
            Bo() {
              try {
                const e = sessionStorage.getItem(this.Vo);
                return e ? e.split(",") : [];
              } catch (e) {
                return (
                  this.ds.warn(
                    "Failed to save canceled requests in session",
                    e
                  ),
                  []
                );
              }
            }
            Xs() {
              const e = (0, a.clone)(this.er);
              e &&
                (0, l.isBotMessage)(e) &&
                ((e.messagePayload.text = this.ho.freeze()),
                (e.messagePayload.streamState = "end"),
                (e.endOfTurn = !0),
                this.ji(e));
            }
            Ei(e, t) {
              this.Is.set(e, t);
            }
          }
          t.WidgetComponent = O;
          const M = (e) => {
            let t = !0;
            const s = e.messagePayload;
            if (s) {
              s.type === o.MessageType.TextStream && (t = !1);
            }
            return t;
          };
          t.rejectErrorTextStream = () =>
            Promise.reject(Error("TextStreamProgress"));
        },
        623: (e, t, s) => {
          Object.defineProperty(t, "p", { value: !0 }),
            (t.ContextualWidgetComponent = void 0);
          const i = s(6246),
            o = s(8098),
            r = s(2366),
            a = s(4557),
            n = s(9780),
            c = s(5915),
            l = s(28),
            h = "none",
            d = "full-size";
          class p extends a.Component {
            constructor(e, t, s, a, c, l, h, d, p) {
              super(),
                (this.As = e),
                (this.Rt = t),
                (this.zr = s),
                (this.$r = a),
                (this.Ir = c),
                (this.Cr = l),
                (this.Ys = h),
                (this.Sr = d),
                (this.ti = p),
                (this.ds = new n.Logger("ContextualWidgetComponent")),
                (this.Tr = !1),
                (this.zt = e.name),
                (this.Ar = {
                  type: i.MessageType.Text,
                  text: "",
                  globalActions: [
                    {
                      type: i.ActionType.Postback,
                      label: "Global1",
                      postback: {},
                    },
                    {
                      type: i.ActionType.Postback,
                      label: "Global2",
                      postback: {},
                    },
                    {
                      type: i.ActionType.Postback,
                      label: "Global3",
                      postback: {},
                    },
                    {
                      type: i.ActionType.Postback,
                      label: "Global4",
                      postback: {},
                    },
                  ],
                }),
                (this.threadId = `${i.ContextSource.UIWidget}:${
                  this.$r || ""
                }-${this.zr || ""}`),
                (this.Er = this.As.sdkMetadata
                  ? Object.assign(
                      { version: o.SDK_VERSION },
                      this.As.sdkMetadata
                    )
                  : { version: o.SDK_VERSION }),
                (this.As.icons = Object.assign(
                  Object.assign({}, this.As.icons),
                  { logo: o.iconInlineLogo }
                )),
                (this.Rs = Object.assign(
                  Object.assign({}, this.As.i18n.en),
                  this.As.i18n[this.As.locale]
                ));
              const {
                uploadFile: u,
                getSuggestions: g,
                $i: m,
                Pi: b,
                Li: f,
                Ei: w,
              } = this.Sr;
              (this.Ps = new r.ChatFooterComponent(
                t,
                this.sendMessage.bind(this),
                u.bind(d),
                Object.assign(Object.assign({}, this.As), {
                  enableAttachment: !1,
                }),
                g.bind(d),
                m.bind(d),
                b.bind(d),
                f.bind(d),
                this.ti,
                d,
                w.bind(d)
              )),
                (this.contextualElem = document.getElementById(this.zr)),
                (this.Pr =
                  this.contextualElem.querySelector("input, textarea")),
                (this.Lr = [
                  {
                    type: i.ActionType.Postback,
                    label: "Show more",
                    postback: { showMore: !0 },
                  },
                ]),
                (this.Fr = !1),
                (this.Nr = !1),
                (this.Rr = !1),
                (this.Dr = !0),
                (this.gi = {
                  webCore: h,
                  onMessageActionClicked: this.Hr.bind(this),
                });
            }
            render() {
              const e = this.Rt,
                t = e.createDiv(["widget-wrapper"]);
              (this.element = e.createDiv(["contextual-widget"])),
                (this.element.id = this.threadId);
              const s = e.createDiv(["container", "none"]);
              this.appendToElement(s), t.appendChild(s), (this.Ur = s);
              const i = this.contextualElem.parentNode,
                r = e.createDiv(["contextual-widget-wrapper"]);
              i.replaceChild(r, this.contextualElem),
                r.appendChild(this.contextualElem),
                document.body.appendChild(t),
                this.contextualElem.parentElement.insertBefore(
                  t,
                  this.contextualElem
                );
              const a = e.createDiv([]);
              (this.Vr = e.createDiv(["widget", "flex", "col"])),
                this.Vr.setAttribute("role", "region"),
                this.Vr.setAttribute("aria-labelledby", `${this.zt}-title`);
              const n = e.createDiv(["header", "flex"]),
                c = e.createDiv(["header-info-wrapper"]),
                l = this.Rs.chatTitle,
                d = this.As.icons;
              if (!("logo" in d) || d.logo) {
                const t = e.createImageIcon({
                  icon: d.logo || o.iconLogo,
                  iconCss: ["logo"],
                });
                n.appendChild(t);
              }
              if (l) {
                const t = e.createTextDiv(["title"]);
                (t.id = `${this.zt}-contextual-title`),
                  (t.innerText = l),
                  (t.title = l),
                  c.appendChild(t);
              }
              n.appendChild(c);
              const p = e.createIconButton({
                css: ["start-over-button", h],
                icon: o.iconStartOver,
                iconCss: [],
                title: "Start Again",
              });
              (p.onclick = () => {
                this.Pr
                  ? (this.Pr.value = "")
                  : this.ds.error(
                      "The input element is not found for clearing the filled-in text."
                    ),
                  (this.Dr = !0),
                  (this.Tr = !0),
                  e.addCSSClass(p, h),
                  this.Br();
              }),
                n.appendChild(p),
                (this.Wr = p);
              const u = e.createIconButton({
                css: ["close-button"],
                icon: d.close || o.iconClose,
                iconCss: [],
                title: "close",
              });
              (u.onclick = this.Zr.bind(this)),
                n.appendChild(u),
                this.Vr.appendChild(n),
                (this.Gr = e.createDiv(["widget-content"])),
                this.Vr.appendChild(this.Gr),
                this.Ps.render(),
                this.Ps.disable(!1),
                this.Vr.appendChild(this.Ps.element),
                e.addCSSClass(a, "open"),
                a.appendChild(this.Vr),
                e.addCSSClass(this.element, "wrapper", this.As.theme),
                this.element.appendChild(a),
                this.Ar.globalActions && (this.qr = this.Ar.globalActions),
                this.Yr(!0);
            }
            sendMessage(e, t = !0) {
              return this.ho
                ? (0, l.rejectErrorTextStream)()
                : ("string" == typeof e && (e = (0, i.buildUserTextMessage)(e)),
                  this.Ps.focusTextArea(),
                  e &&
                    this.Ys.sendMessage(e, {
                      sdkMetadata: this.Er,
                      threadId: this.threadId,
                    })
                      .then(() => {
                        (this.Rr = !1),
                          this.Rt.removeCSSClass(this.Wr, h),
                          t && this.Jr();
                      })
                      .catch((e) =>
                        this.ds.error(
                          "[sendMessage] Failed to send message:",
                          e
                        )
                      ));
            }
            onMessageReceived(e) {
              var t, s;
              const r = this.As,
                a = this.Pr,
                l = this.Rt;
              if (
                ((this.Nr = !1),
                this.Fr ||
                  (l.addCSSClass(this.Ps.element, "enabled"), (this.Fr = !0)),
                e.messagePayload.llmGenerated)
              ) {
                const t = n.MessageComponentFactory.fromMessage(
                  r,
                  l,
                  e,
                  this.gi
                );
                if (!t) return;
                if (
                  ((this.Rr = !0), t instanceof c.TextStreamMessageComponent)
                ) {
                  const s = e.messagePayload;
                  switch (s.streamState) {
                    case "start":
                      return (
                        this.Ps.disable(),
                        (t.isCoPilot = !0),
                        (t.showDone = this.Kr.bind(this)),
                        void (this.Xr
                          ? this.Xr(s)
                          : a
                          ? ((t.textElement = a), t.update(s), (this.ho = t))
                          : this.ds.error(
                              "The input element is not found for filling in the generated text."
                            ))
                      );
                    case "running":
                      return void (this.Xr ? this.Xr(s) : this.ho.update(s));
                    case "end":
                      this.Ps.disable(!1),
                        this.Xr
                          ? (this.Xr(s), this.Kr())
                          : (this.ho.update(s), (this.ho = null)),
                        (this.Dr = !1),
                        (s.text = ""),
                        this.pr(e);
                  }
                } else if (
                  ((this.ho = null),
                  (this.Dr = !1),
                  t instanceof c.TextMessageComponent)
                ) {
                  const t = e.messagePayload;
                  this.Xr
                    ? this.Xr(t)
                    : ((a.innerHTML = (0, o.convertBreakTagsToNewLines)(
                        t.text
                      )),
                      (t.text = ""),
                      this.pr(e)),
                    this.Zr();
                }
              } else if (
                null === (t = e.messagePayload.channelExtensions) ||
                void 0 === t
                  ? void 0
                  : t.showInDialog
              ) {
                const t = l.createDiv(["wrapper", "popup-content-wrapper"]),
                  s = l.createDiv(["popup-dialog"]),
                  i = n.MessageComponentFactory.fromMessage(r, l, e, this.gi);
                (i.onActionClick = this.Hr.bind(this)),
                  s.appendChild(i.render()),
                  t.appendChild(s);
                const o = i.actionsWrapper;
                if (o) {
                  const e = o.children;
                  for (let s = 0; s < e.length; s++)
                    e[s].addEventListener("click", () => t.remove());
                }
                (t.onclick = (e) => {
                  s.contains(e.target) || t.remove();
                }),
                  document.body.appendChild(t),
                  (this.Dr = !1),
                  this.Zr();
              } else if (
                ((this.Dr = !1), e.messagePayload.type === i.MessageType.Error)
              ) {
                if (
                  ((this.Nr = !0),
                  null === (s = this.Gr.firstChild) ||
                    void 0 === s ||
                    s.remove(),
                  !this.Qr)
                ) {
                  const e = l.createDiv(["error-message"]);
                  e.appendChild(
                    l.createImageIcon({
                      icon: o.iconInlineError,
                      iconCss: ["error-icon"],
                    })
                  );
                  const t = l.createDiv(["error-info"]),
                    s = l.createTextDiv(["error-text"]),
                    i = l.createTextDiv(["reset-button"]);
                  (i.onclick = () => {
                    (this.Nr = !1), (this.Dr = !0), this.Br();
                  }),
                    (s.innerText = "Something went wrong"),
                    (i.innerText = "Start over"),
                    t.appendChild(s),
                    t.appendChild(i),
                    e.appendChild(t),
                    (this.Qr = e);
                }
                this.Gr.appendChild(this.Qr), this.Br();
              } else this.pr(e), this.showFullSizeWidget();
            }
            addText(e) {
              return (this.Ar.text = e), this;
            }
            addAction(e, t, s = !1) {
              return (
                this.Lr.push({
                  type: i.ActionType.Postback,
                  label: e,
                  postback: { actionId: t, generate: s },
                }),
                this
              );
            }
            addFieldInputParameter(e, t, s) {
              return (
                this.Lr.forEach((i) => {
                  const o = i.postback;
                  o.actionId === e &&
                    (o.fieldInputParameters || (o.fieldInputParameters = {}),
                    (o.fieldInputParameters[t] = s));
                }),
                this
              );
            }
            addAdditionalInputParameter(e, t, s) {
              return (
                this.Lr.forEach((i) => {
                  const o = i.postback;
                  o.actionId === e &&
                    (o.additionalInputParameters ||
                      (o.additionalInputParameters = {}),
                    (o.additionalInputParameters[t] = s));
                }),
                this
              );
            }
            createWidget() {
              const e = this.contextualElem;
              return (
                this.element || this.render(),
                this.Ir &&
                  e.addEventListener("focus", () => {
                    this.showWidget();
                  }),
                this
              );
            }
            showWidget() {
              const e = this.Cr;
              return (
                Object.keys(e)
                  .filter((e) => e !== this.threadId)
                  .forEach((t) => {
                    e[t].hideWidget();
                  }),
                this.Rt.removeCSSClass(this.Ur, h),
                this
              );
            }
            collapseWidget() {
              return this.Zr(), this;
            }
            hideWidget() {
              return this.Rt.addCSSClass(this.Ur, h), this;
            }
            startWidgetInteraction(e) {
              return this.ea(this.ta(e)), this;
            }
            onGeneratedText(e) {
              return (this.Xr = e), this;
            }
            pr(e) {
              var t;
              const s = n.MessageComponentFactory.fromMessage(
                Object.assign(Object.assign({}, this.As), {
                  actionsLayout: "horizontal",
                  globalActionsLayout: "horizontal",
                }),
                this.Rt,
                e,
                this.gi
              );
              (s.onActionClick = this.Hr.bind(this)),
                null === (t = this.Gr.firstChild) || void 0 === t || t.remove(),
                this.Gr.appendChild(s.render());
            }
            Yr(e = !1) {
              this.Dr &&
                (e
                  ? (1 === this.Lr.length
                      ? (this.Ar.actions = this.Lr.slice(0))
                      : (this.Ar.actions = this.Lr.slice(0, 2).reverse()),
                    (this.Ar.globalActions = []))
                  : ((this.Ar.actions = this.Lr.slice(1)),
                    this.qr && (this.Ar.globalActions = this.qr.slice(0))),
                this.pr({ messagePayload: this.Ar }));
            }
            Zr() {
              const e = this.Rt;
              if (!this.sa) {
                const t = e.createDiv([
                    "minimum-size",
                    "contextual-widget",
                    "wrapper",
                  ]),
                  s = e.createIconButton({
                    css: [],
                    icon: o.iconInlineLaunch,
                    iconCss: [],
                    title: "open",
                  }),
                  r = e.createIconButton({
                    css: [],
                    icon: o.iconThumbsUp,
                    iconCss: [],
                    title: "like",
                  }),
                  a = e.createIconButton({
                    css: [],
                    icon: o.iconThumbsDown,
                    iconCss: [],
                    title: "dislike",
                  });
                (s.onclick = () => {
                  this.Dr || this.Nr ? this.Br() : this.showFullSizeWidget();
                }),
                  (r.onclick = () => {
                    this.sendMessage(
                      (0, i.buildPostbackMessage)({
                        postback: { rating: "positive", feedbackType: "llm" },
                        type: i.ActionType.Postback,
                      }),
                      !1
                    );
                  }),
                  (a.onclick = () => {
                    this.sendMessage(
                      (0, i.buildPostbackMessage)({
                        postback: { rating: "negative", feedbackType: "llm" },
                        type: i.ActionType.Postback,
                      }),
                      !1
                    );
                  }),
                  t.appendChild(s),
                  t.appendChild(r),
                  t.appendChild(a),
                  this.Ur.appendChild(t),
                  (this.sa = t);
              }
              e.removeCSSClass(this.element, d),
                e.addCSSClass(this.element, h),
                this.ia && e.addCSSClass(this.ia, h),
                this.oa && e.addCSSClass(this.oa, h),
                e.removeCSSClass(this.sa, h),
                this.Rr
                  ? e.removeCSSClass(this.sa, "no-feedback")
                  : e.addCSSClass(this.sa, "no-feedback");
            }
            Br() {
              const e = this.Rt;
              this.sa && e.addCSSClass(this.sa, h),
                this.ia && e.addCSSClass(this.ia, h),
                this.oa && e.addCSSClass(this.oa, h),
                e.removeCSSClass(this.element, d),
                e.removeCSSClass(this.element, h),
                this.Yr(!0),
                (this.Rr = !1);
            }
            showFullSizeWidget() {
              const e = this.Rt;
              this.sa && e.addCSSClass(this.sa, h),
                this.ia && e.addCSSClass(this.ia, h),
                this.oa && e.addCSSClass(this.oa, h),
                e.addCSSClass(this.element, h),
                this.Yr(),
                e.addCSSClass(this.element, d);
            }
            Jr() {
              const e = this.Rt;
              if (!this.ia) {
                const t = e.createDiv(["generate-spinner"]),
                  s = e.createTextDiv(["generate-text"]);
                (s.innerText = "Generating..."),
                  t.appendChild(
                    e.createImageIcon({
                      icon: o.iconGenerating,
                      iconCss: ["generate-icon", "spin"],
                    })
                  );
                const i = e.createIconButton({
                  css: ["close-button", h],
                  icon: o.iconClose,
                  iconCss: [],
                  title: "close",
                });
                (i.onclick = this.Zr.bind(this)),
                  t.appendChild(s),
                  t.appendChild(i),
                  this.Ur.appendChild(t),
                  (this.ia = t);
              }
              this.sa && e.addCSSClass(this.sa, h),
                this.oa && e.addCSSClass(this.oa, h),
                e.removeCSSClass(this.element, d),
                e.addCSSClass(this.element, h),
                e.removeCSSClass(this.ia, h);
            }
            Kr() {
              const e = this.Rt;
              if (!this.oa) {
                const t = e.createDiv(["generate-spinner"]),
                  s = e.createTextDiv(["generate-text"]);
                (s.innerText = "Done"),
                  t.appendChild(
                    e.createImageIcon({
                      icon: o.iconCheck,
                      iconCss: ["generate-icon"],
                    })
                  ),
                  t.appendChild(s),
                  this.Ur.appendChild(t),
                  (this.oa = t);
              }
              this.sa && e.addCSSClass(this.sa, h),
                e.addCSSClass(this.ia, h),
                e.removeCSSClass(this.oa, h),
                e.removeCSSClass(this.element, d),
                e.addCSSClass(this.element, h),
                setTimeout(this.Zr.bind(this), 3e3);
            }
            Hr(e) {
              switch (e.type) {
                case i.ActionType.Postback:
                  e.getPayload().then((t) => {
                    (null == t ? void 0 : t.generate)
                      ? this.ea(
                          Object.assign(
                            Object.assign(
                              {},
                              (0, o.getFieldInputValues)(t.fieldInputParameters)
                            ),
                            t.additionalInputParameters
                          )
                        )
                      : (null == t ? void 0 : t.showMore)
                      ? this.showFullSizeWidget()
                      : this.sendMessage(
                          (0, i.buildPostbackMessage)({
                            postback: t,
                            text: e.label,
                            type: i.MessageType.Postback,
                          })
                        );
                  });
                  break;
                case i.ActionType.SubmitForm:
                  const t = e.messageComponent;
                  if (!t.validateForm()) break;
                  e.getPayload().then((e) => {
                    const s = {
                      postback: e,
                      submittedFields: t.getSubmittedFields(),
                      type: i.MessageType.FormSubmission,
                    };
                    e || delete s.postback,
                      this.sendMessage((0, i.buildUserMessage)(s));
                  });
              }
            }
            ea(e) {
              this.sendMessage({
                messagePayload: {
                  type: i.MessageType.UpdateApplicationContextCommand,
                  source: i.ContextSource.UIWidget,
                  context: this.$r,
                  properties: e,
                  reset: this.Tr,
                },
              });
            }
            ta(e) {
              let t;
              return (
                this.Lr.forEach((s) => {
                  const i = s.postback,
                    { fieldInputParameters: r, additionalInputParameters: a } =
                      i;
                  i.actionId === e &&
                    (t = Object.assign(
                      Object.assign({}, (0, o.getFieldInputValues)(r)),
                      a
                    ));
                }),
                t
              );
            }
          }
          t.ContextualWidgetComponent = p;
        },
        6992: function (e, t, s) {
          var i =
              (this && this.t) ||
              (Object.create
                ? function (e, t, s, i) {
                    void 0 === i && (i = s);
                    var o = Object.getOwnPropertyDescriptor(t, s);
                    (o &&
                      !("get" in o ? !t.p : o.writable || o.configurable)) ||
                      (o = {
                        enumerable: !0,
                        get: function () {
                          return t[s];
                        },
                      }),
                      Object.defineProperty(e, i, o);
                  }
                : function (e, t, s, i) {
                    void 0 === i && (i = s), (e[i] = t[s]);
                  }),
            o =
              (this && this.u) ||
              function (e, t) {
                for (var s in e)
                  "default" === s ||
                    Object.prototype.hasOwnProperty.call(t, s) ||
                    i(t, e, s);
              };
          Object.defineProperty(t, "p", { value: !0 }),
            o(s(7739), t),
            o(s(28), t),
            o(s(623), t),
            o(s(4810), t);
        },
        4810: (e, t, s) => {
          Object.defineProperty(t, "p", { value: !0 }),
            (t.SearchBarWidgetComponent = void 0);
          const i = s(2366),
            o = s(4557),
            r = s(9780),
            a = s(5915),
            n = "none";
          class c extends o.Component {
            constructor(e, t, s, o, n, c) {
              super(),
                (this.As = e),
                (this.ni = t),
                (this.Ys = s),
                (this.Sr = o),
                (this.ye = n),
                (this.ti = c),
                (this.ds = new r.Logger("SearchBarWidgetComponent"));
              const {
                getSuggestions: l,
                sendMessage: h,
                uploadFile: d,
                $i: p,
                Pi: u,
                Li: g,
                Ei: m,
              } = this.Sr;
              (this.Ps = new i.ChatFooterComponent(
                this.ni,
                h.bind(o),
                d.bind(o),
                this.As,
                l.bind(o),
                p.bind(o),
                u.bind(o),
                g.bind(o),
                this.ti,
                o,
                m.bind(o)
              )),
                this.As.showTypingIndicator &&
                  (this.Ii = new a.TypingIndicatorComponent(
                    a.MESSAGE_SIDE.LEFT,
                    this.As,
                    this.ni
                  ));
            }
            get footer() {
              return this.Ps;
            }
            get typingIndicator() {
              return this.Ii;
            }
            render() {
              return this.ra();
            }
            appendMessageToConversation(e) {
              const t = this.Hi;
              (t.textContent = ""),
                t.appendChild(e),
                this.ni.removeCSSClass(t, n);
            }
            renderMessage(e, t, s) {
              const i = this.Hi,
                o = this.ni,
                a = "skill-message";
              if (i) {
                (0, r.isBotMessage)(e) || (i.textContent = "");
                const n = this.pr(e, t, i);
                if (n) {
                  (0, r.isBotMessage)(e)
                    ? o.addCSSClass(n, a)
                    : o.addCSSClass(n, "user-message");
                  const t = this.aa;
                  s &&
                  (null == t
                    ? void 0
                    : t.className.includes(`${this.As.name}-${a}`))
                    ? t.replaceWith(n)
                    : i.appendChild(n),
                    (this.aa = n);
                }
              }
            }
            showMessage(e, t) {
              const s = this.ni.getMessage(t.render());
              (s.id = e), this.Hi.appendChild(s);
            }
            ra() {
              const e = this.As,
                t = document.getElementById(e.targetElement);
              let s;
              if (t) {
                const e = this.ni,
                  i = e.createDiv(["search-bar-widget-wrapper", "wrapper"]),
                  o = e.createDiv(["search-bar-widget"]),
                  r = e.createDiv(["search-bar-widget-content"]);
                (s = e.createDiv(["search-bar-popup", n])),
                  (this.element = t),
                  (this.Sr.element = t),
                  this.Ps.render();
                const a = this.Ps.element.querySelector("textarea"),
                  c = this.Ps.getSuggestionsList(),
                  l = (t) => {
                    const o = t.target;
                    o.isConnected &&
                      !i.contains(o) &&
                      ("true" === a.getAttribute("aria-expanded")
                        ? e.addCSSClass(c, n)
                        : e.addCSSClass(s, n),
                      document.removeEventListener("click", l));
                  },
                  h = () => {
                    (null == c ? void 0 : c.hasChildNodes())
                      ? e.removeCSSClass(c, n)
                      : e.removeCSSClass(s, n),
                      document.addEventListener("click", l);
                  };
                this.Ys.isConnected() || this.ye(),
                  e.setChatWidgetWrapper(i),
                  r.appendChild(s),
                  o.appendChild(r),
                  i.appendChild(this.Ps.element),
                  i.appendChild(o),
                  t.appendChild(i),
                  (this.Hi = s),
                  a.addEventListener("input", () => {
                    a.value && (null == c ? void 0 : c.hasChildNodes())
                      ? e.addCSSClass(s, n)
                      : e.removeCSSClass(s, n);
                  }),
                  document.addEventListener("click", l),
                  this.Ps.element.addEventListener("click", () =>
                    document.addEventListener("click", l)
                  ),
                  a.addEventListener("focus", h),
                  a.addEventListener("click", h),
                  null == c ||
                    c.addEventListener("click", () => {
                      setTimeout(() => {
                        c.childElementCount &&
                          document.removeEventListener("click", l);
                      });
                    });
              } else
                this.ds.error(
                  `Cannot fetch search bar using the passed target element: ${e.targetElement}`
                );
              return s;
            }
            pr(e, t, s) {
              const i = this.As.delegate;
              if (i && i.render) {
                const t = this.ni.createDiv(["message"]);
                (t.id = e.msgId), (t.lang = this.As.locale), s.appendChild(t);
                if (i.render(e)) return null;
                t.remove();
              }
              return t.render();
            }
          }
          t.SearchBarWidgetComponent = c;
        },
        1816: (e, t, s) => {
          Object.defineProperty(t, "p", { value: !0 }),
            (t.Autocomplete = void 0);
          const i = s(6064),
            o = s(8098),
            r = "aria",
            a = `${r}-expanded`,
            n = `${r}-selected`,
            c = `${r}-activedescendant`,
            l = "autocomplete-active";
          t.Autocomplete = class {
            constructor(e, t, s) {
              (this.na = e),
                (this.ni = s),
                (this.ca = -1),
                (this.la = this.ha(t)),
                (0, o.setAttributes)(e, {
                  "aria-autocomplete": "list",
                  "aria-controls": t,
                  [a]: "false",
                  autocomplete: "off",
                  role: "combobox",
                });
            }
            display(e, t) {
              this.da(),
                (this.le = e.map((s, i) => {
                  const o = this.pa(i, e.length);
                  return (
                    this.ua(o, s, t),
                    (o.onclick = () => {
                      (this.na.value = s), this.hide();
                    }),
                    this.la.appendChild(o),
                    o
                  );
                })),
                this.na.setAttribute(a, "true");
            }
            hide() {
              this.na.setAttribute(a, "false"),
                this.na.removeAttribute(c),
                this.da();
            }
            isOpen() {
              return "true" === this.na.getAttribute(a);
            }
            handleKeyboardEvent(e) {
              let t = !1;
              if (e.ctrlKey) return t;
              const s = this.le.length;
              switch (e.code) {
                case i.KeyCode.Return:
                case i.KeyCode.Space:
                case i.KeyCode.Tab:
                  this.ga && d(this.na, this.ga.textContent), this.hide();
                  break;
                case i.KeyCode.Down:
                  (this.ca = (this.ca + 1) % s), (t = !0);
                  break;
                case i.KeyCode.Up:
                  (this.ca = this.ca < 0 ? s - 1 : (this.ca - 1 + s) % s),
                    (t = !0);
                  break;
                case i.KeyCode.Esc:
                  this.hide(), this.na.focus();
              }
              return (
                t &&
                  (e.stopPropagation(),
                  e.preventDefault(),
                  this.ma(this.le[this.ca])),
                t
              );
            }
            getListbox() {
              return this.la;
            }
            ha(e) {
              const t = this.ni.createElement("ul", ["autocomplete-items"]);
              return (
                (t.id = e),
                (0, o.setAttributes)(t, {
                  "aria-labelledby": `${this.na.id}-label`,
                  "aria-live": "polite",
                  role: "listbox",
                }),
                (0, o.on)(t, "keydown", (e) => {
                  this.na.dispatchEvent(new KeyboardEvent(e.type, e));
                }),
                t
              );
            }
            pa(e, t) {
              const s = this.ni.createElement("li", ["autocomplete-item"]);
              return (
                (s.id = `${this.la.id}item-${e + 1}`),
                (s.tabIndex = -1),
                (0, o.setAttributes)(s, {
                  "aria-posinset": (e + 1).toString(),
                  "aria-setsize": t.toString(),
                  [n]: "false",
                  role: "option",
                }),
                s
              );
            }
            ua(e, t, s) {
              const i = t.toLowerCase().indexOf(s),
                o = this.ni.createTextSpan();
              if ((o.setAttribute("aria-hidden", "true"), i >= 0)) {
                const e = h(t.substring(0, i)),
                  r = this.ni.createElement("strong", [], !0);
                r.textContent = t.substring(i, i + s.length);
                const a = h(t.substring(i + s.length));
                o.append(e, r, a);
              } else o.textContent = t;
              e.append(o), e.setAttribute("aria-label", t);
            }
            ma(e) {
              const t = this.ga;
              t && (this.ni.removeCSSClass(t, l), t.setAttribute(n, "false")),
                e &&
                  (e.scrollIntoView(!1),
                  e.setAttribute(n, "true"),
                  this.ni.addCSSClass(e, l),
                  (this.ga = e),
                  this.na.setAttribute(c, e.id));
            }
            da() {
              const e = this.la;
              for (; e.firstChild; ) e.removeChild(e.lastChild);
              (this.le = []), (this.ga = null), (this.ca = -1);
            }
          };
          const h = (e) => document.createTextNode(e),
            d = (e, t) => {
              (e.value = t), e.setSelectionRange(t.length, t.length);
            };
        },
        9571: (e, t, s) => {
          Object.defineProperty(t, "p", { value: !0 }),
            (t.ChatFooterComponent = void 0);
          const i = s(6064),
            o = s(8098),
            r = s(1816),
            a = s(4557),
            n = s(9780),
            c = {
              ARROW_DOWN: "ArrowDown",
              ARROW_UP: "ArrowUp",
              ENTER: "Enter",
            },
            l = "keyboard",
            h = "voice",
            d = {
              AUDIO:
                ".aac, .amr, .m4a, .mp3, .mp4a, .mpga, .oga, .ogg, .wav, audio/*",
              FILE: ".7z, .csv, .doc, .docx, .eml, .ics, .key, .log, .msg, .neon, .numbers, .odt, .pages, .pdf, .pps, .ppsx, .ppt, .pptx, .rtf, .txt, .vcf, .xls, .xlsx, .xml, .yml, .yaml, application/msword, application/vnd.openxmlformats-officedocument.wordprocessingml.document",
              IMAGE:
                ".gif, .jfif, .jpeg, .jpg, .png, .svg, .tif, .tiff, .webp, image/*",
              VIDEO:
                ".3g2, .3gp, .avi, .m4v, .mov, .mp4, .mpeg, .mpg, .ogv, .qt, .webm, .wmv, video/*",
              ALL: "",
            };
          d.ALL = `${d.AUDIO},${d.FILE},${d.IMAGE},${d.VIDEO}`;
          const p = window.setTimeout;
          class u extends a.Component {
            constructor(e, t, s, r, a, n, c, l, h, d, p) {
              super(),
                (this.ni = e),
                (this.ba = t),
                (this.fa = s),
                (this.As = r),
                (this.wa = a),
                (this.$i = n),
                (this.va = c),
                (this.Li = l),
                (this.ti = h),
                (this.xa = d),
                (this.Ei = p),
                (this.mode = void 0),
                (this.ka = o.ATTACHMENT_MAX_SIZE),
                (this.ya = []),
                (this._a = !1),
                (this.Oa = !1),
                (this.Ma = !1),
                (this.ja = !0),
                (this.za = (0, o.throttle)((e) => {
                  this.ti.trigger(o.ChatEvent.TYPING, e);
                }, 1e3)),
                (this.$a = (0, o.throttle)((e) => {
                  this.Li(
                    "RESPONDING",
                    this.As.enableAgentSneakPreview ? e : "..."
                  );
                }, this.As.typingStatusInterval * o.SEC_MULTIPLIER)),
                (this.zt = r.name),
                (this.Ia = r.i18n),
                (this.Ca = r.icons),
                (this.Rs = Object.assign(
                  Object.assign({}, this.Ia.en),
                  this.Ia[r.locale]
                )),
                (this.ja = !(0, i.isMobile)()),
                (this.Sa = `${this.zt}-share-button`);
            }
            render() {
              if (((this.element = this.Ui()), this.As.enableSpeech)) {
                const e = this.Ta();
                this.element.appendChild(e);
              }
              const e = this.Aa();
              this.element.appendChild(e),
                this.setInputMode(l),
                this.disable(),
                window.addEventListener(
                  "resize",
                  (0, o.debounce)(() => {
                    this.Ea();
                  }, 100)
                );
            }
            setInputMode(e) {
              e !== this.mode &&
                (this.As.enableSpeech
                  ? ((this.mode = e), this.mode === l ? this.Pa() : this.La())
                  : ((this.mode = l), this.Pa()));
            }
            setUserInputText(e) {
              this.Fa &&
                ((this.Fa.value = e),
                this.Fa.setSelectionRange(e.length, e.length),
                this.focusTextArea(),
                this.Na());
            }
            getUserInputText() {
              return this.Fa.value;
            }
            setUserInputPlaceholder(e) {
              this.Fa && (this.mode === l ? this.Ra(e) : (this.Da = e));
            }
            setRecognitionRequested(e) {
              this.Ma = e;
            }
            setVoiceRecording(e) {
              this.As.enableSpeech &&
                (e && this.Ma
                  ? this.setInputMode(h)
                  : e || this.setInputMode(l));
            }
            updateVisualizer(e, t) {
              this.mode === h && (0, i.drawVisualizer)(e, this.Ha, t);
            }
            focusTextArea() {
              this.ja && this.Fa.focus(),
                (this.Fa.scrollTop = this.Fa.scrollHeight);
            }
            disable(e = !0) {
              const t = this.ni,
                s = "disabled";
              this.As.enableAttachment && (this.Ua.disabled = e),
                e
                  ? (t.addCSSClass(this.Fa, s),
                    this.As.enableAutocomplete && (this.Va(), this.Ba()))
                  : t.removeCSSClass(this.Fa, s),
                this.As.enableSpeech &&
                  (this.setInputMode(l),
                  this.disableVoiceModeButton(e, { src: "network" })),
                (this.Wa = e),
                this.Na();
            }
            isDisabled() {
              return this.Wa;
            }
            disableVoiceModeButton(e, { src: t }) {
              if (this.As.enableSpeech) {
                switch (t) {
                  case "lang":
                    this._a = e;
                    break;
                  case "network":
                    this.Oa = e;
                }
                this.As.multiLangChat && (this._a || this.Oa)
                  ? (this.Za.disabled = !0)
                  : (this.Za.disabled = this.Oa);
              }
            }
            displaySuggestions(e) {
              if (
                ((this.Ga = e),
                (this.qa = e.length > 0),
                !this.qa || !this.Fa.value)
              )
                return void this.Ba();
              const t = this.Fa.value.trim().toLowerCase();
              this.Ya.display(
                e.slice(
                  0,
                  Math.min(e.length, o.Constants.MAX_SUGGESTIONS_COUNT)
                ),
                t
              );
            }
            getSuggestions() {
              return this.Ga;
            }
            getSuggestionsValid() {
              return this.qa;
            }
            getSuggestionsList() {
              var e;
              return null === (e = this.Ya) || void 0 === e
                ? void 0
                : e.getListbox();
            }
            setLocale(e) {
              (this.Rs = e),
                this.Ua &&
                  (m(this.Ua, e.upload),
                  this.Ja.querySelectorAll("li").forEach((e) => {
                    const t = e.dataset.value,
                      s =
                        this.Rs[
                          `share${
                            t.charAt(0).toUpperCase() +
                            t.substring(1).toLowerCase()
                          }`
                        ] ||
                        this.Rs[t] ||
                        e;
                    e.querySelector("span").innerText = s;
                  })),
                this.setUserInputPlaceholder(e.inputPlaceholder),
                this.Ka && m(this.Ka, e.send),
                this.Za && m(this.Za, e.speak),
                this.Xa && m(this.Xa, e.inputPlaceholder);
            }
            updateInputHeight() {
              this.Ea();
            }
            Ui() {
              return this.ni.createDiv(["footer"]);
            }
            Pa() {
              var e;
              const t = this.ni;
              t.removeCSSClass(this.element, "mode-voice"),
                t.addCSSClass(this.element, "mode-keyboard"),
                this.Ra(this.Da),
                (this.Fa.disabled = !1),
                this.Na(),
                this.As.enableAutocomplete &&
                  (null === (e = this.Fa.value) || void 0 === e
                    ? void 0
                    : e.trim().length) >= 3 &&
                  this.Qa();
            }
            La() {
              const e = this.ni;
              e.removeCSSClass(this.element, "mode-keyboard"),
                e.addCSSClass(this.element, "mode-voice"),
                (this.Da = this.Fa.placeholder),
                this.Ra(this.Rs.recognitionTextPlaceholder),
                (this.Fa.disabled = !0),
                this.Na(),
                this.Ba();
            }
            Aa() {
              var e;
              const t = this.ni,
                s = t.createDiv(["footer-mode-keyboard", "flex"]),
                i =
                  null === (e = this.As.icons) || void 0 === e
                    ? void 0
                    : e.footerLogo;
              i &&
                s.appendChild(
                  t.createImageIcon({ icon: i, iconCss: ["footer-logo"] })
                ),
                this.tn(s);
              const o = t.createDiv(["footer-actions", "flex"]),
                r = this.sn();
              if (
                ((this.Ka = r),
                this.Ei("send", r),
                o.appendChild(r),
                this.As.enableSpeech &&
                  ((this.Za = this.rn()),
                  o.appendChild(this.Za),
                  (this.Xa = this.an()),
                  o.appendChild(this.Xa)),
                this.As.enableAttachment)
              ) {
                const e = this.nn();
                o.appendChild(e);
              }
              return s.appendChild(o), s;
            }
            nn() {
              const e = this.ni,
                t = e.createDiv(),
                s = g(this.ni, {
                  css: ["button-upload", "flex"],
                  customIcon: this.Ca.shareMenu,
                  defaultIcon: o.iconAttach,
                  title: this.Rs.upload,
                });
              s.id = this.Sa;
              const i = e.createElement("input", ["none"]);
              (i.type = "file"),
                (i.tabIndex = -1),
                i.setAttribute("aria-hidden", "true"),
                (this.cn = i),
                (this.Ja = this.ln(s));
              const r = e.getMenuButton({
                button: s,
                menuId: this.Ja.id,
                menu: this.Ja,
                widget: this.As.searchBarMode
                  ? this.xa.element
                  : this.xa.chatWidgetDiv,
              });
              return (
                (0, o.on)(r, "click", () => {
                  this.Ba();
                }),
                (this.Ua = r),
                this.Ei("shareMenu", r),
                document.addEventListener(
                  "deviceready",
                  () => {
                    const e = globalThis
                      ? globalThis.device
                      : window
                      ? window.device
                      : void 0;
                    "Android" === (null == e ? void 0 : e.platform) &&
                      this.cn.removeAttribute("accept");
                  },
                  !1
                ),
                (0, o.on)(i, "click", () => (i.value = null)),
                (0, o.on)(i, "change", (e) => {
                  const t = e.target;
                  t.files && t.files.length && this.hn(t.files[0]);
                }),
                t.appendChild(this.Ua),
                t.appendChild(this.Ja),
                t.appendChild(i),
                t
              );
            }
            ln(e) {
              return this.ni.getMenu({
                menuId: `${this.As.name}-share-menu`,
                menuClassList: ["share-popup-list"],
                buttonId: this.Sa,
                menuItems: this.dn(),
                menuButton: e,
              });
            }
            dn() {
              const e = this.ni,
                t = this.Ca,
                s = this.Rs,
                i = this.cn,
                r = `${this.zt}-share-`;
              let a = this.As.shareMenuItems;
              const c = [],
                l = [
                  n.ShareCategory.AUDIO,
                  n.ShareCategory.FILE,
                  n.ShareCategory.LOCATION,
                  n.ShareCategory.VISUAL,
                ],
                h = new Set();
              if (
                (((null == a ? void 0 : a.length) &&
                  !a.every(
                    (e) =>
                      "string" == typeof e && l.indexOf(e.toLowerCase()) < 0
                  )) ||
                  (a = l),
                a.forEach((e) => {
                  "string" == typeof e && h.add(e.toLowerCase());
                }),
                h.has(n.ShareCategory.VISUAL))
              ) {
                const a = `${r}visual`,
                  n = t.shareMenuVisual || o.iconShareMedia,
                  l = e.createListItem(
                    a,
                    s.shareVisual,
                    "visual",
                    n,
                    "share-popup-item",
                    () => {
                      (i.accept = `${d.IMAGE},${d.VIDEO}`), i.click();
                    }
                  );
                c.push(l), this.Ei("shareMenuVisual", l);
              }
              if (h.has(n.ShareCategory.AUDIO)) {
                const a = `${r}audio`,
                  n = t.shareMenuAudio || o.iconShareAudio,
                  l = e.createListItem(
                    a,
                    s.shareAudio,
                    "audio",
                    n,
                    "share-popup-item",
                    () => {
                      (i.accept = d.AUDIO), i.click();
                    }
                  );
                c.push(l), this.Ei("shareMenuAudio", l);
              }
              if (h.has(n.ShareCategory.FILE)) {
                const a = `${r}file`,
                  n = t.shareMenuFile || o.iconShareFile,
                  l = e.createListItem(
                    a,
                    s.shareFile,
                    "file",
                    n,
                    "share-popup-item",
                    () => {
                      (i.accept = d.FILE), i.click();
                    }
                  );
                c.push(l), this.Ei("shareMenuFile", l);
              }
              if (h.has(n.ShareCategory.LOCATION)) {
                const i = `${r}location`,
                  a = t.shareMenuLocation || o.iconShareLocation,
                  n = e.createListItem(
                    i,
                    s.shareLocation,
                    "location",
                    a,
                    "share-popup-item",
                    () => this.va()
                  );
                c.push(n), this.Ei("shareMenuLocation", n);
              }
              const p = t.shareMenuFile || o.iconShareFile;
              return (
                this.As.shareMenuItems
                  .filter(
                    (e) => "string" != typeof e && "string" == typeof e.type
                  )
                  .forEach((t) => {
                    const r = t.type.toLowerCase(),
                      a = `share_${
                        r.indexOf("*") >= 0 ? "all" : r.replace(/ /g, "_")
                      }`,
                      n = `${this.zt}-${a}`,
                      l = s[a] || this.Ia.en[a];
                    let h = t.label;
                    l ? (h = l) : (this.Ia.en[a] = h);
                    const u = t.icon || p,
                      g =
                        t.maxSize && t.maxSize >= 1
                          ? Math.min(
                              t.maxSize * o.BYTE_MULTIPLIER,
                              o.ATTACHMENT_MAX_SIZE
                            )
                          : o.ATTACHMENT_MAX_SIZE;
                    let m = "";
                    "wcfs_*" !== r &&
                      (m =
                        r.indexOf("*") >= 0 && "wcfs_*" !== r
                          ? d.ALL
                          : r
                              .split(" ")
                              .map((e) => `.${e} `)
                              .join(",")),
                      c.push(
                        e.createListItem(n, h, a, u, "share-popup-item", () => {
                          (this.ka = g), (i.accept = m), i.click();
                        })
                      );
                  }),
                c
              );
            }
            tn(e) {
              const t = this.ni;
              this.Fa = this.pn();
              const s = t.createLabel(["hidden"]);
              (s.id = `${this.Fa.id}-label`),
                (s.htmlFor = this.Fa.id),
                (this.un = s),
                this.Ra(this.Da),
                e.append(s, this.Fa),
                this.As.enableAutocomplete &&
                  ((this.Ya = new r.Autocomplete(
                    this.Fa,
                    `${this.zt}-suggestions-list`,
                    this.ni
                  )),
                  e.append(this.Ya.getListbox()));
            }
            pn() {
              const e = ["user-input"];
              this.As.enableSpeech && e.push("user-input-inline-send");
              const t = this.ni.createElement("textarea", e, !0);
              return (
                t.setAttribute("enterkeyhint", "send"),
                (t.id = `${this.zt}-user-text-input`),
                (this.Da = this.Rs.inputPlaceholder),
                (t.rows = 1),
                (t.onkeydown = this.gn.bind(this)),
                (t.onkeyup = this.mn.bind(this)),
                (t.oninput = () => {
                  const e = t.value;
                  (this.xa.speechFinalResult = this.xa.speechFinalResult || {
                    speechId: "",
                    text: "",
                  }),
                    (this.xa.speechFinalResult.text = e),
                    this.Ea();
                }),
                (0, o.on)(t, "paste", () => {
                  this.Wa || p(this.Na.bind(this));
                }),
                this.bn(t),
                this.Ei("input", t),
                t
              );
            }
            Ra(e) {
              (this.Fa.placeholder = e), (this.un.innerText = e);
            }
            bn(e) {
              const t = Object.getOwnPropertyDescriptor(
                HTMLTextAreaElement.prototype,
                "value"
              );
              Object.defineProperty(e, "value", {
                set: (s) => {
                  t.set.call(e, s), this.Na(), this.Ea();
                },
                get: t.get,
              });
            }
            sn() {
              const e = g(this.ni, {
                css: ["button-send"],
                customIcon: this.Ca.send,
                defaultIcon: o.iconSend,
                title: this.Rs.send,
              });
              return (
                (e.disabled = !0),
                (e.onclick = () => {
                  var e;
                  this.fn() ||
                    ((this.wn = void 0),
                    (this.Fa.value =
                      null === (e = this.Fa) || void 0 === e
                        ? void 0
                        : e.value.trim()),
                    this.As.enableAutocomplete && (this.Va(), this.Ba()),
                    this.vn());
                }),
                e
              );
            }
            rn() {
              const e = g(this.ni, {
                css: ["button-switch-voice"],
                customIcon: this.Ca.mic,
                defaultIcon: o.iconMic,
                title: this.Rs.speak,
              });
              return (
                (e.onclick = () => {
                  this.$i(!0), (this.Ma = !0);
                }),
                this.Ei("mic", e),
                e
              );
            }
            Ta() {
              const e = this.ni,
                t = e.createDiv(["footer-mode-voice", "flex"]),
                s = e.createDiv(["footer-visualizer-wrapper"]);
              return (
                (this.Ha = e.createElement("canvas")),
                (this.Ha.width = 244),
                (this.Ha.height = 32),
                s.appendChild(this.Ha),
                t.appendChild(s),
                t
              );
            }
            an() {
              const e = g(this.ni, {
                css: ["button-switch-kbd"],
                customIcon: this.Ca.keyboard,
                defaultIcon: o.iconKeyboard,
                title: this.Rs.inputPlaceholder,
              });
              return (
                (e.onclick = () => {
                  (this.Ma = !1), this.$i(!1);
                }),
                this.Ei("keyboard", e),
                e
              );
            }
            Na() {
              var e, t;
              const s = this.Ka;
              if (!s || !s.nodeType) return;
              const i = this.ni,
                o = "none",
                r =
                  (null ===
                    (t =
                      null === (e = this.Fa) || void 0 === e
                        ? void 0
                        : e.value) || void 0 === t
                    ? void 0
                    : t.trim().length) > 0;
              this.mode === l && (this.As.alwaysShowSendButton || r)
                ? i.removeCSSClass(s, o)
                : i.addCSSClass(s, o),
                (s.disabled = this.Wa || !r);
            }
            fn() {
              return !this.Fa || 0 === this.Fa.value.trim().length;
            }
            gn(e) {
              var t;
              this.isDisabled() ||
                (this.As.enableAutocomplete &&
                  this.Ya.isOpen() &&
                  this.Ya.handleKeyboardEvent(e)) ||
                (e.key === i.KeyCode.Return &&
                  !e.shiftKey &&
                  (null === (t = this.Fa.value) || void 0 === t
                    ? void 0
                    : t.trim().length) > 0 &&
                  (e.preventDefault(), this.Ka.click()));
            }
            mn(e) {
              var t;
              if ((this.Na(), this.isDisabled()))
                return this.Va(), void this.Ba();
              if (e.isComposing) return;
              const s =
                null === (t = this.Fa.value) || void 0 === t
                  ? void 0
                  : t.trim();
              this.za(!0),
                this.As.enableSendTypingStatus &&
                  (s ? this.$a(s) : this.Li("LISTENING")),
                clearTimeout(this.xn),
                (this.xn = p(() => {
                  this.za(!1),
                    this.As.enableSendTypingStatus && this.Li("LISTENING");
                }, this.As.typingStatusInterval * o.SEC_MULTIPLIER)),
                this.As.enableAutocomplete &&
                  (e.code === i.KeyCode.Backspace &&
                    ((this.wn = void 0),
                    this.Va(),
                    this.Ba(),
                    clearTimeout(this.kn)),
                  this.yn().indexOf(e.code) < 0 &&
                    (s.length >= 3
                      ? this.wn !== s &&
                        ((this.wn = s), clearTimeout(this.kn), this.Qa())
                      : ((this.wn = void 0),
                        this.Ba(),
                        clearTimeout(this.kn))));
            }
            Ea() {
              if (!this.As.searchBarMode) {
                this.Fa.style.height = null;
                const e = 0.6 * this.xa.chatWidgetDiv.clientHeight,
                  t = this.Fa.scrollHeight;
                this.Fa.style.height = `${Math.min(e, t)}px`;
              }
            }
            vn() {
              this.ba(this.Fa.value),
                (this.Fa.value = ""),
                (this.Fa.innerText = ""),
                p(this.Ea.bind(this));
            }
            hn(e) {
              const t = this.ka;
              (this.ka = o.ATTACHMENT_MAX_SIZE),
                this.fa(e, { maxSize: t }),
                (this.cn.value = "");
            }
            _n() {
              this.wa(this.Fa.value.trim()).catch(() => {});
            }
            Ba() {
              this.Ya && this.Ya.isOpen() && this.Ya.hide();
            }
            Qa() {
              this.kn = p(() => {
                this._n();
              }, 300);
            }
            Va() {
              (this.Ga = null), (this.qa = !1);
            }
            yn() {
              if (!this.ya.length)
                for (const e of Object.keys(c)) this.ya.push(c[e]);
              return this.ya;
            }
          }
          function g(e, { css: t, customIcon: s, defaultIcon: i, title: o }) {
            const r = s || i;
            return e.createIconButton({
              css: ["footer-button", "flex"].concat(t),
              icon: r,
              iconCss: [],
              title: o,
            });
          }
          function m(e, t) {
            e.title = t;
          }
          t.ChatFooterComponent = u;
        },
        2512: function (e, t, s) {
          var i =
              (this && this.t) ||
              (Object.create
                ? function (e, t, s, i) {
                    void 0 === i && (i = s);
                    var o = Object.getOwnPropertyDescriptor(t, s);
                    (o &&
                      !("get" in o ? !t.p : o.writable || o.configurable)) ||
                      (o = {
                        enumerable: !0,
                        get: function () {
                          return t[s];
                        },
                      }),
                      Object.defineProperty(e, i, o);
                  }
                : function (e, t, s, i) {
                    void 0 === i && (i = s), (e[i] = t[s]);
                  }),
            o =
              (this && this.u) ||
              function (e, t) {
                for (var s in e)
                  "default" === s ||
                    Object.prototype.hasOwnProperty.call(t, s) ||
                    i(t, e, s);
              };
          Object.defineProperty(t, "p", { value: !0 }), o(s(9571), t);
        },
        5711: (e, t, s) => {
          Object.defineProperty(t, "p", { value: !0 }),
            (t.ChatHeaderComponent = void 0);
          const i = s(6246),
            o = s(8098),
            r = s(4557),
            a = s(9780),
            n = "end-conversation",
            c = "collapse",
            l = "clear",
            h = "tts",
            d = "none";
          class p extends r.Component {
            constructor(e, t, s, i, o, r, n, c, l) {
              super(),
                (this.As = e),
                (this.ni = t),
                (this.G = s),
                (this.On = i),
                (this.Mn = o),
                (this.Ys = r),
                (this.jn = n),
                (this.Ei = c),
                (this.xa = l),
                (this.ds = new a.Logger("ChatHeaderComponent")),
                (this.zn = []),
                (this.$n = []),
                (this.zt = e.name),
                (this.Rs = Object.assign(
                  Object.assign({}, this.As.i18n.en),
                  this.As.i18n[e.locale]
                ));
            }
            render() {
              return (
                (this.element = this.Ui()),
                this.As.showConnectionStatus &&
                  ((this.xi = (e) => this.In(e)),
                  this.Ys.on(i.CoreEvent.State, this.xi)),
                this.disable(),
                this.element
              );
            }
            addLanguageSelect(e) {
              const t = !(!this.$n || !this.$n.length);
              (this.Cn = e.render(t)),
                this.Ei("language", this.Cn),
                this.Cn &&
                  (t ? this.Sn.appendChild(this.Cn) : this.Tn.prepend(this.Cn));
            }
            closeWidgetPopup() {
              this.G();
            }
            clearHistory() {
              this.On();
            }
            showTTSButton(e) {
              const t = this.An(h);
              t && (t.style.display = e ? "flex" : d);
            }
            disableTTSButton(e) {
              const t = this.An(h);
              if (t) {
                const s = this.ni;
                if ("LI" === t.tagName) {
                  const i = "disable";
                  e
                    ? (s.addCSSClass(t, i), (t.ariaDisabled = "true"))
                    : (s.removeCSSClass(t, i), (t.ariaDisabled = "false"));
                } else t.disabled = e;
              }
            }
            setLocale(e) {
              var t;
              const s = this.ni,
                i = this.Cn;
              this.Rs = e;
              const o = e.chatTitle;
              o && (this.En.innerText = o);
              const r = e.chatSubtitle;
              r
                ? ((this.Pn.innerText = r),
                  s.removeCSSClass(this.Pn, d),
                  s.addCSSClass(this.Ln, d))
                : this.As.showConnectionStatus
                ? (this.In(this.Fn),
                  s.removeCSSClass(this.Ln, d),
                  s.addCSSClass(this.Pn, d))
                : (s.addCSSClass(this.Pn, d), s.addCSSClass(this.Ln, d)),
                this.Nn && u(this.Nn, e.showOptions),
                null === (t = this.zn) ||
                  void 0 === t ||
                  t.forEach((t) => {
                    u(t.element, e[t.title]);
                  }),
                i &&
                  u(i.querySelector("button") || i, e.languageSelectDropdown);
            }
            disable(e = !0) {
              if (
                this.As.enableEndConversation &&
                !this.As.wcfsEnableEndConversationButtonToClose
              )
                for (const t of this.zn)
                  t.name === n && (t.element.disabled = e);
            }
            addAction(e) {
              this.zn.push(e);
            }
            remove() {
              this.Ys.off(i.CoreEvent.State, this.xi);
            }
            Ui() {
              var e;
              const t = this.ni,
                s = this.As,
                i = s.icons,
                r = t.createDiv(["header", "flex"]),
                a = t.createDiv(["header-info-wrapper"]),
                p = t.createDiv(["header-actions", "flex"]),
                u = this.Rs,
                g = u.chatTitle,
                m = u.chatSubtitle;
              if (!("logo" in i) || i.logo) {
                const e = t.createImageIcon({
                  icon: i.logo || o.iconLogo,
                  iconCss: ["logo"],
                });
                r.appendChild(e);
              }
              if (g) {
                const e = t.createTextDiv(["title"]);
                (e.id = `${s.name}-title`),
                  (e.innerText = g),
                  a.appendChild(e),
                  (this.En = e);
              }
              (this.Pn = t.createTextDiv(["subtitle", d])),
                a.appendChild(this.Pn),
                (this.Ln = t.createTextDiv(["connection-status", d])),
                a.appendChild(this.Ln),
                m
                  ? ((this.Pn.innerText = m), t.removeCSSClass(this.Pn, d))
                  : s.showConnectionStatus &&
                    (this.In(this.Ys.getState()), t.removeCSSClass(this.Ln, d)),
                r.appendChild(a);
              const b = t.createDiv(["header-gap"]);
              if ((r.appendChild(b), s.customHeaderElementId)) {
                const e = document.getElementById(s.customHeaderElementId);
                if (e) {
                  const s = t.createDiv(["header-custom-element"]);
                  s.appendChild(e), r.appendChild(s);
                } else
                  this.ds.error(
                    `Could not find element with ID '${s.customHeaderElementId}'. No custom element added to the chat header.`
                  );
              }
              if (((this.Tn = p), s.enableEndConversation)) {
                const e = i.close || o.iconClose;
                this.zn.push({
                  name: n,
                  title: "endConversation",
                  icon: e,
                  clickHandler: this.jn.bind(this),
                  order: 10,
                });
              }
              if (!s.embedded) {
                const e = i.collapse || o.iconCollapse;
                this.zn.push({
                  name: c,
                  title: "close",
                  icon: e,
                  clickHandler: this.closeWidgetPopup.bind(this),
                  order: 20,
                });
              }
              if (
                (s.enableBotAudioResponse &&
                  ((this.Rn = !s.initBotAudioMuted),
                  this.zn.push({
                    name: h,
                    title: this.Rn ? "audioResponseOn" : "audioResponseOff",
                    icon: this.Rn
                      ? i.ttsOn || o.iconTTSUnmute
                      : i.ttsOff || o.iconTTSMute,
                    clickHandler: () => {
                      (this.Rn = !this.Rn), this.Dn(), this.Mn(this.Rn);
                    },
                    order: 30,
                  })),
                s.enableClearMessage)
              ) {
                const e = i.clearHistory || o.iconClearHistory;
                this.zn.push({
                  name: l,
                  title: "clear",
                  icon: e,
                  clickHandler: this.clearHistory.bind(this),
                  order: 40,
                });
              }
              return (
                this.zn.sort((e, t) => (e.order > t.order ? 1 : -1)),
                null === (e = this.zn) ||
                  void 0 === e ||
                  e.forEach((e, s) => {
                    const i = this.As.multiLangChat
                      ? this.zn.length + 1
                      : this.zn.length;
                    if (
                      !this.As.enableHeaderActionCollapse ||
                      (s < 2 && !(i > 2 && 1 === s))
                    ) {
                      const s = t.createIconButton({
                        css: ["header-button"],
                        icon: e.icon,
                        iconCss: [],
                        title: u[e.title],
                      });
                      (s.onclick = e.clickHandler),
                        this.Hn(e, s),
                        (e.element = s),
                        this.Tn.prepend(s);
                    } else this.$n.push(e);
                  }),
                this.$n && this.$n.length && this.Un(this.$n),
                r.appendChild(p),
                r
              );
            }
            Hn(e, t) {
              switch (((t.id = `${this.zt}-${e.name}`), e.name)) {
                case n:
                  this.Ei("close", t);
                  break;
                case c:
                case h:
                  this.Ei(e.name, t);
                  break;
                case l:
                  this.Ei("clearHistory", t);
              }
            }
            Un(e) {
              const t = this.ni,
                s = this.Rs,
                i = `${this.As.name}-action-menu`,
                r = `${i}-button`,
                a = e.map((e) => {
                  const i = t.createListItem(
                    `action-menu-option-${e.name}`,
                    s[e.title],
                    e.name,
                    e.icon,
                    "action-item",
                    e.clickHandler
                  );
                  return this.Hn(e, i), (e.element = i), i;
                }),
                n = t.createIconButton({
                  css: ["header-button", "button-show-options"],
                  icon: o.iconExpand,
                  iconCss: [],
                  title: s.showOptions,
                }),
                c = t.getMenu({
                  menuId: i,
                  menuClassList: ["action-menu"],
                  menuItems: a,
                  buttonId: r,
                  menuButton: n,
                }),
                l = t.getMenuButton({
                  button: n,
                  menuId: i,
                  menu: c,
                  widget: this.xa.chatWidgetDiv,
                });
              this.Tn.prepend(l),
                this.Tn.appendChild(c),
                (this.Nn = l),
                (this.Sn = c);
            }
            Vn(e) {
              for (const t of this.zn) if (t.name === e) return t;
              return null;
            }
            An(e) {
              var t;
              return null === (t = this.Vn(e)) || void 0 === t
                ? void 0
                : t.element;
            }
            Dn() {
              const e = this.As.icons,
                t = this.Vn(h);
              (t.title = this.Rn ? "audioResponseOn" : "audioResponseOff"),
                (t.icon = this.Rn
                  ? e.ttsOn || o.iconTTSUnmute
                  : e.ttsOff || o.iconTTSMute),
                this.Zo(h);
            }
            Zo(e) {
              const t = this.ni,
                s = this.Rs,
                i = this.Vn(e),
                o = this.An(e);
              if (o) {
                o.innerHTML = "";
                const e = s[i.title],
                  r = i.icon,
                  a = "LI" === o.tagName,
                  n = t.createImageIcon({
                    icon: r,
                    iconCss: [a ? "icon" : "", "action-item-icon"],
                  });
                if (a) {
                  o.appendChild(n);
                  const s = t.createTextSpan([
                    "text",
                    "action-item-text",
                    "ellipsis",
                  ]);
                  (s.innerText = e), o.appendChild(s);
                } else o.appendChild(n), (o.title = e);
              }
            }
            In(e) {
              const t = this.ni,
                s = "connecting",
                o = "connected",
                r = "disconnected",
                a = this.Ln,
                n = this.Rs;
              switch (((this.Fn = e), e)) {
                case i.ConnectionState.Open:
                  (a.innerText = n.connected),
                    t.removeCSSClass(a, s, r),
                    t.addCSSClass(a, o);
                  break;
                case i.ConnectionState.Closed:
                  (a.innerText = n.disconnected),
                    t.removeCSSClass(a, s, o),
                    t.addCSSClass(a, r);
                  break;
                case i.ConnectionState.Closing:
                  (a.innerText = n.closing),
                    t.removeCSSClass(a, o, r),
                    t.addCSSClass(a, s);
                  break;
                case i.ConnectionState.Connecting:
                  (a.innerText = n.connecting),
                    t.removeCSSClass(a, o, r),
                    t.addCSSClass(a, s);
              }
            }
          }
          function u(e, t) {
            if ("LI" === e.tagName) {
              const s = e.querySelector("span");
              s && (s.innerText = t);
            } else e.title = t;
          }
          t.ChatHeaderComponent = p;
        },
        7102: function (e, t, s) {
          var i =
              (this && this.t) ||
              (Object.create
                ? function (e, t, s, i) {
                    void 0 === i && (i = s);
                    var o = Object.getOwnPropertyDescriptor(t, s);
                    (o &&
                      !("get" in o ? !t.p : o.writable || o.configurable)) ||
                      (o = {
                        enumerable: !0,
                        get: function () {
                          return t[s];
                        },
                      }),
                      Object.defineProperty(e, i, o);
                  }
                : function (e, t, s, i) {
                    void 0 === i && (i = s), (e[i] = t[s]);
                  }),
            o =
              (this && this.u) ||
              function (e, t) {
                for (var s in e)
                  "default" === s ||
                    Object.prototype.hasOwnProperty.call(t, s) ||
                    i(t, e, s);
              };
          Object.defineProperty(t, "p", { value: !0 }), o(s(5711), t);
        },
        5919: (e, t, s) => {
          Object.defineProperty(t, "p", { value: !0 }),
            (t.WidgetMainComponent = void 0);
          const i = s(4557);
          class o extends i.Component {
            constructor(e) {
              super(), (this.element = e.createDiv(["conversation"]));
            }
            render() {}
          }
          t.WidgetMainComponent = o;
        },
        5846: function (e, t, s) {
          var i =
              (this && this.t) ||
              (Object.create
                ? function (e, t, s, i) {
                    void 0 === i && (i = s);
                    var o = Object.getOwnPropertyDescriptor(t, s);
                    (o &&
                      !("get" in o ? !t.p : o.writable || o.configurable)) ||
                      (o = {
                        enumerable: !0,
                        get: function () {
                          return t[s];
                        },
                      }),
                      Object.defineProperty(e, i, o);
                  }
                : function (e, t, s, i) {
                    void 0 === i && (i = s), (e[i] = t[s]);
                  }),
            o =
              (this && this.u) ||
              function (e, t) {
                for (var s in e)
                  "default" === s ||
                    Object.prototype.hasOwnProperty.call(t, s) ||
                    i(t, e, s);
              };
          Object.defineProperty(t, "p", { value: !0 }), o(s(5919), t);
        },
        2366: function (e, t, s) {
          var i =
              (this && this.t) ||
              (Object.create
                ? function (e, t, s, i) {
                    void 0 === i && (i = s);
                    var o = Object.getOwnPropertyDescriptor(t, s);
                    (o &&
                      !("get" in o ? !t.p : o.writable || o.configurable)) ||
                      (o = {
                        enumerable: !0,
                        get: function () {
                          return t[s];
                        },
                      }),
                      Object.defineProperty(e, i, o);
                  }
                : function (e, t, s, i) {
                    void 0 === i && (i = s), (e[i] = t[s]);
                  }),
            o =
              (this && this.u) ||
              function (e, t) {
                for (var s in e)
                  "default" === s ||
                    Object.prototype.hasOwnProperty.call(t, s) ||
                    i(t, e, s);
              };
          Object.defineProperty(t, "p", { value: !0 }),
            o(s(1816), t),
            o(s(2512), t),
            o(s(7102), t),
            o(s(5846), t),
            o(s(5598), t);
        },
        5598: (e, t, s) => {
          Object.defineProperty(t, "p", { value: !0 }),
            (t.MultiLangChatComponent = void 0);
          const i = s(6246),
            o = s(9780),
            r = s(8098);
          function a(e) {
            return `${e.name}-${e.channelId}-${e.userId}`;
          }
          function n(e, t) {
            (0, r.getBrowserLocale)() === e && (t[e.substring(0, 2)] = e);
          }
          t.MultiLangChatComponent = class {
            constructor(e, t, s) {
              let r, a;
              if (
                ((this.U = t),
                (this.xa = s),
                (this.ds = new o.Logger("MultiLangChatComponent")),
                (this.Bn = !0),
                (this.Wn = !0),
                (this.Zn = !1),
                (this.Gn = {}),
                (this.qn = {}),
                (this.Yn = []),
                (this.Ys = t.webCore),
                (this.As = t.settings),
                (this.Rs = Object.assign(
                  Object.assign({}, this.As.i18n.en),
                  this.As.i18n[this.As.locale]
                )),
                (this.zt = t.settings.name),
                e &&
                  ((this.Jn = Object.assign(Object.assign({}, e), {
                    supportedLangs: e.supportedLangs
                      ? [...e.supportedLangs]
                      : [],
                  })),
                  (r = this.Jn.supportedLangs),
                  (a = this.Jn.primary),
                  "string" == typeof a && (this.Jn.primary = a.toLowerCase())),
                r && r.length)
              )
                if (
                  (r.forEach((e) => {
                    e.lang = e.lang.toLowerCase();
                  }),
                  r.length > 1
                    ? (r.unshift({
                        lang: "und",
                        label: this.Rs.language_detect,
                      }),
                      this.Jn.primary || (this.Jn.primary = null))
                    : (this.Jn.primary = r[0].lang),
                  (this.Yn = r.map((e) => e.lang)),
                  this.As.enableBotAudioResponse)
                ) {
                  const e = t.synthesisVoices;
                  if (e && e.length) {
                    const t = {};
                    r
                      .filter((e) => e.lang && "und" !== e.lang)
                      .forEach((s) => {
                        const i = e.filter((e) => e.lang.indexOf(s.lang) >= 0);
                        i.push({ lang: s.lang }), (t[s.lang] = i);
                      }),
                      (this.qn = t);
                  } else
                    new Set(this.Yn.filter((e) => "und" !== e)).forEach((e) => {
                      this.qn[e] = [{ lang: e, name: e }];
                    });
                } else this.Kn = () => {};
              if (this.As.enableSpeech) {
                const e = {};
                Object.values(i.RecognitionLocale).forEach((t) => {
                  (e[t.substring(0, 2)] = t), (e[t] = t);
                }),
                  n(i.RecognitionLocale.EN_GB, e),
                  n(i.RecognitionLocale.EN_AU, e),
                  n(i.RecognitionLocale.EN_IN, e),
                  (this.Gn = e);
              } else this.Xn = () => {};
            }
            render(e) {
              const t = this.U.util,
                s = this.zt,
                i = "language-selection",
                o = `${s}-${i}-button`,
                a = `${s}-${i}-menu`,
                n = this.Jn;
              let c;
              if (
                ((this.Zn = e),
                !(n && n.supportedLangs && n.supportedLangs.length >= 2))
              )
                return null;
              if (!this.Qn) {
                const s = this.As.icons.language || r.iconLanguage,
                  l = t.createIconButton({
                    css: ["header-button", "button-lang"],
                    icon: s,
                    iconCss: [],
                    title: this.Rs.languageSelectDropdown,
                  }),
                  h = t.createListItem(
                    "action-menu-option-lang",
                    this.Rs.languageSelectDropdown,
                    "lang",
                    s,
                    "action-item",
                    null,
                    !0
                  ),
                  d = n.supportedLangs.map((e) => {
                    var s;
                    const { lang: o, label: r } = e,
                      a = "und" === o && n.primary ? n.primary : o,
                      c = `language_${"und" === o ? "detect" : o}`,
                      l =
                        (null === (s = this.As.i18n[a]) || void 0 === s
                          ? void 0
                          : s[c]) ||
                        r ||
                        o;
                    return t.createListItem(
                      `${i}-option-${o}`,
                      l,
                      o,
                      "",
                      `${i}-option`,
                      (e) => {
                        let t = e.target;
                        "LI" !== t.tagName && (t = t.parentElement);
                        const s = t.dataset.value;
                        this.ec(s);
                      }
                    );
                  }),
                  p = t.getMenu({
                    menuId: a,
                    menuClassList: [`${i}-menu`],
                    menuItems: d,
                    buttonId: o,
                    menuButton: e ? h : l,
                  });
                if (e) {
                  c = t.getMenuButton({
                    button: h,
                    menuId: a,
                    menu: p,
                    widget: this.xa.chatWidgetDiv,
                  });
                  const e = t.createDiv(["arrow-icon"]),
                    s = t.createImageIcon({ icon: r.iconExpandArrow });
                  e.appendChild(s),
                    c.appendChild(e),
                    this.U.chatWidget.chatWidgetDiv.appendChild(p);
                } else {
                  c = t.createDiv();
                  const e = t.getMenuButton({
                    button: l,
                    menuId: a,
                    menu: p,
                    widget: this.xa.chatWidgetDiv,
                  });
                  c.appendChild(e), c.appendChild(p), (l.id = o);
                }
                this.disableComponent(!1);
              }
              return (this.Qn = c), c;
            }
            setLocale(e) {
              this.Qn &&
                ((this.Rs = e),
                this.Jn.supportedLangs.forEach((t) => {
                  const { lang: s, label: i } = t,
                    o = `language_${"und" === s ? "detect" : s}`,
                    r = document.getElementById(
                      `language-selection-option-${s}`
                    );
                  if (!r) return;
                  const a = e[o] || i || s;
                  r.title = a;
                }));
            }
            setTag(e, t = !0) {
              let s = "";
              null !== e && (s = e.toLowerCase()),
                this.Yn.length && (s = this.Yn.indexOf(s) >= 0 ? s : null),
                this.ec(s, t);
            }
            disableComponent(e) {
              if (this.Qn) {
                const t = this.U.util,
                  s = this.Qn;
                if (this.Zn) {
                  const i = "disable";
                  e ? t.addCSSClass(s, i) : t.removeCSSClass(s, i);
                } else s.querySelector("button").disabled = e;
              }
            }
            ec(e, t = !0) {
              let s = e;
              (this.Rs = this.As.i18n[s]),
                this.tc !== s &&
                  ((this.tc = s),
                  this.U.eventDispatcher.trigger(r.ChatEvent.CHAT_LANG, s)),
                this.Qn && this.sc(s),
                "und" === s && (s = null),
                t && (this.oc(s), this.U.storageService.setItem(a(this.As), s)),
                this.Kn(s),
                this.Xn(s),
                this.U.chatWidget.onLanguageUpdate(s, t);
            }
            oc(e) {
              if (this.Ys.isConnected()) {
                const t = { profile: { languageTag: e } };
                e || (t.profile.locale = e);
                const s = this.As.sdkMetadata
                  ? Object.assign(
                      { version: r.SDK_VERSION },
                      this.As.sdkMetadata
                    )
                  : { version: r.SDK_VERSION };
                this.Ys.updateUser(t, { sdkMetadata: s }).catch((e) =>
                  this.ds.warn(
                    "[updateProfile] Failed to update user profile:",
                    e
                  )
                );
              }
            }
            Kn(e) {
              const t = this.U.chatWidget;
              if (e) {
                if (
                  (this.Bn ||
                    (t.enableSpeechSynthesisService(!0), (this.Bn = !0)),
                  this.As.enableBotAudioResponse)
                ) {
                  const t = this.qn[e];
                  this.Ys.setTTSVoice(t).catch((e) => {
                    this.ds.info(
                      `Failed to set TTS voice for '${t[0].lang}'. ${e}`
                    ),
                      this.Kn(null);
                  });
                }
              } else
                (this.Bn = !1),
                  this.As.enableBotAudioResponse && this.Ys.cancelTTS(),
                  t.enableSpeechSynthesisService(!1);
            }
            Xn(e) {
              const t = this.U,
                s = this.Gn[e],
                i = t.chatWidget;
              s
                ? (this.Wn ||
                    (i.setVoiceRecognitionService(!0), (this.Wn = !0)),
                  this.Ys.setRecognitionLocale(s))
                : ((this.Wn = !1),
                  this.Ys.stopRecognition(),
                  this.Ys.setRecognitionLocale(null),
                  i.setVoiceRecognitionService(!1));
            }
            sc(e) {
              const t = this.U.util,
                s = e || "und",
                i = document.getElementById(
                  `${this.zt}-language-selection-menu`
                ),
                o = "active";
              if (i) {
                const e = i.querySelector(`li.${this.zt}-${o}`);
                e && t.removeCSSClass(e, o);
                const r = i.querySelector(`[data-value="${s}"]`);
                r && t.addCSSClass(r, o);
              }
            }
            initLanguage() {
              const { primary: e } = this.Jn || {},
                t = this.U.storageService.getItem(a(this.As));
              let s = e;
              t && (s = "null" === t ? null : t),
                void 0 !== s && this.setTag(s);
            }
          };
        },
        4557: (e, t, s) => {
          Object.defineProperty(t, "p", { value: !0 }), (t.Component = void 0);
          const i = s(6064);
          t.Component = class {
            remove() {
              this.element.remove();
            }
            isVisible() {
              return (0, i.isVisible)(this.element);
            }
            appendToElement(e) {
              e.appendChild(this.element);
            }
            prependToElement(e) {
              const t = e.firstChild;
              t ? e.insertBefore(this.element, t) : e.appendChild(this.element);
            }
            appendContentChildElement(e) {
              this.rc().appendChild(e);
            }
            appendContentChild(e) {
              this.rc().appendChild(e.element);
            }
            rc() {
              return this.element;
            }
          };
        },
        4049: (e, t, s) => {
          Object.defineProperty(t, "p", { value: !0 }),
            (t.ActionComponentFactory = void 0);
          const i = s(6246),
            o = s(5915),
            r = s(6893);
          class a {
            static fromActionPayload(e, t, s, r, n) {
              switch (e.type) {
                case i.ActionType.Postback:
                  return new o.PostbackActionComponent(t, e);
                case i.ActionType.Url:
                  return new o.UrlActionComponent(
                    t,
                    e,
                    s.openLinksInNewWindow,
                    s.linkHandler
                  );
                case i.ActionType.Webview:
                  return new o.UrlActionComponent(
                    t,
                    e,
                    s.openLinksInNewWindow,
                    n.webviewLinkHandler
                  );
                case i.ActionType.Location:
                  return new o.LocationActionComponent(t, e);
                case i.ActionType.Call:
                  return new o.CallActionComponent(t, e);
                case i.ActionType.Share:
                  return new o.ShareActionComponent(t, e, r);
                case i.ActionType.SubmitForm:
                  return new o.SubmitFormActionComponent(t, e);
                case i.ActionType.Popup:
                  return new o.PopupActionComponent(t, e, s, n);
                case i.ActionType.Client:
                  return new o.ClientActionComponent(t, e, r);
                default:
                  return (
                    a.logger.error(
                      `Payload contains wrong action type:${e.type}`
                    ),
                    null
                  );
              }
            }
          }
          (t.ActionComponentFactory = a),
            (a.logger = new r.Logger("ActionComponentFactory"));
        },
        5053: function (e, t, s) {
          var i =
              (this && this.t) ||
              (Object.create
                ? function (e, t, s, i) {
                    void 0 === i && (i = s);
                    var o = Object.getOwnPropertyDescriptor(t, s);
                    (o &&
                      !("get" in o ? !t.p : o.writable || o.configurable)) ||
                      (o = {
                        enumerable: !0,
                        get: function () {
                          return t[s];
                        },
                      }),
                      Object.defineProperty(e, i, o);
                  }
                : function (e, t, s, i) {
                    void 0 === i && (i = s), (e[i] = t[s]);
                  }),
            o =
              (this && this.u) ||
              function (e, t) {
                for (var s in e)
                  "default" === s ||
                    Object.prototype.hasOwnProperty.call(t, s) ||
                    i(t, e, s);
              };
          Object.defineProperty(t, "p", { value: !0 }),
            o(s(4049), t),
            o(s(5340), t);
        },
        5340: (e, t, s) => {
          Object.defineProperty(t, "p", { value: !0 }),
            (t.MessageComponentFactory = void 0);
          const i = s(6246),
            o = s(5915),
            r = s(7584);
          t.MessageComponentFactory = class {
            static fromMessage(e, t, s, a) {
              let n, c;
              (0, r.isBotMessage)(s)
                ? ((n = o.MESSAGE_SIDE.LEFT),
                  (c = s.source || i.SkillMessageSource.Bot))
                : (n = o.MESSAGE_SIDE.RIGHT);
              const l = s.messagePayload;
              switch (l.type) {
                case i.MessageType.Postback:
                case i.MessageType.Text:
                  return l.channelExtensions &&
                    "stars" === l.channelExtensions.displayType
                    ? new o.FeedbackComponent(e, t, l, n, c, a)
                    : new o.TextMessageComponent(e, t, l, n, c, a);
                case i.MessageType.TextStream:
                  return new o.TextStreamMessageComponent(e, t, l, n, c, a);
                case i.MessageType.Attachment:
                  return new o.AttachmentMessageComponent(e, t, l, n, c, a);
                case i.MessageType.Card:
                  return new o.CardMessageComponent(e, t, l, n, c, a);
                case i.MessageType.Location:
                  return new o.LocationMessageComponent(e, t, l, n, c, a);
                case i.MessageType.Table:
                  return new o.TableMessageComponent(e, t, l, n, c, a);
                case i.MessageType.Form:
                  return new o.FormMessageComponent(e, t, l, n, c, a);
                case i.MessageType.TableForm:
                  return new o.TableFormMessageComponent(e, t, l, n, c, a);
                case i.MessageType.EditForm:
                  return new o.EditFormMessageComponent(e, t, l, n, c, a);
                case i.MessageType.Raw:
                  return new o.RawMessageComponent(e, t, l, n, c, a);
                default:
                  throw Error(`Wrong message payload type:${l.type}`);
              }
            }
          };
        },
        9501: (e, t, s) => {
          Object.defineProperty(t, "p", { value: !0 }),
            (t.HotkeysManager = void 0);
          const i = s(6064),
            o = "keydown";
          t.HotkeysManager = class {
            constructor(e) {
              var t;
              (this.ac = new Map()),
                (this.nc = !0),
                (this.cc = (e) => {
                  if (r(e) && this.lc(e.code)) {
                    const e = document.querySelector(this.hc);
                    if (e) {
                      const t = e.value.length;
                      setTimeout(() => {
                        e.value.length > t && (e.value = e.value.slice(0, t));
                      });
                    }
                  }
                });
              const s = null !== (t = e.name) && void 0 !== t ? t : "oda-chat";
              this.hc = `.${s}-user-input`;
            }
            add(e, t, s = !0) {
              this.nc && (this.dc(), (this.nc = !1));
              const i = e.toUpperCase(),
                o = isNaN(i) ? `Key${i}` : `Digit${i}`;
              this.ac.set(o, { check: s, elem: t }),
                t.setAttribute("aria-keyshortcuts", `Alt+${i}`);
            }
            setWidget(e) {
              this.xa = e;
            }
            remove() {
              document.removeEventListener(o, this.cc);
            }
            dc() {
              document.addEventListener(o, this.cc);
            }
            lc(e) {
              let t = !1;
              const s = this.ac.get(e),
                o = s && s.elem;
              return (
                o &&
                  (0, i.isVisible)(s.check ? this.xa : o) &&
                  !o.disabled &&
                  (o.focus(), o.click(), (t = !0)),
                t
              );
            }
          };
          const r = (e) =>
            e.altKey && !e.ctrlKey && !e.metaKey && !e.shiftKey && !e.repeat;
        },
        9780: function (e, t, s) {
          var i =
              (this && this.t) ||
              (Object.create
                ? function (e, t, s, i) {
                    void 0 === i && (i = s);
                    var o = Object.getOwnPropertyDescriptor(t, s);
                    (o &&
                      !("get" in o ? !t.p : o.writable || o.configurable)) ||
                      (o = {
                        enumerable: !0,
                        get: function () {
                          return t[s];
                        },
                      }),
                      Object.defineProperty(e, i, o);
                  }
                : function (e, t, s, i) {
                    void 0 === i && (i = s), (e[i] = t[s]);
                  }),
            o =
              (this && this.u) ||
              function (e, t) {
                for (var s in e)
                  "default" === s ||
                    Object.prototype.hasOwnProperty.call(t, s) ||
                    i(t, e, s);
              };
          Object.defineProperty(t, "p", { value: !0 }),
            o(s(5053), t),
            o(s(9501), t),
            o(s(6893), t),
            o(s(3751), t),
            o(s(7584), t),
            o(s(8052), t),
            o(s(499), t);
        },
        6893: (e, t) => {
          Object.defineProperty(t, "p", { value: !0 }), (t.Logger = void 0);
          class s {
            constructor(e) {
              this.uc = e;
            }
            debug(...e) {
              this.gc(s.LOG_LEVEL.DEBUG, e);
            }
            error(...e) {
              this.gc(s.LOG_LEVEL.ERROR, e);
            }
            info(...e) {
              this.gc(s.LOG_LEVEL.INFO, e);
            }
            warn(...e) {
              this.gc(s.LOG_LEVEL.WARN, e);
            }
            gc(e, t) {
              if (s.logLevel >= e) {
                let i;
                switch (
                  (t.unshift(`[${s.appName}.${s.appVersion}.${this.uc}]`), e)
                ) {
                  case s.LOG_LEVEL.ERROR:
                    i = console.error;
                    break;
                  case s.LOG_LEVEL.WARN:
                    i = console.warn;
                    break;
                  case s.LOG_LEVEL.INFO:
                    i = console.info;
                    break;
                  case s.LOG_LEVEL.DEBUG:
                    i = console.debug;
                }
                i.apply(console, t);
              }
            }
          }
          (t.Logger = s),
            (s.LOG_LEVEL = { NONE: 0, ERROR: 1, WARN: 2, INFO: 3, DEBUG: 4 }),
            (s.logLevel = s.LOG_LEVEL.NONE);
        },
        3751: (e, t) => {
          Object.defineProperty(t, "p", { value: !0 });
        },
        7584: (e, t) => {
          Object.defineProperty(t, "p", { value: !0 }),
            (t.isBotMessage = function (e) {
              return !!e.source;
            }),
            (t.getMessageDigest = function (e) {
              if (e.msgId) return e.msgId;
              const t = JSON.stringify(e.messagePayload);
              return `${s(t)}`;
            });
          const s = (e) => {
            let t = 0,
              s = 0;
            const i = Math.pow(9, 9);
            for (; t < e.length; ) s = Math.imul(s ^ e.charCodeAt(t++), i);
            return s ^ (s >>> 9);
          };
        },
        8052: (e, t) => {
          Object.defineProperty(t, "p", { value: !0 }),
            (t.WidgetTheme = t.StorageType = t.ShareCategory = void 0);
          t.StorageType = {
            SESSION: "sessionStorage",
            LOCAL: "localStorage",
            CUSTOM: "custom",
          };
          t.WidgetTheme = {
            CLASSIC: "classic",
            DEFAULT: "default",
            REDWOOD_DARK: "redwood-dark",
          };
          t.ShareCategory = {
            AUDIO: "audio",
            FILE: "file",
            LOCATION: "location",
            VISUAL: "visual",
          };
        },
        499: (e, t, s) => {
          Object.defineProperty(t, "p", { value: !0 }),
            (t.StorageService = void 0);
          const i = s(8098);
          t.StorageService = class {
            constructor(e) {
              (this.getItem = (e) => (
                !this.mc[e] && this.bc && (this.mc[e] = this.fc.getItem(e)),
                this.mc[e]
              )),
                (this.setItem = (e, t) => {
                  this.bc
                    ? (this.fc.setItem(e, t), delete this.mc[e])
                    : (this.mc[e] = t);
                }),
                (this.removeItem = (e) => {
                  this.bc && this.fc.removeItem(e), delete this.mc[e];
                }),
                (this.mc = {}),
                (0, i.isStorageAvailable)(e)
                  ? ((this.bc = !0), (this.fc = window[e]))
                  : (this.bc = !1);
            }
          };
        },
        5430: function (e, t, s) {
          var i =
              (this && this.t) ||
              (Object.create
                ? function (e, t, s, i) {
                    void 0 === i && (i = s);
                    var o = Object.getOwnPropertyDescriptor(t, s);
                    (o &&
                      !("get" in o ? !t.p : o.writable || o.configurable)) ||
                      (o = {
                        enumerable: !0,
                        get: function () {
                          return t[s];
                        },
                      }),
                      Object.defineProperty(e, i, o);
                  }
                : function (e, t, s, i) {
                    void 0 === i && (i = s), (e[i] = t[s]);
                  }),
            o =
              (this && this.u) ||
              function (e, t) {
                for (var s in e)
                  "default" === s ||
                    Object.prototype.hasOwnProperty.call(t, s) ||
                    i(t, e, s);
              };
          Object.defineProperty(t, "p", { value: !0 }),
            o(s(4413), t),
            o(s(2366), t),
            o(s(6992), t),
            o(s(4557), t),
            o(s(9780), t),
            o(s(5915), t),
            o(s(2854), t);
        },
        9836: (e, t, s) => {
          Object.defineProperty(t, "p", { value: !0 }),
            (t.ActionComponent = void 0);
          const i = s(6246),
            o = s(8098);
          t.ActionComponent = class {
            constructor(e, t) {
              var s, o;
              (this.util = e),
                (this.wc = !1),
                (this.vc = t.type),
                (this.xc = t.label),
                (this.kc = t.imageUrl),
                (this.yc = t.style),
                (this._c = t.tooltip),
                (this.Oc = t.displayType),
                (this.Mc =
                  null === (s = t.channelExtensions) || void 0 === s
                    ? void 0
                    : s.activeImageUrl),
                (this.jc =
                  null === (o = t.channelExtensions) || void 0 === o
                    ? void 0
                    : o.c2kText),
                this.vc !== i.ActionType.SubmitForm ||
                  this.yc ||
                  (this.yc = i.ActionStyle.Primary);
            }
            render() {
              const e = this.util,
                t = e.createButton([
                  "action-postback",
                  this.yc === i.ActionStyle.Primary
                    ? "primary"
                    : this.yc === i.ActionStyle.Danger
                    ? "danger"
                    : "",
                ]);
              if (
                (this.Oc === i.ActionDisplayType.Icon &&
                  e.addCSSClass(t, i.ActionDisplayType.Icon),
                (t.onclick = this.handleOnClick.bind(this)),
                this.kc &&
                  t.appendChild(
                    e.createImageIcon({
                      icon: this.kc,
                      iconCss: ["action-image"],
                    })
                  ),
                this.xc)
              ) {
                const s = (0, o.linkify)(this.xc, e.cssPrefix),
                  r = e.createTextDiv();
                if (this.Oc === i.ActionDisplayType.Link) {
                  const i = e.createAnchor("", s);
                  (i.onclick = (e) => e.preventDefault()),
                    r.appendChild(i),
                    e.addCSSClass(t, "display-link");
                } else
                  this.jc
                    ? ((r.innerHTML = String.fromCharCode(
                        parseInt(this.xc) + 10111
                      )),
                      e.addCSSClass(t, "c2k-action"),
                      t.addEventListener("mouseover", () => {
                        r.innerHTML = String.fromCharCode(
                          parseInt(this.xc) + 10121
                        );
                        for (const t of Array.from(
                          document.getElementsByClassName(this.jc)
                        ))
                          e.addCSSClass(t, "highlight");
                      }),
                      t.addEventListener("mouseleave", () => {
                        r.innerHTML = String.fromCharCode(
                          parseInt(this.xc) + 10111
                        );
                        for (const t of Array.from(
                          document.getElementsByClassName(this.jc)
                        ))
                          e.removeCSSClass(t, "highlight");
                      }))
                    : (r.innerHTML = s);
                t.appendChild(r);
              }
              if ((this.wc && e.addCSSClass(t, "disabled"), this._c)) {
                const s = e.createDiv(["action-wrapper"]),
                  i = e.createDiv(),
                  o = e.createTextDiv(["tooltip", "none"]);
                return (
                  (o.innerText = this._c),
                  o.setAttribute("role", "tooltip"),
                  i.appendChild(o),
                  s.appendChild(t),
                  s.appendChild(i),
                  s
                );
              }
              return (this.zc = t), t;
            }
            handleOnClick(e) {
              if (this.onActionClick && !this.wc) {
                const e = {
                  getPayload: this.getEventPayload.bind(this),
                  label: this.xc,
                  imageUrl: this.Mc || this.kc,
                  type: this.vc,
                };
                this.Mc &&
                  this.zc.lastElementChild.replaceWith(
                    this.util.createImage(
                      this.Mc,
                      ["action-image"],
                      this.xc || ""
                    )
                  ),
                  this.onActionClick(e);
              }
              (this.vc !== i.ActionType.Postback &&
                this.vc !== i.ActionType.Location &&
                this.vc !== i.ActionType.Share) ||
                (e.preventDefault(), e.stopPropagation());
            }
            disable() {
              (this.wc = !0),
                this.zc &&
                  (this.util.addCSSClass(this.zc, "disabled"),
                  (this.zc.disabled = !0));
            }
            enable() {
              (this.wc = !1),
                this.zc &&
                  (this.util.removeCSSClass(this.zc, "disabled"),
                  (this.zc.disabled = !1));
            }
            getActionType() {
              return this.vc;
            }
          };
        },
        8183: (e, t, s) => {
          Object.defineProperty(t, "p", { value: !0 }),
            (t.CallActionComponent = void 0);
          const i = s(9836);
          class o extends i.ActionComponent {
            constructor(e, t) {
              super(e, t), (this.$c = t.phoneNumber);
            }
            render() {
              const e = this.util,
                t = super.render();
              "button" === t.tagName.toLowerCase()
                ? e.addCSSClass(t, "action-call")
                : e.addCSSClass(t.firstElementChild, "action-call");
              const s = e.createAnchor(`tel:${this.$c}`, "");
              return (
                (this.onActionClick = () => {
                  s.click();
                }),
                t
              );
            }
            getEventPayload() {
              return Promise.resolve(this.$c);
            }
          }
          t.CallActionComponent = o;
        },
        4674: (e, t, s) => {
          Object.defineProperty(t, "p", { value: !0 }),
            (t.ClientActionComponent = void 0);
          const i = s(6246),
            o = s(9836);
          class r extends o.ActionComponent {
            constructor(e, t, s) {
              super(e, t), (this.Ar = t), (this.Ic = s);
            }
            render() {
              const e = this.util,
                t = super.render();
              return (
                "button" === t.tagName.toLowerCase()
                  ? e.addCSSClass(t, "action-client")
                  : e.addCSSClass(t.firstElementChild, "action-client"),
                t
              );
            }
            getEventPayload() {
              return this.Ar.actionType === i.ClientActionType.COPY_MESSAGE_TEXT
                ? Promise.resolve(this.Ic)
                : Promise.resolve(this.Ar);
            }
          }
          t.ClientActionComponent = r;
        },
        7007: function (e, t, s) {
          var i =
              (this && this.t) ||
              (Object.create
                ? function (e, t, s, i) {
                    void 0 === i && (i = s);
                    var o = Object.getOwnPropertyDescriptor(t, s);
                    (o &&
                      !("get" in o ? !t.p : o.writable || o.configurable)) ||
                      (o = {
                        enumerable: !0,
                        get: function () {
                          return t[s];
                        },
                      }),
                      Object.defineProperty(e, i, o);
                  }
                : function (e, t, s, i) {
                    void 0 === i && (i = s), (e[i] = t[s]);
                  }),
            o =
              (this && this.u) ||
              function (e, t) {
                for (var s in e)
                  "default" === s ||
                    Object.prototype.hasOwnProperty.call(t, s) ||
                    i(t, e, s);
              };
          Object.defineProperty(t, "p", { value: !0 }),
            o(s(9836), t),
            o(s(8183), t),
            o(s(4674), t),
            o(s(170), t),
            o(s(301), t),
            o(s(9e3), t),
            o(s(6670), t),
            o(s(2183), t),
            o(s(9328), t);
        },
        170: (e, t, s) => {
          Object.defineProperty(t, "p", { value: !0 }),
            (t.LocationActionComponent = void 0);
          const i = s(6246),
            o = s(9836);
          class r extends o.ActionComponent {
            render() {
              const e = this.util,
                t = super.render();
              return (
                "button" === t.tagName.toLowerCase()
                  ? e.addCSSClass(t, "action-location")
                  : e.addCSSClass(t.firstElementChild, "action-location"),
                t
              );
            }
            getEventPayload() {
              return (0, i.getCurrentPosition)();
            }
          }
          t.LocationActionComponent = r;
        },
        301: (e, t, s) => {
          Object.defineProperty(t, "p", { value: !0 }),
            (t.PopupActionComponent = void 0);
          const i = s(8098),
            o = s(9836);
          class r extends o.ActionComponent {
            constructor(e, t, s, i) {
              super(e, t),
                (this.As = s),
                (this.le = i),
                (this.Cc = t.popupContent);
            }
            render() {
              const e = this.util,
                t = super.render();
              "button" === t.tagName.toLowerCase()
                ? e.addCSSClass(t, "action-popup")
                : e.addCSSClass(t.firstElementChild, "action-popup");
              const s = (0, i.getPopupContent)(e, this.Cc, this.As, this.le);
              return (
                document.body.appendChild(s),
                (this.onActionClick = () => {
                  e.removeCSSClass(s, "none"),
                    s.querySelector("button").focus();
                }),
                t
              );
            }
            getEventPayload() {
              return Promise.resolve(this.Cc);
            }
          }
          t.PopupActionComponent = r;
        },
        9e3: (e, t, s) => {
          Object.defineProperty(t, "p", { value: !0 }),
            (t.PostbackActionComponent = void 0);
          const i = s(9836);
          class o extends i.ActionComponent {
            constructor(e, t) {
              super(e, t), (this.Sc = t.postback);
            }
            getEventPayload() {
              return Promise.resolve(this.Sc);
            }
          }
          t.PostbackActionComponent = o;
        },
        6670: (e, t, s) => {
          Object.defineProperty(t, "p", { value: !0 }),
            (t.ShareActionComponent = void 0);
          const i = s(9836);
          class o extends i.ActionComponent {
            constructor(e, t, s) {
              super(e, t), (this.Ic = s);
            }
            render() {
              const e = this.util,
                t = super.render();
              return (
                "button" === t.tagName.toLowerCase()
                  ? e.addCSSClass(t, "action-share")
                  : e.addCSSClass(t.firstElementChild, "action-share"),
                t
              );
            }
            getEventPayload() {
              return Promise.resolve(this.Ic);
            }
          }
          t.ShareActionComponent = o;
        },
        2183: (e, t, s) => {
          Object.defineProperty(t, "p", { value: !0 }),
            (t.SubmitFormActionComponent = void 0);
          const i = s(9836);
          class o extends i.ActionComponent {
            constructor(e, t) {
              super(e, t), (this.Sc = t.postback);
            }
            getEventPayload() {
              return Promise.resolve(this.Sc);
            }
          }
          t.SubmitFormActionComponent = o;
        },
        9328: (e, t, s) => {
          Object.defineProperty(t, "p", { value: !0 }),
            (t.UrlActionComponent = void 0);
          const i = s(9836);
          class o extends i.ActionComponent {
            constructor(e, t, s = !1, i) {
              super(e, t), (this.Tc = s), (this.Ac = i), (this.X = t.url);
            }
            render() {
              const e = this.util,
                t = super.render();
              if (
                ("button" === t.tagName.toLowerCase()
                  ? e.addCSSClass(t, "action-url")
                  : e.addCSSClass(t.firstElementChild, "action-url"),
                this.X)
              ) {
                const s = e.createAnchor(this.X, "", [], this.Tc, this.Ac);
                t.onclick = () => {
                  s.click();
                };
              }
              return t;
            }
            getEventPayload() {
              return Promise.resolve(this.X);
            }
          }
          t.UrlActionComponent = o;
        },
        5601: (e, t, s) => {
          Object.defineProperty(t, "p", { value: !0 }),
            (t.AttachmentMessageComponent = void 0);
          const i = s(6246),
            o = s(5686),
            r = s(8216);
          class a extends r.MessageComponent {
            static fromPayload(e, t, s, r, a, n = !1) {
              if (
                a &&
                a.authToken &&
                a.uri &&
                s.url.indexOf(a.uri) >= 0 &&
                !this.Ec.test(s.url)
              ) {
                const e = null == a ? void 0 : a.authToken;
                (null == e ? void 0 : e.length) &&
                  (s.url = `${s.url}?token=${e}`);
              }
              switch (s.type) {
                case i.AttachmentType.Image:
                  return new o.ImageAttachmentComponent(e, t, s, r, n);
                case i.AttachmentType.Video:
                  return new o.VideoAttachmentComponent(e, t, s, r, n);
                case i.AttachmentType.Audio:
                  return new o.AudioAttachmentComponent(e, t, s, r, n);
                case i.AttachmentType.File:
                  return new o.FileAttachmentComponent(e, t, s, r, n);
                default:
                  throw Error("Payload contains wrong attachment type");
              }
            }
            constructor(e, t, s, i, o, r) {
              super(e, t, s, i, o, r),
                (this.Pc = a.fromPayload(
                  e,
                  t,
                  s.attachment,
                  i,
                  r,
                  this.hasActions()
                ));
            }
            getContent() {
              return super.getContent(this.Pc.render());
            }
          }
          (t.AttachmentMessageComponent = a), (a.Ec = /token=[a-z\.\d]+/i);
        },
        944: (e, t, s) => {
          Object.defineProperty(t, "p", { value: !0 }),
            (t.AttachmentComponent = void 0);
          const i = s(6246),
            o = s(8098),
            r = s(8216);
          t.AttachmentComponent = class {
            static capitalize(e) {
              return e.charAt(0).toUpperCase() + e.slice(1);
            }
            constructor(e, t, s, i, o) {
              (this.settings = e),
                (this.util = t),
                (this.side = i),
                (this.Lc = o),
                (this.X = s.url),
                (this.vc = s.type);
              const r = s.url.split("/");
              (this.En = s.title || decodeURI(r[r.length - 1])),
                (this.Fc = s.filename);
            }
            Nc(e, t) {
              const s = this.util,
                i = this.settings,
                r = s.createElement("a", [], !0),
                a = s.createIconButton({
                  css: ["attachment-control-icon", "attachment-button", "flex"],
                  icon: i.icons.download || o.iconDownload,
                  iconCss: ["attachment-download-icon"],
                  title: i.i18n[i.locale].download,
                });
              return (
                r.setAttribute("href", e),
                r.setAttribute("download", t || ""),
                r.setAttribute("target", "_blank"),
                r.appendChild(a),
                r
              );
            }
            createAttachment(e, t) {
              const s = this.util,
                a = this.settings,
                n = s.createDiv(["attachment"]),
                c = s.createDiv(["attachment-placeholder", "flex"]),
                l = s.createDiv(["attachment-icon"]),
                h = s.createImageIcon({ icon: e });
              l.appendChild(h);
              const d = this.En,
                p = s.createDiv([
                  "attachment-footer",
                  "flex",
                  this.Lc && "with-actions",
                ]),
                u = s.createLabel(["attachment-title"]),
                g = s.createDiv(["attachment-controls", "flex"]);
              if (
                ((u.innerText = d),
                u.setAttribute("title", d),
                p.appendChild(u),
                this.vc === i.AttachmentType.Image)
              ) {
                const e = s.createIconButton({
                  css: ["attachment-control-icon", "attachment-button", "flex"],
                  icon: a.icons.expandImage || o.iconZoom,
                  iconCss: ["attachment-expand-icon"],
                  title: a.i18n[a.locale].imageViewerOpen,
                });
                (e.onclick = () => {
                  this.createImagePreview(this.X, d);
                }),
                  g.appendChild(e);
              }
              if (
                (this.side === r.MESSAGE_SIDE.LEFT &&
                  g.appendChild(this.Nc(this.X, this.Fc)),
                t)
              )
                switch (
                  (c.appendChild(t),
                  (t.onerror = () => {
                    t.remove(), c.appendChild(l);
                  }),
                  this.vc)
                ) {
                  case i.AttachmentType.Image:
                    (t.onload = () => {
                      t.clientHeight > o.ATTACHMENT_MAX_HEIGHT &&
                        (c.style.alignItems = "flex-start"),
                        p.appendChild(g);
                    }),
                      (t.onclick = () => {
                        this.createImagePreview(this.X, this.En);
                      });
                    break;
                  case i.AttachmentType.Audio:
                  case i.AttachmentType.Video:
                    t.onloadeddata = () => {
                      p.appendChild(g);
                    };
                }
              else c.appendChild(l), p.appendChild(g);
              return n.appendChild(c), null == n || n.appendChild(p), n;
            }
            createImagePreview(e, t) {
              const s = this.util,
                i = "image-preview",
                r = this.settings,
                a = s.createDiv([`${i}-wrapper`]),
                n = s.createImage(e, [i]),
                c = s.createLabel([`${i}-title`]);
              c.innerText = t;
              const l = document.querySelector(
                  `.${this.settings.name}-wrapper`
                ),
                h = r.icons.close || o.iconClose,
                d = s.createIconButton({
                  css: [`${i}-close`],
                  icon: h,
                  iconCss: [`${i}-close-icon`],
                  title: r.i18n[r.locale].imageViewerClose,
                });
              (d.onclick = () => {
                a.remove();
              }),
                (d.onkeydown = (e) => {
                  "Tab" === e.code && (a.focus(), e.preventDefault());
                });
              const p = s.createDiv([`${i}-header`]);
              p.appendChild(c),
                p.appendChild(d),
                a.appendChild(p),
                a.appendChild(n),
                a.setAttribute("tabindex", "-1"),
                (a.onkeydown = (e) => {
                  "Escape" === e.code && a.remove();
                }),
                l.appendChild(a),
                a.focus();
            }
          };
        },
        6841: (e, t, s) => {
          Object.defineProperty(t, "p", { value: !0 }),
            (t.AudioAttachmentComponent = void 0);
          const i = s(8098),
            o = s(8216),
            r = s(944);
          class a extends r.AttachmentComponent {
            render() {
              const e = this.util,
                t = this.settings,
                s = t.icons.fileAudio || i.iconAudio,
                r = e.createMedia("video", this.X, ["attachment-audio"]);
              (r.controls = !0),
                (r.preload = "metadata"),
                o.MESSAGE_SIDE.RIGHT === this.side &&
                  r.setAttribute("controlsList", "nodownload");
              const a = `<a href="${this.X}">`,
                n = t.i18n[t.locale].attachmentAudioFallback
                  .replace("{0}", a)
                  .replace("{/0}", "</a>");
              return (
                (r.innerHTML = n),
                t.linkHandler
                  ? (0, i.setEmbeddedLinksHandler)(r, t.linkHandler)
                  : t.openLinksInNewWindow && (0, i.setLinksOpenInNewWindow)(r),
                this.createAttachment(s, r)
              );
            }
          }
          t.AudioAttachmentComponent = a;
        },
        9039: (e, t, s) => {
          Object.defineProperty(t, "p", { value: !0 }),
            (t.FileAttachmentComponent = void 0);
          const i = s(8098),
            o = s(944);
          class r extends o.AttachmentComponent {
            render() {
              const e = this.settings.icons.fileGeneric || i.iconFile;
              return this.createAttachment(e);
            }
          }
          t.FileAttachmentComponent = r;
        },
        1748: (e, t, s) => {
          Object.defineProperty(t, "p", { value: !0 }),
            (t.ImageAttachmentComponent = void 0);
          const i = s(8098),
            o = s(944);
          class r extends o.AttachmentComponent {
            render() {
              const e = this.util,
                t = this.settings.icons.fileImage || i.iconImage,
                s = e.createImage(this.X, ["attachment-image"], this.En);
              return this.createAttachment(t, s);
            }
          }
          t.ImageAttachmentComponent = r;
        },
        5686: function (e, t, s) {
          var i =
              (this && this.t) ||
              (Object.create
                ? function (e, t, s, i) {
                    void 0 === i && (i = s);
                    var o = Object.getOwnPropertyDescriptor(t, s);
                    (o &&
                      !("get" in o ? !t.p : o.writable || o.configurable)) ||
                      (o = {
                        enumerable: !0,
                        get: function () {
                          return t[s];
                        },
                      }),
                      Object.defineProperty(e, i, o);
                  }
                : function (e, t, s, i) {
                    void 0 === i && (i = s), (e[i] = t[s]);
                  }),
            o =
              (this && this.u) ||
              function (e, t) {
                for (var s in e)
                  "default" === s ||
                    Object.prototype.hasOwnProperty.call(t, s) ||
                    i(t, e, s);
              };
          Object.defineProperty(t, "p", { value: !0 }),
            o(s(944), t),
            o(s(6841), t),
            o(s(9039), t),
            o(s(1748), t),
            o(s(9210), t);
        },
        9210: (e, t, s) => {
          Object.defineProperty(t, "p", { value: !0 }),
            (t.VideoAttachmentComponent = void 0);
          const i = s(8098),
            o = s(8216),
            r = s(944);
          class a extends r.AttachmentComponent {
            render() {
              const e = this.util,
                t = this.settings,
                s = this.X,
                r = t.icons.fileVideo || i.iconVideo,
                a = (0, i.getEmbeddedVideo)(s, e.cssPrefix);
              if (a) {
                const t = e.createElement("span");
                return (t.innerHTML = a), t;
              }
              const n = e.createMedia("video", this.X, ["attachment-video"]);
              (n.controls = !0),
                (n.preload = "metadata"),
                o.MESSAGE_SIDE.RIGHT === this.side &&
                  n.setAttribute("controlsList", "nodownload");
              const c = `<a href="${this.X}">`,
                l = t.i18n[t.locale].attachmentVideoFallback
                  .replace("{0}", c)
                  .replace("{/0}", "</a>");
              return (
                (n.innerHTML = l),
                this.settings.linkHandler
                  ? (0, i.setEmbeddedLinksHandler)(n, t.linkHandler)
                  : this.settings.openLinksInNewWindow &&
                    (0, i.setLinksOpenInNewWindow)(n),
                this.createAttachment(r, n)
              );
            }
          }
          t.VideoAttachmentComponent = a;
        },
        4773: (e, t, s) => {
          Object.defineProperty(t, "p", { value: !0 }),
            (t.C2SQLBaseMessageComponent = void 0);
          const i = s(6246),
            o = s(8216);
          class r extends o.MessageComponent {
            constructor(e, t, s, i, o, r) {
              super(e, t, s, i, o, r),
                (this.Rc = []),
                (this.cssPrefix = e.name),
                (this.le = r),
                (this.Ar = s);
            }
            disableActions() {
              super.disableActions(),
                this.Rc.forEach((e) => {
                  e.disable();
                });
            }
            disablePostbacks() {
              super.disablePostbacks(),
                (0, o.getPostActions)(this.Rc).forEach((e) => {
                  e.disable();
                });
            }
            enableActions() {
              super.enableActions(),
                this.Rc.forEach((e) => {
                  e.enable();
                });
            }
            enablePostbacks() {
              super.enablePostbacks(),
                (0, o.getPostActions)(this.Rc).forEach((e) => {
                  e.enable();
                });
            }
            render() {
              return super.render();
            }
            getHeader() {
              const e = this.util,
                t = super.getHeader();
              return e.addCSSClass(t, "message-header-yellow"), t;
            }
            getContent(e) {
              const t = this.util,
                s = "message-bubble",
                o = this.Ar.type,
                r = t.createDiv([s]);
              o === i.MessageType.Table || o === i.MessageType.TableForm
                ? t.addCSSClass(r, `${s}-tabular-message`)
                : t.addCSSClass(
                    r,
                    `${s}-form-message`,
                    o === i.MessageType.EditForm ? "edit-form-message" : ""
                  ),
                e && r.appendChild(e);
              const a = this.getPageStatus();
              return a && r.appendChild(a), r;
            }
            getPageStatus() {
              const e = this.util;
              let t;
              const s = this.Ar.paginationInfo;
              return (
                s &&
                  s.totalCount > s.rangeSize &&
                  ((t = e.createTextDiv(["results-page-status"])),
                  (t.innerText = s.status)),
                t
              );
            }
          }
          t.C2SQLBaseMessageComponent = r;
        },
        1875: (e, t, s) => {
          Object.defineProperty(t, "p", { value: !0 }),
            (t.EditFormMessageComponent = void 0);
          const i = s(6246),
            o = s(6064),
            r = s(8098),
            a = s(9780),
            n = s(4773),
            c = s(3276),
            l = s(9608),
            h = "aria-expanded",
            d = "";
          class p extends n.C2SQLBaseMessageComponent {
            constructor() {
              super(...arguments),
                (this.Dc = 0),
                (this.Hc = 0),
                (this.Uc = []),
                (this.ds = new a.Logger("EditFormMessageComponent")),
                (this.Vc = {});
            }
            disableActions() {
              super.disableActions(), u(this.Bc, this.Uc, this.util);
            }
            disablePostbacks() {
              super.disablePostbacks(), u(this.Bc, this.Uc, this.util);
            }
            enableActions() {
              super.enableActions(), u(this.Bc, this.Uc, this.util, !1);
            }
            enablePostbacks() {
              super.enablePostbacks(), u(this.Bc, this.Uc, this.util, !1);
            }
            getContent() {
              const e = this.Ar,
                t = this.settings,
                s = this.util,
                o = "form-message",
                r = `${o}-item`,
                a = s.createDiv([o]),
                n = s.createDiv([r]);
              if (e.title) {
                const t = s.createTextDiv([`${o}-header`]);
                (t.innerText = e.title), a.appendChild(t);
              }
              return (
                (0, i.isEditFormPayloadWithFields)(e)
                  ? (e.formColumns > 2 && (e.formColumns = 2),
                    e.fields
                      .filter((e) => e)
                      .forEach((t) => {
                        n.appendChild(this.Wc(t, o, !1, e.formColumns));
                      }))
                  : e.formRows.forEach((e) => {
                      const i = (0, l.getFormRow)(
                          e,
                          this.Rc,
                          s,
                          t,
                          this.shareText,
                          this.handleOnActionClick.bind(this),
                          this.options
                        ),
                        r = e.columns.length;
                      e.columns.forEach((e) => {
                        const t = (0, l.getFormRowColumn)(e, s);
                        e.fields
                          .filter((e) => e)
                          .forEach((s) => {
                            t.appendChild(this.Wc(s, o, !0)),
                              (0, l.setMaxColumnWidth)(
                                e.width,
                                s.displayType,
                                t,
                                r
                              );
                          }),
                          i.appendChild(t);
                      }),
                        n.appendChild(i);
                    }),
                this.actions
                  .concat(this.Rc)
                  .some((e) => e.getActionType() === i.ActionType.SubmitForm) ||
                  this.ds.error("Payload does not contain submit-form action"),
                this.Zc(
                  n,
                  e.errorMessage ||
                    (this.Hc && this.Dc > 1
                      ? this.translations.editFormErrorMessage
                      : d),
                  !0
                ),
                a.appendChild(n),
                (this.Gc = n),
                super.getContent(a)
              );
            }
            validateForm() {
              var e;
              let t = !0;
              return (
                null === (e = this.Bc) || void 0 === e || e.remove(),
                this.Uc.forEach((e) => {
                  t = this.qc(e) && t;
                }),
                !t &&
                  this.Dc > 1 &&
                  this.Zc(this.Gc, this.translations.editFormErrorMessage, !0),
                t
              );
            }
            getSubmittedFields() {
              return (
                this.Uc.filter((e) => {
                  const t = e.tagName.toLowerCase();
                  return (
                    "textarea" === t && (this.Vc[e.id] = e.value), "input" === t
                  );
                }).forEach((e) => {
                  const t = e;
                  switch (t.type) {
                    case "checkbox":
                      this.Vc[t.id] = t.checked
                        ? t.getAttribute("valueOn")
                        : t.getAttribute("valueOff");
                      break;
                    case "number":
                      this.Vc[t.id] = t.valueAsNumber;
                      break;
                    default:
                      this.Vc[t.id] = t.value;
                  }
                }),
                this.Vc
              );
            }
            Wc(e, t, s, o) {
              const r = this.shareText,
                a = this.util;
              if ((this.Dc++, (0, i.isReadOnlyField)(e))) {
                const t = new c.FieldComponent(
                  this.settings,
                  a,
                  e,
                  r,
                  this.options,
                  o
                );
                return (
                  (t.isColumnField = s),
                  (t.onActionClick = this.handleOnActionClick.bind(this)),
                  t.action && this.Rc.push(t.action),
                  t.render()
                );
              }
              return s
                ? (0, c.applyMarginTop)(this.Yc(e, o, t, a), e.marginTop, a)
                : this.Yc(e, o, t, a);
            }
            Yc(e, t, s, a) {
              var n, l, p, u, g;
              const m = `${s}-field`,
                b = [m, `${m}-col-${t}`, `edit-${m}`],
                f = a.createDiv(b),
                w = a.createDiv([`${s}-key`, "with-margin"]),
                {
                  labelFontSize: v,
                  labelFontWeight: x,
                  id: k,
                  displayType: y,
                  placeholder: _,
                  required: O,
                  clientErrorMessage: M,
                  serverErrorMessage: j,
                  autoSubmit: z,
                } = e;
              let $, I, C;
              switch (
                ((w.innerHTML = e.label || d),
                (0, c.applyFontStyles)(w, v, x, a),
                f.appendChild(w),
                y)
              ) {
                case i.DisplayType.SingleSelect:
                  const t = e;
                  if (
                    ((I = t.defaultValue),
                    (C = t.layoutStyle),
                    I && (this.Vc[k] = I),
                    C && "list" !== C)
                  ) {
                    if ("radioGroup" === C) {
                      const e = a.createElement("form", [
                        `${s}-value`,
                        "form-container",
                        "col",
                      ]);
                      a.setAttributes(e, { id: k, ariaLabel: y, errorMsg: M }),
                        (e.onclick = (e) => e.stopPropagation()),
                        t.options.forEach((t) => {
                          const s = a.createInputElement(
                            {
                              type: "radio",
                              name: k,
                              value: t.label,
                              required: O,
                              checked: t.value === I,
                            },
                            ["radio-input"]
                          );
                          s.onchange = () => {
                            s.checked && (this.Vc[k] = t.value),
                              this.Jc(k, z, e);
                          };
                          const i = a.createLabel();
                          (i.innerText = t.label),
                            i.prepend(s),
                            e.appendChild(i);
                        }),
                        this.Uc.push(e),
                        f.appendChild(e),
                        this.Zc(e, j);
                    } else
                      this.ds.error(
                        `Payload contains wrong layout style:${C} for single select field`
                      );
                  } else {
                    const e = a.createDiv(["select-wrapper", `${s}-value`]),
                      i = a.createInputElement(
                        {
                          type: "text",
                          placeholder: _,
                          required: O,
                          id: k,
                          autocomplete: "off",
                        },
                        [`${s}-value`]
                      ),
                      c = a.createDiv(),
                      l = a.createDiv(["listbox", "popup", "none"]),
                      p = a.createElement("ul", ["single-select-list"]),
                      u = p.getElementsByTagName("li"),
                      g = a.createIconButton({
                        css: ["select-icon"],
                        icon: r.iconCaretDown,
                        iconCss: [],
                        title: d,
                      }),
                      m = (t) => {
                        "true" !== e.getAttribute(h) ||
                          c.contains(t.target) ||
                          (v || (i.value = d), w(!1));
                      },
                      b = () => {
                        "false" === e.getAttribute(h) &&
                          (e.setAttribute(h, "true"),
                          a.removeCSSClass(l, "none"),
                          setTimeout(() =>
                            document.addEventListener("click", m)
                          ),
                          i.focus());
                      },
                      w = (t = !0) => {
                        "true" === e.getAttribute(h) &&
                          (v && (i.value = v.textContent || v.innerText),
                          e.setAttribute(h, "false"),
                          a.addCSSClass(l, "none"),
                          document.removeEventListener("click", m),
                          this.Kc(d, u, x),
                          t && i.focus());
                      };
                    let v,
                      x = [];
                    a.setAttributes(e, { errorMsg: M }),
                      e.setAttribute(h, "false"),
                      e.setAttribute("aria-label", y),
                      (e.onclick = (e) => {
                        e.stopPropagation(), b();
                      }),
                      (e.oninput = () => {
                        this.Kc(i.value, u, x) ? b() : w();
                      }),
                      (e.onkeydown = (e) => {
                        var t;
                        const s = e.key;
                        s === o.KeyCode.Down || s === o.KeyCode.Up
                          ? !v || v.classList.contains(`${this.cssPrefix}-none`)
                            ? null === (t = x[0]) || void 0 === t || t.focus()
                            : null == v || v.focus()
                          : (s !== o.KeyCode.Esc && s !== o.KeyCode.Tab) || w();
                      }),
                      (i.onfocus = () => a.addCSSClass(e, "focused")),
                      (i.onblur = () => a.removeCSSClass(e, "focused")),
                      (g.onclick = (t) => {
                        t.stopPropagation(),
                          "true" === e.getAttribute(h) ? w() : b();
                      }),
                      null === (n = t.options) ||
                        void 0 === n ||
                        n.forEach((t) => {
                          const s = a.createListItem(
                            t.label,
                            t.label,
                            t.label,
                            d,
                            d,
                            () => {
                              a.addCSSClass(s, "selected"),
                                v && a.removeCSSClass(v, "selected"),
                                (v = s),
                                w(),
                                (this.Vc[k] = t.value),
                                this.Jc(k, z, e);
                            },
                            !1,
                            !1
                          );
                          (s.onkeydown = (e) => this.Xc(e, s, p, i, x)),
                            t.value === I &&
                              (a.addCSSClass(s, "selected"),
                              (v = s),
                              (i.value = t.label)),
                            p.appendChild(s);
                        }),
                      (x = Array.from(u)),
                      (c.onclick = (e) => e.stopPropagation()),
                      e.appendChild(i),
                      e.appendChild(g),
                      l.appendChild(p),
                      c.appendChild(l),
                      f.appendChild(e),
                      f.appendChild(c),
                      this.Uc.push(e),
                      this.Zc(i, j);
                  }
                  break;
                case i.DisplayType.MultiSelect:
                  const c = e;
                  if (
                    ((I = c.defaultValue),
                    (C = c.layoutStyle),
                    (this.Vc[k] = I || []),
                    C && "list" !== C)
                  ) {
                    if ("checkboxes" === C) {
                      const e = a.createElement("form", [
                        `${s}-value`,
                        "form-container",
                        "col",
                      ]);
                      a.setAttributes(e, {
                        id: k,
                        ariaLabel: y,
                        errorMsg: M,
                        ariaRequired: O ? "true" : "false",
                      }),
                        (e.onclick = (e) => e.stopPropagation()),
                        c.options.forEach((t) => {
                          const s = a.createInputElement(
                              {
                                type: "checkbox",
                                name: k,
                                value: t.label,
                                checked:
                                  null == I ? void 0 : I.includes(t.value),
                                required: O,
                              },
                              ["radio-input"]
                            ),
                            i = a.createLabel();
                          (i.innerText = t.label),
                            i.prepend(s),
                            (s.onchange = () => {
                              if (s.checked) this.Vc[k].push(t.value);
                              else {
                                const e = this.Vc[k];
                                e.splice(e.indexOf(t.value), 1);
                              }
                              this.Jc(k, z, e);
                            }),
                            e.appendChild(i);
                        }),
                        this.Uc.push(e),
                        f.appendChild(e),
                        this.Zc(e, j);
                    } else
                      this.ds.error(
                        `Payload contains wrong layout style:${C} for multi select field`
                      );
                  } else {
                    const e = a.createDiv([
                        `${s}-value`,
                        "text-field-container",
                      ]),
                      t = a.createElement("ul", ["selected-options"]),
                      i = a.createDiv(),
                      n = a.createDiv(["listbox", "popup", "none"]),
                      p = [],
                      u = a.createDiv(["filter-message-box"]),
                      g = a.createDiv(["filter-message-text", "none"]),
                      m = a.createInputElement({ type: "text" }, [
                        `${s}-value`,
                        "listbox-search",
                        "none",
                      ]),
                      b = a.createElement("ul", ["multi-select-list"]),
                      w = b.getElementsByTagName("li"),
                      v = a.createDiv(["search-icon-wrapper", "none"]),
                      x = a.createImageIcon({
                        icon: r.iconSearch,
                        iconCss: ["search-icon"],
                      });
                    (g.textContent = this.translations.noResultText),
                      u.appendChild(g),
                      (m.oninput = () =>
                        this.Kc(m.value, w, p)
                          ? a.addCSSClass(g, "none")
                          : a.removeCSSClass(g, "none")),
                      (m.onkeydown = (t) => {
                        var s;
                        const i = t.key;
                        i === o.KeyCode.Down
                          ? (this.Kc(m.value, w, p),
                            null === (s = p[0]) || void 0 === s || s.focus())
                          : (i !== o.KeyCode.Esc && i !== o.KeyCode.Tab) ||
                            e.click();
                      }),
                      _ && t.setAttribute("data-placeholder", _),
                      e.setAttribute(h, "false");
                    const y = (t) => {
                        "true" !== e.getAttribute(h) ||
                          i.contains(t.target) ||
                          $();
                      },
                      $ = () => {
                        e.setAttribute(h, "false"),
                          a.addCSSClass(n, "none"),
                          document.removeEventListener("click", y),
                          (m.value = d),
                          this.Kc(m.value, w, p),
                          a.addCSSClass(m, "none"),
                          a.addCSSClass(v, "none"),
                          a.addCSSClass(g, "none");
                      };
                    (e.onclick = (t) => {
                      if ((t.stopPropagation(), "true" === e.getAttribute(h)))
                        $(), e.focus();
                      else {
                        e.setAttribute(h, "true"), a.removeCSSClass(n, "none");
                        const t = b.firstElementChild;
                        t ? t.focus() : a.removeCSSClass(g, "none"),
                          setTimeout(() =>
                            document.addEventListener("click", y)
                          );
                      }
                    }),
                      (e.onkeydown = (t) => {
                        const s = t.code;
                        t.ctrlKey ||
                          t.altKey ||
                          t.metaKey ||
                          t.shiftKey ||
                          s === o.KeyCode.Esc ||
                          s === o.KeyCode.Tab ||
                          (e.click(),
                          a.removeCSSClass(m, "none"),
                          a.removeCSSClass(v, "none"),
                          m.focus());
                      }),
                      a.setAttributes(e, {
                        id: k,
                        ariaRequired: O ? "true" : "false",
                      }),
                      (e.tabIndex = 0),
                      M && e.setAttribute("data-error", M),
                      null === (l = c.options) ||
                        void 0 === l ||
                        l.forEach((s) => {
                          const i = (i) => {
                              const o = a.createDiv(["multi-select-option"]);
                              o.innerText = s.label;
                              const n = a.createImageIcon({
                                icon: r.iconClose,
                                iconCss: ["opt-close"],
                              });
                              (n.onclick = () => {
                                t.removeChild(o), b.appendChild(i);
                                const r = this.Vc[k];
                                r.splice(r.indexOf(s.value), 1),
                                  this.Jc(k, z, e);
                              }),
                                o.appendChild(n),
                                (o.onclick = (t) => {
                                  t.stopPropagation(),
                                    "true" === e.getAttribute(h) && e.click();
                                }),
                                t.appendChild(o);
                            },
                            o = a.createListItem(
                              s.label,
                              s.label,
                              s.label,
                              d,
                              d,
                              () => {
                                e.click(),
                                  b.removeChild(o),
                                  this.Vc[k].push(s.value),
                                  i(o),
                                  this.Jc(k, z, e);
                              },
                              !1,
                              !1
                            );
                          (o.onkeydown = (t) => this.Xc(t, o, b, e, p)),
                            (null == I ? void 0 : I.includes(s.value))
                              ? i(o)
                              : b.appendChild(o);
                        }),
                      (i.onclick = (e) => e.stopPropagation()),
                      e.appendChild(t),
                      this.Uc.push(e),
                      f.appendChild(e),
                      v.appendChild(x),
                      n.appendChild(u),
                      n.appendChild(m),
                      n.appendChild(v),
                      n.appendChild(b),
                      i.appendChild(n),
                      f.appendChild(i),
                      this.Zc(e, j);
                  }
                  break;
                case i.DisplayType.Toggle:
                  const m = e,
                    b = a.createLabel([`${s}-value`, "toggle"]);
                  (b.tabIndex = 0),
                    (b.onclick = (e) => e.stopPropagation()),
                    ($ = a.createInputElement({
                      id: k,
                      placeholder: _,
                      required: O,
                      type: "checkbox",
                      checked: m.defaultValue === m.valueOn,
                      errorMsg: M,
                      valueOn: m.valueOn,
                      valueOff: m.valueOff,
                    }));
                  const w = m.labelOn || m.valueOn,
                    v = m.labelOff || m.valueOff;
                  $.setAttribute("aria-label", $.checked ? w : v),
                    ($.oninput = () => {
                      $.setAttribute("aria-label", $.checked ? w : v),
                        this.Jc(k, z, $);
                    }),
                    b.appendChild($),
                    b.appendChild(a.createDiv(["round-slider"])),
                    f.appendChild(b),
                    this.Zc($.parentElement, j);
                  break;
                case i.DisplayType.DatePicker:
                  const x = e;
                  $ = a.createInputElement(
                    {
                      type: "date",
                      id: k,
                      title: _,
                      required: O,
                      defaultValue: x.defaultValue,
                      min: x.minDate,
                      max: x.maxDate,
                      errorMsg: M,
                    },
                    [`${s}-value`]
                  );
                  break;
                case i.DisplayType.TimePicker:
                  const S = e;
                  $ = a.createInputElement(
                    {
                      type: "time",
                      id: k,
                      title: _,
                      required: O,
                      defaultValue: S.defaultValue,
                      min: S.minTime,
                      max: S.maxTime,
                      errorMsg: M,
                    },
                    [`${s}-value`]
                  );
                  break;
                case i.DisplayType.TextInput:
                  const T = e;
                  if (T.multiLine) {
                    const e = a.createElement("textarea", [`${s}-value`], !0);
                    a.setAttributes(e, {
                      id: k,
                      required: O,
                      minLength: T.minLength,
                      maxLength: T.maxLength,
                      defaultValue: T.defaultValue,
                      placeholder: T.placeholder,
                      errorMsg: M,
                    }),
                      (e.rows = 3),
                      (e.onchange = () => this.Jc(k, z, e)),
                      (e.onclick = (e) => e.stopPropagation()),
                      f.appendChild(e),
                      this.Uc.push(e),
                      this.Zc(e, j);
                  } else
                    $ = a.createInputElement(
                      {
                        type: T.inputStyle || "text",
                        id: k,
                        placeholder: _,
                        required: O,
                        defaultValue: T.defaultValue,
                        errorMsg: M,
                        minLength: T.minLength,
                        maxLength: T.maxLength,
                        pattern: T.validationRegularExpression,
                      },
                      [`${s}-value`]
                    );
                  break;
                case i.DisplayType.NumberInput:
                  const A = e;
                  $ = a.createInputElement(
                    {
                      type: "number",
                      id: k,
                      placeholder: _,
                      required: O,
                      defaultValue:
                        null === (p = A.defaultValue) || void 0 === p
                          ? void 0
                          : p.toString(),
                      min:
                        null === (u = A.minValue) || void 0 === u
                          ? void 0
                          : u.toString(),
                      max:
                        null === (g = A.maxValue) || void 0 === g
                          ? void 0
                          : g.toString(),
                      errorMsg: M,
                    },
                    [`${s}-value`]
                  );
                  break;
                default:
                  this.ds.error(
                    `Payload contains wrong display type:${y} for editable field`
                  );
              }
              return (
                $ &&
                  ("checkbox" !== $.type &&
                    (f.appendChild($),
                    this.Zc($, j),
                    ($.onchange = () => this.Jc(k, z, $)),
                    ($.onclick = (e) => e.stopPropagation())),
                  this.Uc.push($)),
                f
              );
            }
            qc(e, t = !1) {
              const s = e.dataset.error;
              let o,
                r = e.nextElementSibling,
                a = !0;
              switch (e.tagName.toLowerCase()) {
                case "form":
                  const t = e,
                    n = t.querySelector("input"),
                    c = t.getAttribute("aria-label");
                  if (
                    c === i.DisplayType.MultiSelect &&
                    "true" === t.ariaRequired
                  ) {
                    this.Vc[t.id].length ||
                      ((a = !1),
                      (o = s || (null == n ? void 0 : n.validationMessage)));
                  } else
                    c !== i.DisplayType.SingleSelect ||
                      t.checkValidity() ||
                      ((a = !1),
                      (o = s || (null == n ? void 0 : n.validationMessage)));
                  break;
                case "input":
                  const l = e;
                  "checkbox" === l.type
                    ? (r = r.parentElement.nextElementSibling)
                    : l.checkValidity() ||
                      ((o = s || l.validationMessage), (a = !1));
                  break;
                case "textarea":
                  const h = e;
                  h.checkValidity() ||
                    ((o = s || h.validationMessage), (a = !1));
                  break;
                case "div":
                  const d = e;
                  if (
                    ((r = r.nextElementSibling),
                    d.getAttribute("aria-label") === i.DisplayType.SingleSelect)
                  ) {
                    const e = d.firstElementChild;
                    (a = !e.required || Boolean(this.Vc[e.id])),
                      a || (o = s || e.validationMessage);
                    break;
                  }
                  "true" === d.getAttribute("aria-required") &&
                    ((o = s), (a = Boolean(this.Vc[e.id].length)));
              }
              return (
                (() => {
                  t ||
                    ("SPAN" === (null == r ? void 0 : r.tagName) &&
                      (this.util.removeCSSClass(e.parentElement, "error"),
                      r.remove(),
                      this.Hc--),
                    a ||
                      this.Zc(e, o || this.translations.editFieldErrorMessage));
                })(),
                a
              );
            }
            Kc(e, t, s) {
              const i = this.util;
              s.length = 0;
              for (let o = 0; o < t.length; o++) {
                const r = t[o],
                  a = r.querySelector("span"),
                  n = r.textContent || r.innerText;
                n.toLowerCase().indexOf(e.toLowerCase()) < 0
                  ? (i.addCSSClass(r, "none"),
                    (a.innerHTML = n.replace(/(<b>)|(<\/b>)/g, d)))
                  : ((a.innerHTML = e
                      ? n.replace(new RegExp(`${e}`, "gi"), "<b>$&</b>")
                      : n.replace(/(<b>)|(<\/b>)/g, d)),
                    i.removeCSSClass(r, "none"),
                    s.push(r));
              }
              return s.length > 0;
            }
            Xc(e, t, s, i, r) {
              var a, n, c, l;
              const h = this.cssPrefix,
                d = r.indexOf(t),
                p = r.length;
              let u = !1;
              if (!(e.ctrlKey || e.altKey || e.metaKey)) {
                if (e.shiftKey && e.code === o.KeyCode.Tab) i.click();
                else
                  switch (e.code) {
                    case o.KeyCode.Return:
                    case o.KeyCode.Space:
                      t.click(), (u = !0);
                      break;
                    case o.KeyCode.Esc:
                    case o.KeyCode.Tab:
                      i.click(),
                        e.code === o.KeyCode.Esc && (i.focus(), (u = !0));
                      break;
                    case o.KeyCode.Up:
                      const g = t.previousElementSibling || s.lastElementChild;
                      g.classList.contains(`${h}-none`)
                        ? null === (a = r[(d + p - 1) % p]) ||
                          void 0 === a ||
                          a.focus()
                        : g.focus(),
                        (u = !0);
                      break;
                    case o.KeyCode.Down:
                      const m = t.nextElementSibling || s.firstElementChild;
                      m.classList.contains(`${h}-none`)
                        ? null === (n = r[(d + 1) % p]) ||
                          void 0 === n ||
                          n.focus()
                        : m.focus(),
                        (u = !0);
                      break;
                    case o.KeyCode.Home:
                    case o.KeyCode.PageUp:
                      const b = s.firstElementChild;
                      b.classList.contains(`${h}-none`)
                        ? null === (c = r[0]) || void 0 === c || c.focus()
                        : b.focus(),
                        (u = !0);
                      break;
                    case o.KeyCode.End:
                    case o.KeyCode.PageDown:
                      const f = s.lastElementChild;
                      f.classList.contains(`${h}-none`)
                        ? null === (l = r[p - 1]) || void 0 === l || l.focus()
                        : f.focus(),
                        (u = !0);
                      break;
                    default:
                      if (i instanceof HTMLInputElement) i.focus();
                      else {
                        const e = s.previousElementSibling,
                          t = e.previousElementSibling,
                          i = this.util;
                        i.removeCSSClass(t, "none"),
                          i.removeCSSClass(e, "none"),
                          t.focus();
                      }
                  }
                u && (e.stopPropagation(), e.preventDefault());
              }
            }
            Jc(e, t, s) {
              if (this.qc(s) && t) {
                const t = (0, o.clone)(this.getSubmittedFields());
                this.Uc.forEach((e) => {
                  this.qc(e, !0) || delete t[e.id];
                }),
                  Object.keys(t).forEach((e) => {
                    const s = t[e];
                    Array.isArray(s)
                      ? 0 === s.length && delete t[e]
                      : 0 === s || s || delete t[e];
                  });
                const s = this.settings.sdkMetadata
                  ? Object.assign(
                      { version: r.SDK_VERSION },
                      this.settings.sdkMetadata
                    )
                  : { version: r.SDK_VERSION };
                this.le.webCore
                  .sendMessage(
                    (0, i.buildUserMessage)({
                      submittedFields: t,
                      partialSubmitField: e,
                      type: i.MessageType.FormSubmission,
                    }),
                    { sdkMetadata: s }
                  )
                  .then(() => {
                    const e = this.settings.disablePastActions;
                    "all" === e
                      ? this.disableActions()
                      : "postback" === e && this.disablePostbacks();
                  })
                  .catch((e) =>
                    this.ds.error(
                      "[partialSubmit] Failed to send postback message:",
                      e
                    )
                  );
              }
            }
            Zc(e, t, s = !1) {
              if (t) {
                const i = this.util,
                  o = i.createTextSpan(["field-error", s ? "form-error" : d]),
                  a = i.createImageIcon({
                    icon: r.iconError,
                    iconCss: ["form-error-icon"],
                  }),
                  n = i.createTextSpan(["error-text"]);
                if (((n.innerText = t), o.appendChild(a), o.appendChild(n), s))
                  e.appendChild(o), (this.Bc = o);
                else {
                  const t = e.parentElement;
                  i.addCSSClass(t, "error"), t.appendChild(o), this.Hc++;
                }
              }
            }
          }
          function u(e, t, s, i = !0) {
            e &&
              (i
                ? s.addCSSClass(e, "disabled")
                : s.removeCSSClass(e, "disabled")),
              t.forEach((e) => {
                switch (e.tagName.toLowerCase()) {
                  case "form":
                    const t = e.getElementsByTagName("input");
                    i
                      ? s.addCSSClass(e, "disabled")
                      : s.removeCSSClass(e, "disabled");
                    for (let e = 0; e < t.length; e++) {
                      t[e].disabled = i;
                    }
                    break;
                  case "input":
                    const o = e;
                    (o.disabled = i),
                      "checkbox" === o.type &&
                        (i
                          ? s.addCSSClass(e.parentElement, "disabled")
                          : s.removeCSSClass(e.parentElement, "disabled"));
                    break;
                  case "textarea":
                    e.disabled = i;
                    break;
                  case "div":
                    i
                      ? (s.addCSSClass(e, "disabled"),
                        s.addCSSClass(e.parentElement, "disabled"))
                      : (s.removeCSSClass(e, "disabled"),
                        s.removeCSSClass(e.parentElement, "disabled"));
                }
              });
          }
          t.EditFormMessageComponent = p;
        },
        3276: (e, t, s) => {
          Object.defineProperty(t, "p", { value: !0 }),
            (t.FieldComponent = void 0),
            (t.applyFontStyles = c),
            (t.applyMarginTop = l);
          const i = s(6246),
            o = s(6064),
            r = s(8098),
            a = s(9780),
            n = s(8216);
          function c(e, t, s, i) {
            switch (t) {
              case "large":
                i.addCSSClass(e, "font-size-lg");
                break;
              case "small":
                i.addCSSClass(e, "font-size-sm");
                break;
              default:
                i.addCSSClass(e, "font-size-md");
            }
            switch (s) {
              case "bold":
                i.addCSSClass(e, "font-weight-bold");
                break;
              case "light":
                i.addCSSClass(e, "font-weight-light");
                break;
              default:
                i.addCSSClass(e, "font-weight-md");
            }
          }
          function l(e, t, s) {
            let i = "";
            switch (t) {
              case "none":
                break;
              case "medium":
                i = "margin-top-md";
                break;
              case "large":
                i = "margin-top-lg";
                break;
              default:
                i = "margin-top-default";
            }
            return i && s.addCSSClass(e, i), e;
          }
          function h(e, t, s, i, o) {
            if (t) {
              const r = a.MessageComponentFactory.fromMessage(
                s,
                i,
                { messagePayload: t },
                o
              );
              if (r) {
                const t = i.createDiv(),
                  s = i.createDiv(["popupContent"]);
                s.appendChild(r.render()),
                  s.setAttribute("role", "tooltip"),
                  t.appendChild(s),
                  (e.style.cursor = "pointer"),
                  e.appendChild(t);
              }
            }
          }
          t.FieldComponent = class {
            constructor(e, t, s, o, r, n) {
              (this.As = e),
                (this.ni = t),
                (this.Qc = s),
                (this.le = r),
                (this.el = n),
                (this.isTableField = !1),
                (this.isColumnField = !1),
                s.displayType === i.DisplayType.Action &&
                  (this.action = a.ActionComponentFactory.fromActionPayload(
                    s.action,
                    t,
                    e,
                    o,
                    this.le
                  ));
            }
            render() {
              var e;
              const t = this.ni,
                s = this.Qc,
                a = "form-message",
                n = this.le,
                p = this.As,
                {
                  alignment: u,
                  label: g,
                  labelFontSize: m,
                  labelFontWeight: b,
                  marginTop: f,
                  onHoverPopupContent: w,
                } = s,
                v = t.createTextDiv([`${a}-value`]),
                x =
                  null === (e = s.value) || void 0 === e
                    ? void 0
                    : e.toString();
              switch (s.displayType) {
                case i.DisplayType.Link:
                  const e = t.createDiv(),
                    { imageUrl: a, linkLabel: n } = s,
                    l = t.createElement("a", n ? [] : ["ellipsis"], !0);
                  if (((l.href = x), a)) {
                    const e = t.createImage(a, ["video-wrapper"], x);
                    (e.alt = n || ""),
                      l.appendChild(e),
                      g && t.addCSSClass(v, "with-top-margin");
                  } else l.innerHTML = n || (0, o.stripHTTP)(x) || "";
                  l.setAttribute("target", "_blank"),
                    e.appendChild(l),
                    p.linkHandler
                      ? (0, r.setEmbeddedLinksHandler)(e, p.linkHandler)
                      : p.openLinksInNewWindow &&
                        (0, r.setLinksOpenInNewWindow)(e),
                    v.appendChild(l);
                  break;
                case i.DisplayType.Text:
                  const { fontSize: h, fontWeight: m, truncateAt: b } = s;
                  x && b
                    ? ((v.innerHTML = `${x.slice(0, b)}...`), (v.title = x))
                    : (v.innerHTML = x || ""),
                    c(v, h, m, t);
                  break;
                case i.DisplayType.Media:
                  const f = s.mediaType,
                    w = g && x;
                  switch (f) {
                    case "image":
                      const e = t.createImage(x, ["video-wrapper"], x);
                      w && t.addCSSClass(v, "with-top-margin"),
                        v.appendChild(e);
                      break;
                    case "video":
                      (0, r.getEmbeddedVideo)(x, t.cssPrefix)
                        ? ((v.innerHTML = (0, r.linkify)(
                            x,
                            t.cssPrefix,
                            p.embeddedVideo
                          )),
                          p.embeddedVideo &&
                            w &&
                            t.addCSSClass(v, "with-top-margin"))
                        : v.appendChild(d(f, x, v, w, t));
                      break;
                    case "audio":
                      v.appendChild(d(f, x, v, w, t));
                  }
                  break;
                case i.DisplayType.Action:
                  t.addCSSClass(v, "flex"),
                    (v.style.justifyContent = u),
                    g && t.addCSSClass(v, "with-top-margin"),
                    (this.action.onActionClick = this.onActionClick),
                    v.appendChild(this.action.render());
              }
              if (this.isTableField) return h(v, w, p, t, n), v;
              const k = `${a}-field`,
                y = [k, `${k}-col-${this.el}`],
                _ = t.createDiv(y),
                O = t.createDiv([`${a}-key`]);
              return (
                (O.innerHTML = g || ""),
                u && ((O.style.textAlign = u), (v.style.textAlign = u)),
                c(O, m, b, t),
                _.appendChild(O),
                _.appendChild(v),
                h(_, w, p, t, n),
                this.isColumnField ? l(_, f, t) : _
              );
            }
            disableActions() {
              this.action.disable();
            }
            disablePostbacks() {
              (0, n.getPostActions)([this.action]).forEach((e) => {
                e.disable();
              });
            }
            enableActions() {
              this.action.enable();
            }
            enablePostbacks() {
              (0, n.getPostActions)([this.action]).forEach((e) => {
                e.enable();
              });
            }
          };
          const d = (e, t, s, i, o) => {
            const r = o.createMedia(e, t, ["video-wrapper"]);
            return (
              (r.controls = !0),
              (r.preload = "metadata"),
              i && o.addCSSClass(s, "with-top-margin"),
              r
            );
          };
        },
        9608: (e, t, s) => {
          Object.defineProperty(t, "p", { value: !0 }),
            (t.FormMessageComponent = void 0),
            (t.applySelectAction = d),
            (t.getFormItem = l),
            (t.getFormRow = h),
            (t.getFormRowColumn = p),
            (t.setMaxColumnWidth = u);
          const i = s(6246),
            o = s(8098),
            r = s(9780),
            a = s(4773),
            n = s(3276);
          class c extends a.C2SQLBaseMessageComponent {
            getContent() {
              const e = this.util,
                t = this.settings,
                s = this.Ar,
                i = "form-message",
                o = e.createDiv([i]);
              s.formColumns > 2 && (s.formColumns = 2);
              const r = s.forms;
              return (
                r.forEach((a, n) => {
                  if (a.title) {
                    const t = e.createTextDiv([`${i}-header`]);
                    (t.innerText = a.title), o.appendChild(t);
                  }
                  const [c, h] = l(
                    e,
                    a,
                    s.formColumns,
                    t,
                    this.handleOnActionClick.bind(this),
                    this.le
                  );
                  this.Rc = this.Rc.concat(h);
                  const d = n + 1;
                  d === r.length ||
                    r[d].title ||
                    e.addCSSClass(c, "with-border"),
                    o.appendChild(c);
                }),
                super.getContent(o)
              );
            }
          }
          function l(e, t, s, a, c, l) {
            var g;
            const m = "form-message",
              b = `${m}-actions-col`,
              f =
                null === (g = t.channelExtensions) || void 0 === g
                  ? void 0
                  : g.c2kReferences,
              w = e.createDiv([`${m}-item`, f ? "c2k-reference" : ""]),
              v = l.shareText || (0, o.getFormShareText)(t, !0),
              x = (function (e, t, s, i, o, a) {
                var n;
                const c = [];
                if (
                  (null === (n = e.actions) || void 0 === n
                    ? void 0
                    : n.length) > 0
                )
                  for (const n of e.actions) {
                    const e = r.ActionComponentFactory.fromActionPayload(
                      n,
                      t,
                      s,
                      o,
                      a
                    );
                    e && ((e.onActionClick = i), c.push(e));
                  }
                return c;
              })(t, e, a, c, v, l);
            let k;
            if (
              (x.length &&
                (k = (function (e, t, s, i) {
                  const o = t.createDiv(
                    "horizontal" !== s.formActionsLayout
                      ? ["form-actions", "col", i]
                      : ["form-actions"]
                  );
                  for (const t of e) {
                    const e = t.render();
                    o.appendChild(e);
                  }
                  return o;
                })(x, e, a, b)),
              (0, i.isFormEntityWithRows)(t)
                ? t.formRows.forEach((t, s) => {
                    const o = h(t, x, e, a, v, c, l),
                      r = t.columns.length;
                    if (
                      (t.columns.forEach((t) => {
                        const s = p(t, e);
                        t.fields.forEach((o) => {
                          if ((0, i.isReadOnlyField)(o)) {
                            const i = new n.FieldComponent(a, e, o, v, l);
                            (i.isColumnField = !0),
                              (i.onActionClick = c),
                              i.action && x.push(i.action),
                              u(t.width, o.displayType, s, r),
                              s.appendChild(i.render());
                          }
                        }),
                          o.appendChild(s);
                      }),
                      f && 0 !== s)
                    ) {
                      const t = e.createTextSpan(["delimiter"]);
                      (t.innerHTML = "&bull;"),
                        o.firstElementChild.firstElementChild.lastElementChild.prepend(
                          t
                        );
                    }
                    w.appendChild(o);
                  })
                : t.fields.forEach((t) => {
                    const i = new n.FieldComponent(a, e, t, v, l, s);
                    (i.onActionClick = c),
                      i.action && x.push(i.action),
                      w.appendChild(i.render());
                  }),
              k && w.appendChild(k),
              t.selectAction)
            ) {
              d(
                r.ActionComponentFactory.fromActionPayload(
                  t.selectAction,
                  e,
                  a,
                  v,
                  l
                ),
                x,
                c,
                w,
                t.selectAction.label
              );
            }
            return [w, x];
          }
          function h(e, t, s, i, o, a, n) {
            const c = s.createDiv(["form-row", e.separator ? "separator" : ""]);
            if (e.selectAction) {
              d(
                r.ActionComponentFactory.fromActionPayload(
                  e.selectAction,
                  s,
                  i,
                  o,
                  n
                ),
                t,
                a,
                c,
                e.selectAction.label
              );
            }
            return c;
          }
          function d(e, t, s, i, o) {
            e &&
              (t.push(e),
              (e.onActionClick = s),
              (i.onclick = (t) => e.handleOnClick(t)),
              (i.title = o || ""),
              (i.style.cursor = "pointer"));
          }
          function p(e, t) {
            const { width: s, verticalAlignment: i } = e,
              o = t.createDiv(["form-row-column", s || ""]);
            return (
              "center" === i
                ? t.addCSSClass(o, "align-center")
                : "bottom" === i
                ? t.addCSSClass(o, "align-end")
                : t.addCSSClass(o, "align-start"),
              o
            );
          }
          function u(e, t, s, o) {
            "stretch" === e ||
              t !== i.DisplayType.Media ||
              s.style.maxWidth ||
              (s.style.maxWidth = `calc((100% - ${16 * (o - 1)}px)/${o})`);
          }
          t.FormMessageComponent = c;
        },
        849: function (e, t, s) {
          var i =
              (this && this.t) ||
              (Object.create
                ? function (e, t, s, i) {
                    void 0 === i && (i = s);
                    var o = Object.getOwnPropertyDescriptor(t, s);
                    (o &&
                      !("get" in o ? !t.p : o.writable || o.configurable)) ||
                      (o = {
                        enumerable: !0,
                        get: function () {
                          return t[s];
                        },
                      }),
                      Object.defineProperty(e, i, o);
                  }
                : function (e, t, s, i) {
                    void 0 === i && (i = s), (e[i] = t[s]);
                  }),
            o =
              (this && this.u) ||
              function (e, t) {
                for (var s in e)
                  "default" === s ||
                    Object.prototype.hasOwnProperty.call(t, s) ||
                    i(t, e, s);
              };
          Object.defineProperty(t, "p", { value: !0 }),
            o(s(4773), t),
            o(s(1875), t),
            o(s(3276), t),
            o(s(9608), t),
            o(s(3330), t),
            o(s(6452), t);
        },
        3330: (e, t, s) => {
          Object.defineProperty(t, "p", { value: !0 }),
            (t.TableMessageComponent = void 0),
            (t.createTableCell = l),
            (t.applyHeadingWidth = h);
          const i = s(9780),
            o = s(4773),
            r = s(3276),
            a = s(9608),
            n = 100;
          class c extends o.C2SQLBaseMessageComponent {
            getContent() {
              const e = this.util,
                t = this.Ar,
                s = h(t.headings),
                o = "table-message",
                n = e.createDiv([`${o}-wrapper`]),
                c = e.createElement("table", [o]);
              n.appendChild(c);
              const d = e.createElement("tr", [`${o}-headings`]);
              return (
                s.forEach((t) => {
                  const s = l(e, [`${o}-heading`], t.width, t.alignment);
                  (s.innerText = t.label), d.appendChild(s);
                }),
                c.appendChild(d),
                t.rows.forEach((t) => {
                  const n = e.createElement("tr", [`${o}-row`]);
                  if (t.selectAction) {
                    const s = i.ActionComponentFactory.fromActionPayload(
                      t.selectAction,
                      e,
                      this.settings,
                      this.shareText,
                      this.options
                    );
                    (0, a.applySelectAction)(
                      s,
                      this.Rc,
                      this.handleOnActionClick.bind(this),
                      n,
                      t.selectAction.label
                    );
                  }
                  t.fields.forEach((t, i) => {
                    const a = l(e, [`${o}-item`], s[i].width, t.alignment),
                      c = new r.FieldComponent(
                        this.settings,
                        e,
                        t,
                        this.shareText,
                        this.options
                      );
                    (c.isTableField = !0),
                      (c.onActionClick = this.handleOnActionClick.bind(this)),
                      c.action && this.Rc.push(c.action),
                      a.appendChild(c.render()),
                      n.appendChild(a);
                  }),
                    c.appendChild(n);
                }),
                super.getContent(n)
              );
            }
          }
          function l(e, t, s, i) {
            const o = e.createElement("td", t, !0);
            return (o.style.textAlign = i), (o.style.width = `${s}%`), o;
          }
          function h(e) {
            let t;
            if (e.every((e) => !e.width || (e.width >= 0 && e.width <= n))) {
              let s = 0,
                i = 0;
              if (
                (e.forEach((e) => {
                  e.width ? (i += e.width) : s++;
                }),
                s)
              ) {
                if (i < n) {
                  const o = (n - i) / s;
                  t = e.map((e) => (e.width || (e.width = o), e));
                } else t = d(e);
              } else if (i === n) t = e;
              else {
                const s = n / i;
                t = e.map((e) => ((e.width = e.width * s), e));
              }
            } else t = d(e);
            return t;
          }
          function d(e) {
            const t = n / e.length;
            return e.map((e) => ((e.width = t), e));
          }
          t.TableMessageComponent = c;
        },
        6452: (e, t, s) => {
          Object.defineProperty(t, "p", { value: !0 }),
            (t.TableFormMessageComponent = void 0);
          const i = s(8098),
            o = s(4773),
            r = s(3276),
            a = s(9608),
            n = s(3330);
          class c extends o.C2SQLBaseMessageComponent {
            getContent() {
              const e = this.util,
                t = this.Ar,
                s = (0, n.applyHeadingWidth)(
                  t.headings.concat({ alignment: "center", label: "" })
                ),
                o = "table-message",
                c = e.createDiv([`${o}-wrapper`]),
                l = e.createElement("table", [o, "tableform-message"]);
              c.appendChild(l);
              const h = e.createElement("tr", [`${o}-headings`]);
              s.forEach((t) => {
                const s = (0, n.createTableCell)(
                  e,
                  [`${o}-heading`],
                  t.width,
                  t.alignment
                );
                (s.innerText = t.label), h.appendChild(s);
              }),
                l.appendChild(h);
              return (
                (h.lastElementChild.style.width = "32px"),
                t.rows.forEach((c, h) => {
                  const d = e.createElement("tr", [`${o}-row`]);
                  c.fields.forEach((t, i) => {
                    const a = (0, n.createTableCell)(
                        e,
                        [`${o}-item`],
                        s[i].width,
                        t.alignment
                      ),
                      c = new r.FieldComponent(
                        this.settings,
                        e,
                        t,
                        this.shareText,
                        this.options
                      );
                    (c.isTableField = !0),
                      (c.onActionClick = this.handleOnActionClick.bind(this)),
                      c.action && this.Rc.push(c.action),
                      a.appendChild(c.render()),
                      d.appendChild(a);
                  }),
                    t.formColumns > 2 && (t.formColumns = 2);
                  const p = t.forms[h],
                    u = (0, n.createTableCell)(e, [`${o}-item`, "button-cell"]),
                    g = e.createIconButton({
                      css: [`${o}-item`, `${o}-item-form-toggle`],
                      icon: i.iconChevronDown,
                      iconCss: [],
                      title: p.title || "",
                    });
                  u.appendChild(g), d.appendChild(u);
                  const m = "none",
                    b = "rotate-180",
                    [f, w] = (0, a.getFormItem)(
                      e,
                      p,
                      t.formColumns,
                      this.settings,
                      this.handleOnActionClick.bind(this),
                      this.le
                    );
                  (this.Rc = this.Rc.concat(w)), e.addCSSClass(f, m);
                  let v = !1;
                  (d.onclick = () => {
                    v
                      ? (e.addCSSClass(f, m), e.removeCSSClass(g, b))
                      : (e.removeCSSClass(f, m), e.addCSSClass(g, b)),
                      (v = !v);
                  }),
                    l.appendChild(d),
                    l.appendChild(f);
                }),
                super.getContent(c)
              );
            }
          }
          t.TableFormMessageComponent = c;
        },
        9811: (e, t, s) => {
          Object.defineProperty(t, "p", { value: !0 }),
            (t.CardMessageComponent = void 0);
          const i = s(8098),
            o = s(9020),
            r = s(8216);
          class a extends r.MessageComponent {
            constructor(e, t, s, i, r, a) {
              super(e, t, s, i, r, a),
                (this.tl = []),
                (this.sl = s.layout),
                (this.il = s.cards.length);
              let n = 0;
              s.cards.forEach((e) => {
                n++,
                  this.tl.push(new o.CardComponent(this.settings, t, e, n, a));
              }),
                (this.globalActions = this.actions.concat(this.globalActions)),
                (this.actions = []),
                (this.ol = !1),
                (this.rl = !0);
            }
            hasActions() {
              return (
                this.tl[0].hasActions() ||
                this.actions.length > 0 ||
                this.globalActions.length > 0
              );
            }
            disableActions() {
              super.disableActions(),
                this.tl.forEach((e) => {
                  e.disableActions();
                });
            }
            disablePostbacks() {
              super.disablePostbacks(),
                this.tl.forEach((e) => {
                  e.disablePostbacks();
                });
            }
            enableActions() {
              super.enableActions(),
                this.tl.forEach((e) => {
                  e.enableActions();
                });
            }
            enablePostbacks() {
              super.enablePostbacks(),
                this.tl.forEach((e) => {
                  e.enablePostbacks();
                });
            }
            render() {
              const e = this.util,
                t = this.settings.name,
                s = [`card-message-${this.sl}`],
                i = super.render();
              if (i.querySelector(`.${t}-icon-wrapper`)) {
                s.push("has-message-icon");
                const o = i.querySelector(`.${t}-content-wrapper`);
                e.addCSSClass(o, "with-icon");
              }
              return e.addCSSClass(i, ...s), i;
            }
            setCardsScrollAttributes(e) {
              (this.ol = "rtl" === getComputedStyle(this.al).direction),
                (this.rl = "default" === e);
            }
            getContent() {
              const e = this.util,
                t = this.il,
                s = e.createDiv(["card-message-content"]),
                o = e.createDiv(["card-message-cards"]);
              let r = !0;
              if (
                (this.tl.forEach((e) => {
                  e.onActionClick = this.handleOnActionClick.bind(this);
                  const t = e.render();
                  r &&
                    e.hasActions() &&
                    ((this.firstActionButton = e.getFirstActionButton()),
                    (r = !1)),
                    o.appendChild(t);
                }),
                s.appendChild(o),
                "horizontal" === this.sl && t > 1)
              ) {
                let e;
                s.appendChild(this.cl()),
                  (this.ll = 0),
                  o.addEventListener("scroll", () => {
                    window.clearTimeout(e),
                      (e = window.setTimeout(() => {
                        let e = 0;
                        for (let s = 0; s < t; s++) {
                          const i = this.ol ? t - s - 1 : s,
                            r = o.children[i];
                          if (o.scrollLeft <= r.offsetLeft + 5) {
                            e = i;
                            break;
                          }
                        }
                        e !== this.ll && ((this.ll = e), this.hl());
                      }, 100));
                  }),
                  window.addEventListener(
                    "resize",
                    (0, i.debounce)(() => {
                      this.dl();
                    }, 500)
                  );
              }
              (this.pl = s), (this.al = o);
              const a = this.settings.name;
              return (
                new IntersectionObserver(
                  (e) => {
                    e.forEach((e) => {
                      e.isIntersecting && this.dl();
                    });
                  },
                  { root: document.querySelector(`.${a}-conversation`) }
                ).observe(o),
                s
              );
            }
            cl() {
              if (!this.ul) {
                const e = this.util,
                  t = this.translations.cardNavNext;
                this.ul = e.createDiv(["next-wrapper"]);
                const s = e.createIconButton({
                  css: ["round", "next"],
                  icon: i.iconChevronNext,
                  iconCss: [],
                  title: t,
                });
                (s.onclick = this.gl.bind(this)), this.ul.appendChild(s);
              }
              return this.ul;
            }
            ml() {
              if (!this.bl) {
                const e = this.util,
                  t = this.translations.cardNavPrevious;
                this.bl = e.createDiv(["prev-wrapper"]);
                const s = e.createIconButton({
                  css: ["round", "previous"],
                  icon: i.iconChevronPrevious,
                  iconCss: [],
                  title: t,
                });
                (s.onclick = this.fl.bind(this)), this.bl.appendChild(s);
              }
              return this.bl;
            }
            gl() {
              this.ll < this.il && (this.ll++, this.hl());
            }
            fl() {
              this.ll > 0 && (this.ll--, this.hl());
            }
            hl() {
              var e, t, s, i;
              const o = this.al.children[this.ll];
              if (o) {
                const r = 52,
                  a = 68;
                (this.al.scrollLeft = o.offsetLeft - (this.rl ? r : a)),
                  0 === this.ll
                    ? null === (e = this.bl) || void 0 === e || e.remove()
                    : (null === (t = this.bl) || void 0 === t
                        ? void 0
                        : t.parentElement) || this.pl.prepend(this.ml()),
                  this.ll === this.il - 1
                    ? null === (s = this.ul) || void 0 === s || s.remove()
                    : (null === (i = this.ul) || void 0 === i
                        ? void 0
                        : i.parentElement) || this.pl.appendChild(this.cl());
              }
            }
            dl() {
              this.al.scrollWidth === this.al.offsetWidth
                ? (this.ul && (this.ul.hidden = !0),
                  this.bl && (this.bl.hidden = !0))
                : (this.ul && (this.ul.hidden = !1),
                  this.bl && (this.bl.hidden = !1));
            }
          }
          t.CardMessageComponent = a;
        },
        5696: function (e, t, s) {
          var i =
              (this && this.t) ||
              (Object.create
                ? function (e, t, s, i) {
                    void 0 === i && (i = s);
                    var o = Object.getOwnPropertyDescriptor(t, s);
                    (o &&
                      !("get" in o ? !t.p : o.writable || o.configurable)) ||
                      (o = {
                        enumerable: !0,
                        get: function () {
                          return t[s];
                        },
                      }),
                      Object.defineProperty(e, i, o);
                  }
                : function (e, t, s, i) {
                    void 0 === i && (i = s), (e[i] = t[s]);
                  }),
            o =
              (this && this.u) ||
              function (e, t) {
                for (var s in e)
                  "default" === s ||
                    Object.prototype.hasOwnProperty.call(t, s) ||
                    i(t, e, s);
              };
          Object.defineProperty(t, "p", { value: !0 }), o(s(9811), t);
        },
        9020: (e, t, s) => {
          Object.defineProperty(t, "p", { value: !0 }),
            (t.CardComponent = void 0);
          const i = s(8098),
            o = s(9780),
            r = s(8216);
          t.CardComponent = class {
            constructor(e, t, s, i, a) {
              var n;
              if (
                ((this.As = e),
                (this.ni = t),
                (this.le = a),
                (this.Rc = []),
                (this.wl = []),
                (this.En = s.title),
                (this.vl = s.description),
                (this.kc = s.imageUrl),
                (this.X = s.url),
                s.actions)
              ) {
                for (const i of s.actions) {
                  const s =
                      (this.En ? `${this.En} - ` : "") +
                      (this.vl ? `${this.vl} - ` : "") +
                      (null !== (n = this.X) && void 0 !== n ? n : ""),
                    r = o.ActionComponentFactory.fromActionPayload(
                      i,
                      t,
                      e,
                      s,
                      a
                    );
                  r &&
                    ((r.onActionClick = this.handleOnActionClick.bind(this)),
                    this.Rc.push(r));
                }
                this.wl = (0, r.getPostActions)(this.Rc);
              }
            }
            handleOnActionClick(e) {
              this.onActionClick && this.onActionClick(e);
            }
            render() {
              const e = this.ni,
                t = this.As,
                s = t.embeddedVideo,
                o = t.locale,
                r = this.X,
                a = e.createDiv(["card"]),
                n = r
                  ? e.createAnchor(
                      r,
                      "",
                      ["card-component"],
                      t.openLinksInNewWindow,
                      t.linkHandler
                    )
                  : e.createDiv(["card-content"]);
              if ((this.X && (n.innerText = ""), this.kc)) {
                const s = t.i18n;
                let i = s[o].cardImagePlaceholder;
                if (this.le && this.le.locale) {
                  const e = s[this.le.locale];
                  i = e ? e.cardImagePlaceholder : i;
                }
                n.appendChild(e.createImage(this.kc, ["card-image"], i));
              }
              const c = e.createTextDiv(["card-title"]);
              if (
                ((c.innerHTML = (0, i.linkify)(this.En, e.cssPrefix, s)),
                n.appendChild(c),
                this.vl)
              ) {
                const t = e.createTextDiv(["card-description"]);
                (t.innerHTML = (0, i.linkify)(this.vl, e.cssPrefix, s)),
                  n.appendChild(t);
              }
              if (
                (a.appendChild(n),
                t.linkHandler
                  ? (0, i.setEmbeddedLinksHandler)(n, t.linkHandler)
                  : t.openLinksInNewWindow && (0, i.setLinksOpenInNewWindow)(n),
                this.Rc.length > 0)
              ) {
                const s = e.createDiv(
                  "horizontal" !== t.cardActionsLayout
                    ? ["card-actions", "col"]
                    : ["card-actions"]
                );
                let i = !0;
                for (const e of this.Rc) {
                  const t = e.render();
                  i && ((this.xl = t), (i = !1)), s.appendChild(t);
                }
                a.appendChild(s);
              }
              return a;
            }
            hasActions() {
              return this.Rc.length > 0;
            }
            disableActions() {
              this.Rc.forEach((e) => e.disable());
            }
            disablePostbacks() {
              this.wl.forEach((e) => e.disable());
            }
            enableActions() {
              this.Rc.forEach((e) => e.enable());
            }
            enablePostbacks() {
              this.wl.forEach((e) => e.enable());
            }
            getFirstActionButton() {
              return this.xl;
            }
          };
        },
        5915: function (e, t, s) {
          var i =
              (this && this.t) ||
              (Object.create
                ? function (e, t, s, i) {
                    void 0 === i && (i = s);
                    var o = Object.getOwnPropertyDescriptor(t, s);
                    (o &&
                      !("get" in o ? !t.p : o.writable || o.configurable)) ||
                      (o = {
                        enumerable: !0,
                        get: function () {
                          return t[s];
                        },
                      }),
                      Object.defineProperty(e, i, o);
                  }
                : function (e, t, s, i) {
                    void 0 === i && (i = s), (e[i] = t[s]);
                  }),
            o =
              (this && this.u) ||
              function (e, t) {
                for (var s in e)
                  "default" === s ||
                    Object.prototype.hasOwnProperty.call(t, s) ||
                    i(t, e, s);
              };
          Object.defineProperty(t, "p", { value: !0 }),
            o(s(7007), t),
            o(s(5601), t),
            o(s(5686), t),
            o(s(849), t),
            o(s(5696), t),
            o(s(9020), t),
            o(s(8036), t),
            o(s(5174), t),
            o(s(2835), t),
            o(s(8216), t),
            o(s(5611), t),
            o(s(4266), t),
            o(s(2971), t),
            o(s(8766), t),
            o(s(8145), t),
            o(s(2467), t),
            o(s(402), t),
            o(s(5793), t);
        },
        5174: function (e, t, s) {
          var i =
              (this && this.t) ||
              (Object.create
                ? function (e, t, s, i) {
                    void 0 === i && (i = s);
                    var o = Object.getOwnPropertyDescriptor(t, s);
                    (o &&
                      !("get" in o ? !t.p : o.writable || o.configurable)) ||
                      (o = {
                        enumerable: !0,
                        get: function () {
                          return t[s];
                        },
                      }),
                      Object.defineProperty(e, i, o);
                  }
                : function (e, t, s, i) {
                    void 0 === i && (i = s), (e[i] = t[s]);
                  }),
            o =
              (this && this.u) ||
              function (e, t) {
                for (var s in e)
                  "default" === s ||
                    Object.prototype.hasOwnProperty.call(t, s) ||
                    i(t, e, s);
              };
          Object.defineProperty(t, "p", { value: !0 }), o(s(909), t);
        },
        909: (e, t, s) => {
          Object.defineProperty(t, "p", { value: !0 }),
            (t.LoadingMessageComponent = void 0);
          const i = s(8036),
            o = s(8216);
          t.LoadingMessageComponent = class {
            constructor(e, t, s, i) {
              (this.kl = e), (this.yl = t), (this.As = s), (this.ni = i);
            }
            render() {
              const e = this.ni,
                t = this.As,
                s = t.icons,
                r = e.createDiv(["attachment"]),
                a =
                  this.yl === o.MESSAGE_SIDE.LEFT ? s.avatarBot : s.avatarUser,
                n = e.createDiv(["attachment-footer", "flex"]),
                c = e.createTextDiv(["attachment-title"]);
              (c.innerText = this.kl), n.appendChild(c);
              const l = e.createDiv(["attachment-placeholder", "flex"]);
              return (
                l.appendChild(new i.SpinnerComponent(e).render()),
                r.appendChild(l),
                r.appendChild(n),
                (this.Dt = t.searchBarMode
                  ? e.getMessage(r)
                  : e.getMessageBlock(this.yl, r, a)),
                this.Dt
              );
            }
            remove() {
              this.Dt.remove();
            }
          };
        },
        8036: function (e, t, s) {
          var i =
              (this && this.t) ||
              (Object.create
                ? function (e, t, s, i) {
                    void 0 === i && (i = s);
                    var o = Object.getOwnPropertyDescriptor(t, s);
                    (o &&
                      !("get" in o ? !t.p : o.writable || o.configurable)) ||
                      (o = {
                        enumerable: !0,
                        get: function () {
                          return t[s];
                        },
                      }),
                      Object.defineProperty(e, i, o);
                  }
                : function (e, t, s, i) {
                    void 0 === i && (i = s), (e[i] = t[s]);
                  }),
            o =
              (this && this.u) ||
              function (e, t) {
                for (var s in e)
                  "default" === s ||
                    Object.prototype.hasOwnProperty.call(t, s) ||
                    i(t, e, s);
              };
          Object.defineProperty(t, "p", { value: !0 }), o(s(184), t);
        },
        184: (e, t) => {
          Object.defineProperty(t, "p", { value: !0 }),
            (t.SpinnerComponent = void 0);
          t.SpinnerComponent = class {
            constructor(e) {
              this.ni = e;
            }
            render() {
              const e = this.ni.createDiv(["spinner"]);
              return (
                (e.innerHTML =
                  '<svg viewBox="0 0 64 64"><circle transform="translate(32,32)" r="26"></circle></svg>'),
                e
              );
            }
          };
        },
        2835: (e, t, s) => {
          Object.defineProperty(t, "p", { value: !0 }),
            (t.LocationMessageComponent = void 0);
          const i = s(8098),
            o = s(8216);
          class r extends o.MessageComponent {
            constructor(e, t, s, i, o, r) {
              super(e, t, s, i, o, r);
              const a = s.location;
              (this.En = a.title),
                (this.X = a.url),
                (this._l = a.longitude),
                (this.Ol = a.latitude);
            }
            render() {
              const e = this.util,
                t = e.createDiv(["message"]);
              t.lang = this.locale;
              const s = e.createDiv(["message-wrapper"]);
              t.appendChild(s);
              const o = e.createDiv(["attachment"]),
                r = e.createDiv(["attachment-placeholder", "flex"]),
                a = e.createDiv(["attachment-icon"]),
                n = e.createImageIcon({
                  icon:
                    this.settings.icons.shareMenuLocation ||
                    i.iconShareLocation,
                }),
                c = e.createDiv(["attachment-footer", "flex"]),
                l = e.createLabel(["attachment-title"]);
              if (
                ((l.innerText = this.En
                  ? this.En
                  : `${this.Ol.toFixed(4)}, ${this._l.toFixed(4)}`),
                c.appendChild(l),
                a.appendChild(n),
                r.appendChild(a),
                !this.actions.length)
              ) {
                const t = e.createDiv(["attachment-controls"]),
                  s = e.createIconButton({
                    css: [
                      "attachment-control-icon",
                      "attachment-button",
                      "flex",
                    ],
                    icon:
                      this.settings.icons.externalLink || i.iconExternalLink,
                    iconCss: [],
                    title: this.translations.openMap,
                  }),
                  o = e.createAnchor(
                    this.X ||
                      `https://www.google.com/maps/@${this.Ol},${this._l},12z`,
                    "",
                    [],
                    this.settings.openLinksInNewWindow,
                    this.settings.linkHandler
                  );
                (s.onclick = () => {
                  o.click();
                }),
                  t.appendChild(s),
                  c.appendChild(t);
              }
              return (
                o.appendChild(r),
                o.appendChild(c),
                s.appendChild(this.getContent(o)),
                t
              );
            }
          }
          t.LocationMessageComponent = r;
        },
        5611: function (e, t, s) {
          var i =
              (this && this.t) ||
              (Object.create
                ? function (e, t, s, i) {
                    void 0 === i && (i = s);
                    var o = Object.getOwnPropertyDescriptor(t, s);
                    (o &&
                      !("get" in o ? !t.p : o.writable || o.configurable)) ||
                      (o = {
                        enumerable: !0,
                        get: function () {
                          return t[s];
                        },
                      }),
                      Object.defineProperty(e, i, o);
                  }
                : function (e, t, s, i) {
                    void 0 === i && (i = s), (e[i] = t[s]);
                  }),
            o =
              (this && this.u) ||
              function (e, t) {
                for (var s in e)
                  "default" === s ||
                    Object.prototype.hasOwnProperty.call(t, s) ||
                    i(t, e, s);
              };
          Object.defineProperty(t, "p", { value: !0 }), o(s(7249), t);
        },
        7249: (e, t, s) => {
          Object.defineProperty(t, "p", { value: !0 }),
            (t.MessageStringComponent = void 0);
          const i = s(8216);
          t.MessageStringComponent = class {
            constructor(e, t, s, i, o, r = !0) {
              (this.En = e),
                (this.kl = t),
                (this.yl = s),
                (this.As = i),
                (this.ni = o),
                (this.Ml = r);
            }
            render(e) {
              const t = this.ni,
                s = this.As,
                o = s.icons,
                r = "message",
                a = t.createDiv([`${r}-content`]),
                n =
                  this.yl === i.MESSAGE_SIDE.LEFT ? o.avatarBot : o.avatarUser;
              if (e) {
                t.addCSSClass(a, `${r}-with-icon`);
                const s = t.createImageIcon({ icon: e }),
                  i = t.createDiv([`${r}-icon`]);
                i.appendChild(s), a.appendChild(i);
              }
              const c = t.createDiv([`${r}-text`]),
                l = t.createTextDiv([`${r}-title`]),
                h = t.createTextDiv([`${r}-description`]);
              return (
                (l.innerText = this.En),
                (h.innerText = this.kl),
                c.appendChild(l),
                c.appendChild(h),
                a.appendChild(c),
                s.searchBarMode
                  ? t.getMessage(a, this.Ml)
                  : t.getMessageBlock(this.yl, a, n, this.Ml)
              );
            }
          };
        },
        8216: function (e, t, s) {
          var i =
              (this && this.t) ||
              (Object.create
                ? function (e, t, s, i) {
                    void 0 === i && (i = s);
                    var o = Object.getOwnPropertyDescriptor(t, s);
                    (o &&
                      !("get" in o ? !t.p : o.writable || o.configurable)) ||
                      (o = {
                        enumerable: !0,
                        get: function () {
                          return t[s];
                        },
                      }),
                      Object.defineProperty(e, i, o);
                  }
                : function (e, t, s, i) {
                    void 0 === i && (i = s), (e[i] = t[s]);
                  }),
            o =
              (this && this.u) ||
              function (e, t) {
                for (var s in e)
                  "default" === s ||
                    Object.prototype.hasOwnProperty.call(t, s) ||
                    i(t, e, s);
              };
          Object.defineProperty(t, "p", { value: !0 }),
            o(s(7989), t),
            o(s(3457), t);
        },
        7989: (e, t, s) => {
          Object.defineProperty(t, "p", { value: !0 }),
            (t.getPostActions = function (e) {
              return e.filter((e) => {
                const t = e.getActionType();
                return (
                  t === i.ActionType.Postback ||
                  t === i.ActionType.Location ||
                  t === i.ActionType.SubmitForm
                );
              });
            });
          const i = s(6246);
        },
        3457: (e, t, s) => {
          Object.defineProperty(t, "p", { value: !0 }),
            (t.MESSAGE_SIDE = t.MessageComponent = void 0);
          const i = s(8098),
            o = s(9780),
            r = s(7989);
          t.MESSAGE_SIDE = { LEFT: "left", RIGHT: "right" };
          function a(e, t, s, o) {
            const r = s.createDiv(["message-bubble", t]),
              a = s.createTextDiv();
            return (
              (a.innerHTML = (0, i.linkify)(e, s.cssPrefix, o)),
              r.appendChild(a),
              r
            );
          }
          function n(e, t, s) {
            const i = s.createTextDiv(t);
            return (
              e.forEach((e) => {
                i.appendChild(e.render());
              }),
              i
            );
          }
          t.MessageComponent = class {
            constructor(e, t, s, o, a, n) {
              (this.settings = e),
                (this.util = t),
                (this.payload = s),
                (this.side = o),
                (this.source = a),
                (this.options = n),
                (this.actions = []),
                (this.globalActions = []),
                (this.wl = []),
                (this.locale = e.locale),
                (this.translations = e.i18n[this.locale]),
                (this.shareText = (0, i.getShareText)(s)),
                n &&
                  n.locale &&
                  ((this.locale = n.locale),
                  (this.translations = Object.assign(
                    Object.assign({}, this.translations),
                    this.settings.i18n[n.locale]
                  ))),
                s.actions &&
                  (this.actions = this.buildActions(s.actions, this.shareText)),
                s.globalActions &&
                  (this.globalActions = this.buildActions(
                    s.globalActions,
                    this.shareText
                  )),
                (this.headerText = s.headerText),
                (this.footerText = s.footerText),
                s.footerForm &&
                  (this.footerFormComponent = (0, i.getFooterFormComponent)(
                    t,
                    s.footerForm,
                    e,
                    Object.assign(Object.assign({}, n), {
                      shareText: this.shareText,
                    })
                  )),
                (this.wl = (0, r.getPostActions)(this.actions).concat(
                  (0, r.getPostActions)(this.globalActions)
                ));
            }
            handleOnActionClick(e) {
              if (this.onActionClick) {
                const t = e;
                (t.messageComponent = this), this.onActionClick(t);
              }
            }
            hasActions() {
              return this.actions.length > 0 || this.globalActions.length > 0;
            }
            focusFirstAction() {
              var e;
              null === (e = this.firstActionButton) ||
                void 0 === e ||
                e.focus();
            }
            disableActions() {
              this.actions.forEach((e) => {
                e.disable();
              }),
                this.globalActions.forEach((e) => {
                  e.disable();
                }),
                this.footerFormComponent &&
                  this.footerFormComponent.disableActions();
            }
            disablePostbacks() {
              this.wl.forEach((e) => {
                e.disable();
              }),
                this.footerFormComponent &&
                  this.footerFormComponent.disablePostbacks();
            }
            enableActions() {
              this.actions.forEach((e) => {
                e.enable();
              }),
                this.globalActions.forEach((e) => {
                  e.enable();
                }),
                this.footerFormComponent &&
                  this.footerFormComponent.enableActions();
            }
            enablePostbacks() {
              this.wl.forEach((e) => {
                e.enable();
              }),
                this.footerFormComponent &&
                  this.footerFormComponent.enablePostbacks();
            }
            render(e) {
              const t = this,
                s = t.util,
                i = t.actions,
                r = t.globalActions,
                a = this.payload.embeddedActions,
                n = "embeddedAction";
              this.element && (this.element.innerHTML = "");
              const c = this.element ? this.element : s.createDiv(["message"]);
              c.lang = t.locale;
              const l = s.createDiv(["message-wrapper"]);
              c.appendChild(l);
              const h = t.getContent(e);
              if (
                (t.headerText && l.appendChild(t.getHeader()),
                l.appendChild(h),
                i && i.length)
              ) {
                const e = t.getActions();
                (this.settings.displayActionsAsPills ? l : h).appendChild(e),
                  t.firstActionButton ||
                    (t.firstActionButton = e.firstElementChild),
                  (this.actionsWrapper = e);
              }
              if (
                (t.footerText && l.appendChild(t.getFooter()),
                this.footerFormComponent)
              ) {
                const e = s.createDiv(["footer-form"]);
                e.appendChild(this.footerFormComponent.render()),
                  l.appendChild(e);
              }
              if (r && r.length) {
                const e = t.getGlobalActions();
                c.appendChild(e),
                  t.firstActionButton ||
                    (t.firstActionButton = e.firstElementChild);
              }
              return (
                (this.element = c),
                c.querySelectorAll(`span.${n}`).forEach((e) => {
                  const t = e,
                    i = a.find((t) => t.id === e.id);
                  if (i) {
                    s.addCSSClass(e, n, `display-${i.displayType}`);
                    const r = o.ActionComponentFactory.fromActionPayload(
                      i,
                      s,
                      this.settings,
                      this.shareText,
                      this.options
                    );
                    r &&
                      ((r.onActionClick = this.handleOnActionClick.bind(this)),
                      r.render(),
                      (t.onclick = (e) => r.handleOnClick(e)));
                  }
                }),
                c
              );
            }
            getHeader() {
              return a(
                this.headerText,
                "message-header",
                this.util,
                this.settings.embeddedVideo
              );
            }
            getContent(e) {
              const t = this.util.createDiv(["message-bubble"]);
              return (
                (t.style.padding =
                  this.settings.messagePadding || t.style.padding),
                e && t.appendChild(e),
                t
              );
            }
            getActions() {
              const e = this.settings,
                t = e.displayActionsAsPills
                  ? ["message-global-actions"]
                  : ["message-actions"];
              return (
                "horizontal" !== e.actionsLayout && t.push("col"),
                n(this.actions, t, this.util)
              );
            }
            getFooter() {
              return a(
                this.footerText,
                "message-footer",
                this.util,
                this.settings.embeddedVideo
              );
            }
            getGlobalActions() {
              const e = ["message-global-actions"];
              return (
                this.settings.icons.avatarBot && e.push("has-message-icon"),
                "horizontal" !== this.settings.globalActionsLayout &&
                  e.push("col"),
                n(this.globalActions, e, this.util)
              );
            }
            buildActions(e, t) {
              const s = this.settings;
              return (function (e, t, s, i, r, a) {
                const n = [];
                return (
                  e.forEach((e) => {
                    const c = o.ActionComponentFactory.fromActionPayload(
                      e,
                      t,
                      s,
                      i,
                      r
                    );
                    c && ((c.onActionClick = a), n.push(c));
                  }),
                  n
                );
              })(
                e,
                this.util,
                s,
                t,
                this.options,
                this.handleOnActionClick.bind(this)
              );
            }
          };
        },
        4266: (e, t, s) => {
          Object.defineProperty(t, "p", { value: !0 }),
            (t.RawMessageComponent = void 0);
          const i = s(8216);
          class o extends i.MessageComponent {
            constructor(e, t, s, i, o, r) {
              super(e, t, s, i, o, r), (this.Ar = JSON.stringify(s.payload));
            }
            getContent() {
              const e = this.util.createTextSpan();
              return (e.innerText = this.Ar), super.getContent(e);
            }
          }
          t.RawMessageComponent = o;
        },
        2971: (e, t, s) => {
          Object.defineProperty(t, "p", { value: !0 }),
            (t.RelativeTimestampComponent = void 0);
          const i = s(6246),
            o = window.setTimeout,
            r = window.setInterval,
            a = 36e5,
            n = 864e5,
            c = 30 * n,
            l = 365 * n,
            h = "relTimeNow",
            d = "relTimeMoment";
          t.RelativeTimestampComponent = class {
            constructor(e, t) {
              (this.ni = t),
                (this.Rs = Object.assign(
                  Object.assign({}, e.i18n.en),
                  e.i18n[e.locale]
                ));
              const s = e.icons,
                i = e.name,
                o = "-has-message-icon";
              (this.zt = i),
                (this.jl = `${i}-left ${s.avatarBot ? `${i}${o}` : ""}`),
                (this.zl = `${i}-right ${s.avatarUser ? `${i}${o}` : ""}`);
            }
            render() {
              const e = this.ni;
              let t = this.Dt;
              return (
                t
                  ? (t.setAttribute("aria-live", "off"),
                    t.setAttribute("aria-hidden", "true"))
                  : (t = e.createTextDiv()),
                (t.className = `${this.zt}-relative-timestamp ${this.$l}`),
                (this.Dt = t),
                t
              );
            }
            setLocale(e) {
              if (((this.Rs = e), this.Il))
                switch (this.Il) {
                  case h:
                  case d:
                    this.Cl(e[this.Il]);
                    break;
                  default:
                    this.Cl(e[this.Il].replace("{0}", `${this.Sl}`));
                }
            }
            setRelativeTime(e) {
              const t = new Date().getTime() - e.getTime(),
                s = Math.floor(t / 1e3),
                i = Math.floor(s / 60),
                o = Math.floor(i / 60),
                r = Math.floor(o / 24),
                a = Math.floor(r / 30),
                n = Math.floor(a / 12);
              n > 0
                ? this.Tl(n)
                : a > 0
                ? this.Al(a)
                : r > 0
                ? this.El(r)
                : o > 0
                ? this.Pl(o)
                : i > 0
                ? this.Ll(i)
                : this.Fl(s);
            }
            refresh(e) {
              (this.$l = e === i.SenderType.Skill ? this.jl : this.zl),
                (this.Dt.className = `${this.zt}-relative-timestamp ${this.$l}`),
                this.Nl();
            }
            remove() {
              var e;
              (null === (e = this.Dt) || void 0 === e
                ? void 0
                : e.parentElement) && this.Dt.remove();
            }
            Nl() {
              this.Rl(h, 1e4, this.Fl.bind(this));
            }
            Fl(e = 10) {
              (e *= 1e3), this.Rl(d, 6e4 - e, this.Ll.bind(this));
            }
            Ll(e = 1) {
              this.Dl("relTimeMin", 6e4, 60, this.Pl.bind(this), e);
            }
            Pl(e = 1) {
              this.Dl("relTimeHr", a, 24, this.El.bind(this), e);
            }
            El(e = 1) {
              this.Dl("relTimeDay", n, 30, this.Al.bind(this), e);
            }
            Al(e = 1) {
              this.Dl("relTimeMon", c, 12, this.Tl.bind(this), e);
            }
            Tl(e = 1) {
              this.Dl("relTimeYr", l, 60, () => {}, e);
            }
            Rl(e, t, s) {
              this.Hl(),
                this.Cl(this.Rs[e]),
                (this.Il = e),
                (this.Ul = o(() => {
                  s();
                }, t));
            }
            Dl(e, t, s, i, o = 1) {
              this.Hl(),
                this.Cl(this.Rs[e].replace("{0}", `${o}`)),
                (this.Il = e),
                (this.Sl = o),
                (this.Ul = r(() => {
                  o++,
                    (this.Sl = o),
                    o > s
                      ? (clearInterval(this.Ul), i())
                      : this.Cl(this.Rs[e].replace("{0}", `${o}`));
                }, t));
            }
            Cl(e) {
              this.Dt || this.render(), (this.Dt.innerText = e);
            }
            Hl() {
              clearTimeout(this.Ul), clearInterval(this.Ul);
            }
          };
        },
        8766: function (e, t, s) {
          var i =
              (this && this.t) ||
              (Object.create
                ? function (e, t, s, i) {
                    void 0 === i && (i = s);
                    var o = Object.getOwnPropertyDescriptor(t, s);
                    (o &&
                      !("get" in o ? !t.p : o.writable || o.configurable)) ||
                      (o = {
                        enumerable: !0,
                        get: function () {
                          return t[s];
                        },
                      }),
                      Object.defineProperty(e, i, o);
                  }
                : function (e, t, s, i) {
                    void 0 === i && (i = s), (e[i] = t[s]);
                  }),
            o =
              (this && this.u) ||
              function (e, t) {
                for (var s in e)
                  "default" === s ||
                    Object.prototype.hasOwnProperty.call(t, s) ||
                    i(t, e, s);
              };
          Object.defineProperty(t, "p", { value: !0 }), o(s(4783), t);
        },
        4783: (e, t) => {
          Object.defineProperty(t, "p", { value: !0 }),
            (t.StatusComponent = void 0);
          t.StatusComponent = class {
            constructor(e, t, s) {
              const i = "status-message",
                o = e.createDiv([`${i}-container`]);
              o.setAttribute("role", "alert");
              const r = e.createDiv([`${i}-wrapper`]);
              if (s) {
                const t = e.createImage(s, ["status-image"], "");
                r.appendChild(t);
              }
              const a = e.createTextDiv([i]);
              (a.textContent = t),
                r.appendChild(a),
                o.appendChild(r),
                (this.Dt = o);
            }
            remove() {
              this.Dt.remove();
            }
            render() {
              return this.Dt;
            }
          };
        },
        8145: (e, t, s) => {
          Object.defineProperty(t, "p", { value: !0 }),
            (t.FeedbackComponent = void 0);
          const i = s(8098),
            o = s(2467);
          class r extends o.TextMessageComponent {
            constructor(e, t, s, i, o, r) {
              super(e, t, s, i, o, r),
                (this.Vl = 0),
                (this.Bl = s.actions),
                (this.ratingId = Date.now());
            }
            focusFirstAction() {
              this.Wl[0].focus();
            }
            disableActions() {
              this.Zl(!0), super.disableActions();
            }
            disablePostbacks() {
              this.Zl(!0), super.disablePostbacks();
            }
            enableActions() {
              this.Zl(!1), super.enableActions();
            }
            enablePostbacks() {
              this.Zl(!1), super.enablePostbacks();
            }
            highlightRating(e) {
              if (!this.actions || !this.Wl) return;
              const t = this.util,
                s = "active",
                i = "string" == typeof e ? this.Gl(e) : e;
              for (let e = 1; e <= this.Wl.length; e++) {
                const o = this.Wl[e - 1];
                if (!o) break;
                (i && e <= i) || (0 === i && e <= this.Vl)
                  ? t.addCSSClass(o, s)
                  : t.removeCSSClass(o, s);
              }
            }
            getActions() {
              const e = this.util,
                t = this.settings,
                s = t.i18n[t.locale].ratingStar,
                o = e.createDiv(["rating-wrapper"]);
              (this.Wl = this.Bl.map((r) => {
                const a = e.createElement("input", [
                  "star-input",
                  "rating-hidden",
                ]);
                (a.id = `rating-${r.label}-${this.ratingId}`),
                  (a.type = "radio"),
                  (a.name = `rating-${this.ratingId}`),
                  (a.value = r.label);
                const n = e.createLabel(["star-label"]);
                (n.htmlFor = `rating-${r.label}-${this.ratingId}`),
                  n.setAttribute("data-rating", r.label);
                const c = e.createTextSpan(["rating-hidden"]),
                  l = s.replace("{0}", `${r.label}`);
                c.innerText = l;
                const h = (t.icons && t.icons.rating) || i.iconRating,
                  d = e.createImageIcon({
                    icon: h,
                    iconCss: ["rating-star-icon"],
                  });
                return (
                  n.appendChild(c),
                  n.appendChild(d),
                  (a.onfocus = () => {
                    a.disabled || (this.Vl = this.ql(a));
                  }),
                  (a.onkeydown = (e) => {
                    "Enter" === e.key && this.Yl(r);
                  }),
                  (n.onclick = () => {
                    a.disabled || ((this.Vl = this.ql(n)), this.Yl(r));
                  }),
                  (n.onmouseover = () => {
                    a.disabled || this.ql(n);
                  }),
                  (n.onmouseleave = () => {
                    a.disabled || this.ql(null);
                  }),
                  o.appendChild(a),
                  o.appendChild(n),
                  a
                );
              })),
                this.Vl && this.ql(null);
              const r = e.createDiv(["rating-root"]);
              return r.appendChild(o), r;
            }
            Zl(e) {
              this.Wl &&
                this.Wl.forEach((t) => {
                  t.disabled = e;
                });
            }
            Yl(e) {
              const t = {
                getPayload: () => Promise.resolve(e.postback),
                label: e.label,
                type: e.type,
              };
              this.handleOnActionClick(t);
            }
            ql(e) {
              let t = 0;
              if (e) {
                const s =
                  "value" in e
                    ? e.value
                    : null == e
                    ? void 0
                    : e.getAttribute("data-rating");
                t = s ? parseInt(s, 10) : 0;
              }
              return this.highlightRating(t), t;
            }
            Gl(e) {
              let t = 0;
              if (e.match(/^\d+$/)) {
                const s = parseInt(e, 10);
                s > 0 && s <= this.actions.length && (t = s);
              }
              return t;
            }
          }
          t.FeedbackComponent = r;
        },
        2467: (e, t, s) => {
          Object.defineProperty(t, "p", { value: !0 }),
            (t.TextMessageComponent = void 0);
          const i = s(6246),
            o = s(8098),
            r = s(8216);
          class a extends r.MessageComponent {
            constructor(e, t, s, i, o, r) {
              super(e, t, s, i, o, r), (this.kl = s.text);
            }
            getContent() {
              const e = this.settings,
                t = this.util,
                s = this.kl,
                a = t.createTextDiv(["message-text"]);
              return (
                this.side === r.MESSAGE_SIDE.RIGHT
                  ? (0, i.isPostbackPayload)(this.payload) &&
                    (n(s) || (0, o.isSVG)(s))
                    ? (t.addCSSClass(a, "message-user-postback"),
                      (a.innerHTML = s))
                    : (a.textContent = c(s))
                  : ((a.innerHTML = (0, o.linkify)(
                      s,
                      t.cssPrefix,
                      e.embeddedVideo
                    )),
                    e.linkHandler
                      ? (0, o.setEmbeddedLinksHandler)(a, e.linkHandler)
                      : e.openLinksInNewWindow &&
                        (0, o.setLinksOpenInNewWindow)(a)),
                super.getContent(a)
              );
            }
          }
          t.TextMessageComponent = a;
          const n = (e) => !!e && /^<img\s+/i.test(e),
            c = (e) =>
              e.replace(/&#x([0-9a-f]+);/gi, (e, t) =>
                String.fromCharCode(parseInt(t, 16))
              );
        },
        402: (e, t, s) => {
          Object.defineProperty(t, "p", { value: !0 }),
            (t.TextStreamMessageComponent = void 0);
          const i = s(8098),
            o = s(8216),
            r = "start",
            a = "end";
          class n extends o.MessageComponent {
            constructor(e, t, s, o, r, n) {
              var l;
              super(e, t, s, o, r, n),
                (this.Jl = ""),
                (this.Kl = !0),
                (this.Xl = s.streamState),
                (this.kl = s.text),
                (this.Jl = s.text),
                (this.Kl =
                  null !== (l = n.isFresh) && void 0 !== l ? l : this.Kl);
              let h = "";
              this.Ql = c(
                (s) => {
                  h += s;
                  const o =
                      h.length % 20
                        ? h
                        : (0, i.linkify)(h, t.cssPrefix, e.embeddedVideo),
                    r = (0, i.convertBreakTagsToNewLines)(o);
                  this.textElement &&
                    (this.textElement instanceof HTMLInputElement ||
                    this.textElement instanceof HTMLTextAreaElement
                      ? (this.textElement.focus(),
                        (this.textElement.value = r),
                        this.textElement instanceof HTMLTextAreaElement &&
                          (this.textElement.scrollTop =
                            this.textElement.scrollHeight))
                      : (this.textElement.innerHTML = r));
                },
                () => {
                  var e;
                  this.Xl === a &&
                    (this.isCoPilot
                      ? this.showDone()
                      : ((this.kl =
                          null === (e = this.textElement) || void 0 === e
                            ? void 0
                            : e.innerHTML),
                        this.render()));
                },
                e.typingDelay || 1
              );
            }
            update(e) {
              const t = e.streamState;
              switch (((this.Xl = t), t)) {
                case r:
                  this.renderClean(e),
                    this.isCoPilot && this.Ql.push(e.text.split(""));
                  break;
                case "running":
                  this.Ql.push(e.text.split("")), (this.Jl = e.text);
                  break;
                case a:
                  if (this.Kl) {
                    const t = this.Jl;
                    if (((this.Jl = ""), t.length)) {
                      const s = e.text.lastIndexOf(t);
                      if (s >= 0) {
                        const i = e.text.substring(s + t.length);
                        this.Ql.push(i.split("")),
                          this.isCoPilot || this.setAddOnComponents(e);
                        break;
                      }
                    }
                  }
                  this.renderClean(e);
              }
            }
            freeze() {
              return (
                this.Ql.clear(), (this.Jl = ""), this.textElement.innerHTML
              );
            }
            getContent() {
              var e;
              const t = this.settings,
                s = this.util,
                o = s.createTextDiv();
              return (
                o.setAttribute("aria-hidden", "true"),
                !this.Kl || (this.Xl !== r && this.textElement)
                  ? ((o.innerHTML = (0, i.linkify)(
                      this.kl,
                      s.cssPrefix,
                      t.embeddedVideo
                    )),
                    this.Xl === a && o.removeAttribute("aria-hidden"),
                    t.linkHandler
                      ? (0, i.setEmbeddedLinksHandler)(o, t.linkHandler)
                      : t.openLinksInNewWindow &&
                        (0, i.setLinksOpenInNewWindow)(o))
                  : ((this.textElement = o),
                    this.Ql.push(
                      null === (e = this.kl) || void 0 === e
                        ? void 0
                        : e.split("")
                    )),
                super.getContent(o)
              );
            }
            renderClean(e) {
              this.Ql.clear(),
                (this.kl = e.text),
                this.isCoPilot || (this.setAddOnComponents(e), this.render());
            }
            setAddOnComponents(e) {
              (this.headerText = e.headerText),
                e.actions && (this.actions = this.buildActions(e.actions)),
                (this.footerText = e.footerText),
                e.footerForm &&
                  (this.footerFormComponent = (0, i.getFooterFormComponent)(
                    this.util,
                    e.footerForm,
                    this.settings,
                    Object.assign(Object.assign({}, this.options), {
                      shareText: this.shareText,
                    })
                  )),
                e.globalActions &&
                  (this.globalActions = this.buildActions(e.globalActions)),
                (this.wl = (0, o.getPostActions)(this.actions).concat(
                  (0, o.getPostActions)(this.globalActions)
                ));
            }
          }
          t.TextStreamMessageComponent = n;
          const c = (e, t, s) => {
            const i = [];
            let o = !0;
            const r = () => {
              if (!i.length) return (o = !0), void setTimeout(() => t());
              setTimeout(() => {
                i.length && (e(i.shift()), r());
              }, s);
            };
            return {
              push: (e) => {
                i.push(...e), o && ((o = !1), r());
              },
              clear: () => {
                i.length = 0;
              },
            };
          };
        },
        5793: (e, t, s) => {
          Object.defineProperty(t, "p", { value: !0 }),
            (t.TypingIndicatorComponent = void 0);
          const i = s(4557);
          class o extends i.Component {
            constructor(e, t, s) {
              super(),
                (this.yl = e),
                (this.As = t),
                (this.ni = s),
                (this.element = this.render()),
                (this.eh = !1),
                (this.th = !0);
            }
            append(e) {
              !this.isVisible() &&
                e &&
                (e.appendChild(this.element),
                (this.eh = !0),
                this.sh && clearTimeout(this.sh),
                this.th &&
                  (this.sh = window.setTimeout(() => {
                    this.remove();
                  }, 1e3 * this.As.typingIndicatorTimeout)));
            }
            remove() {
              this.isVisible() && (this.element.remove(), (this.eh = !1));
            }
            isVisible() {
              return this.eh;
            }
            render() {
              const e = this.ni,
                t = this.As,
                s = e.createDiv(["typing-cue-wrapper"]),
                i = t.icons.avatarBot;
              if (t.icons.typingIndicator) {
                const i = t.icons.typingIndicator,
                  o = e.createImageIcon({ icon: i });
                (o.style.height = t.chatBubbleIconHeight || o.style.height),
                  (o.style.width = t.chatBubbleIconWidth || o.style.width),
                  s.appendChild(o);
              } else {
                const t = e.createDiv(["typing-cue"]);
                s.appendChild(t);
              }
              return (
                s.setAttribute("aria-live", "polite"),
                (this.pl = s),
                this.updateTypingCueLocale(t.i18n[t.locale].typingIndicator),
                t.searchBarMode
                  ? e.getMessage(s)
                  : e.getMessageBlock(this.yl, s, i)
              );
            }
            updateTypingCueLocale(e) {
              this.pl.setAttribute("aria-label", e);
            }
            resetTypingCueIcon() {
              this.element.remove(), (this.element = this.render());
            }
            updateTypingCueIcon(e) {
              (e.style.marginTop = "0px"),
                this.element.firstChild.replaceWith(e);
            }
            setAutoTimeout(e) {
              this.th = e;
            }
          }
          t.TypingIndicatorComponent = o;
        },
        2854: function (e, t, s) {
          var i =
              (this && this.t) ||
              (Object.create
                ? function (e, t, s, i) {
                    void 0 === i && (i = s);
                    var o = Object.getOwnPropertyDescriptor(t, s);
                    (o &&
                      !("get" in o ? !t.p : o.writable || o.configurable)) ||
                      (o = {
                        enumerable: !0,
                        get: function () {
                          return t[s];
                        },
                      }),
                      Object.defineProperty(e, i, o);
                  }
                : function (e, t, s, i) {
                    void 0 === i && (i = s), (e[i] = t[s]);
                  }),
            o =
              (this && this.u) ||
              function (e, t) {
                for (var s in e)
                  "default" === s ||
                    Object.prototype.hasOwnProperty.call(t, s) ||
                    i(t, e, s);
              };
          Object.defineProperty(t, "p", { value: !0 }), o(s(1456), t);
        },
        1456: (e, t, s) => {
          Object.defineProperty(t, "p", { value: !0 }),
            (t.WebViewComponent = void 0);
          const i = s(6064),
            o = s(8098),
            r = s(5915),
            a = [
              "no-referrer",
              "no-referrer-when-downgrade",
              "origin",
              "origin-when-cross-origin",
              "same-origin",
              "strict-origin",
              "strict-origin-when-cross-origin",
              "unsafe-url",
            ],
            n = [
              "allow-downloads-without-user-activation",
              "allow-downloads",
              "allow-forms",
              "allow-modals",
              "allow-orientation-lock",
              "allow-pointer-lock",
              "allow-popups",
              "allow-popups-to-escape-sandbox",
              "allow-presentation",
              "allow-same-origin",
              "allow-scripts",
              "allow-storage-access-by-user-activation",
              "allow-top-navigation",
              "allow-top-navigation-by-user-activation",
            ],
            c = "none",
            l = "webview-container",
            h = `${l}-open`,
            d = `${l}-close`;
          t.WebViewComponent = class {
            constructor(e, t, s) {
              (this.ni = t),
                (this.As = s),
                (this.ih = 0.8),
                (this.qt = {
                  closeButtonIcon: o.iconClose,
                  closeButtonType: "icon",
                  errorInfoBar: !0,
                  referrerPolicy: "no-referrer-when-downgrade",
                  sandbox: [],
                  size: "tall",
                }),
                (this.oh = !1),
                (this.rh = !1),
                this.setProps(e || {}),
                (this.zt = s.name);
            }
            setProps(e) {
              Array.isArray(e.sandbox) &&
                e.sandbox.length &&
                (e.sandbox = e.sandbox
                  .map((e) => e.toLowerCase())
                  .filter((e) => n.indexOf(e) >= 0));
              const t = Object.assign(Object.assign({}, this.qt), e);
              var s;
              t.closeButtonIcon ||
                (t.closeButtonIcon = this.qt.closeButtonIcon),
                t.closeButtonType || (t.closeButtonType = "icon"),
                t.size || (t.size = "tall"),
                (s = t.referrerPolicy),
                a.indexOf(null == s ? void 0 : s.toLowerCase()) >= 0 ||
                  (t.referrerPolicy = "no-referrer-when-downgrade"),
                "full" === t.size && (this.ih = 1),
                (this.qt = t),
                (this.oh = !1),
                (this.rh = !1);
            }
            open(e) {
              if (this.Qn) {
                const t = this.ni,
                  s = 100;
                (this.Qn.style.height = s * this.ih + "%"),
                  t.removeCSSClass(this.Qn, d, c),
                  t.addCSSClass(this.Qn, h),
                  this.Qn.insertBefore(this.ah, this.nh),
                  (this.nh.onload = () => {
                    this.ah.remove(), t.removeCSSClass(this.nh, c);
                  }),
                  this.qt.title || (this.En.textContent = e),
                  this.qt.errorInfoBar &&
                    setTimeout(() => {
                      this.oh &&
                        !this.rh &&
                        ((this.dh = this.ph()),
                        e && (this.uh.href = e),
                        t.removeCSSClass(this.dh, c),
                        this.Qn.appendChild(this.dh),
                        (this.rh = !0));
                    }, 1e3),
                  (this.oh = !0);
              }
            }
            close() {
              const e = this.ni;
              (this.oh = !1),
                e.removeCSSClass(this.Qn, h),
                e.addCSSClass(this.Qn, d),
                this.gh(),
                this.nh.setAttribute("src", ""),
                setTimeout(() => {
                  e.addCSSClass(this.Qn, c), e.removeCSSClass(this.nh, c);
                }, 400);
            }
            render() {
              const e = this.ni,
                t = this.qt;
              return (
                (this.Qn = e.createDiv(["webview-container"])),
                (this.Ti = e.createDiv(["header", "webview-header", "flex"])),
                (this.En = e.createTextDiv([
                  "title",
                  "webview-title",
                  "ellipsis",
                ])),
                (this.mh = e.createIconButton({
                  css: ["header-button", "webview-button-close"],
                  icon: t.closeButtonIcon,
                  iconCss: [],
                  title: t.closeButtonLabel,
                })),
                (this.mh.id = `${this.zt}-webview-button-close`),
                (this.ah = this.bh()),
                (this.nh = e.createElement("iframe", ["webview"])),
                (this.nh.name = `${this.As.name}-webview`),
                (this.nh.title = t.accessibilityTitle),
                t.title && (this.En.textContent = t.title),
                "label" === t.closeButtonType
                  ? (this.mh.classList.add(`${this.zt}-label-only`),
                    this.mh.appendChild(
                      document.createTextNode(t.closeButtonLabel)
                    ))
                  : "iconWithLabel" === t.closeButtonType &&
                    (this.mh.classList.add(`${this.zt}-with-label`),
                    this.mh.appendChild(
                      document.createTextNode(t.closeButtonLabel)
                    )),
                this.nh.setAttribute("referrerpolicy", t.referrerPolicy),
                this.qt.sandbox.length &&
                  this.qt.sandbox.forEach((e) => {
                    this.nh.sandbox.add(e);
                  }),
                e.addCSSClass(this.Qn, c),
                (this.mh.onclick = () => {
                  this.close();
                }),
                this.Ti.appendChild(this.En),
                this.Ti.appendChild(this.mh),
                this.Qn.appendChild(this.Ti),
                this.Qn.appendChild(this.nh),
                this.Qn
              );
            }
            bh() {
              return new r.SpinnerComponent(this.ni).render();
            }
            ph() {
              const e = this.ni,
                t = e.createDiv(["webview-error", "flex"]);
              (this.fh = e.createDiv(["webview-error-text"])),
                t.appendChild(this.fh),
                this.wh(this.qt.errorInfoText);
              const s = e.createIconButton({
                css: ["webview-error-button-close"],
                icon: this.qt.closeButtonIcon,
                iconCss: [],
                title: this.qt.errorInfoDismissLabel,
              });
              return (s.onclick = this.gh.bind(this)), t.appendChild(s), t;
            }
            wh(e) {
              var t;
              const s = this.ni,
                r = (0, o.sanitizeText)(e);
              let a;
              const n = /\{0\}(.*)\{\/0\}/g,
                c = null === (t = n.exec(r)) || void 0 === t ? void 0 : t[1];
              if (c) {
                const e = s.createAnchor("", c, ["webview-alt-link"]);
                a = r.replace((0, i.resetRegex)(n), e.outerHTML);
              } else a = s.createAnchor("", r, ["webview-alt-link"]).outerHTML;
              (this.fh.innerHTML = a), (this.uh = this.fh.querySelector("a"));
            }
            gh() {
              const e = this.ni;
              this.rh &&
                (e.addCSSClass(this.dh, c),
                setTimeout(() => {
                  this.Qn.removeChild(this.dh), (this.rh = !1);
                }, 600));
            }
          };
        },
        5398: (e, t, s) => {
          t.l =
            t.k =
            t.j =
            t.i =
            t.h =
            t.g =
            t.f =
            t.e =
            t.d =
            t.c =
            t.b =
            t.a =
              void 0;
          const i = s(8098);
          Object.defineProperty(t, "a", {
            enumerable: !0,
            get: function () {
              return i.ChatEvent;
            },
          }),
            Object.defineProperty(t, "c", {
              enumerable: !0,
              get: function () {
                return i.DOMUtil;
              },
            }),
            Object.defineProperty(t, "e", {
              enumerable: !0,
              get: function () {
                return i.SDK_VERSION;
              },
            }),
            Object.defineProperty(t, "i", {
              enumerable: !0,
              get: function () {
                return i.addDefaultSettings;
              },
            }),
            Object.defineProperty(t, "j", {
              enumerable: !0,
              get: function () {
                return i.getFieldInputValues;
              },
            }),
            Object.defineProperty(t, "k", {
              enumerable: !0,
              get: function () {
                return i.isAnyVoiceAvailable;
              },
            }),
            Object.defineProperty(t, "l", {
              enumerable: !0,
              get: function () {
                return i.syncTTSLocaleIfUnavailable;
              },
            });
          const o = s(5430);
          Object.defineProperty(t, "b", {
            enumerable: !0,
            get: function () {
              return o.ContextualWidgetComponent;
            },
          }),
            Object.defineProperty(t, "d", {
              enumerable: !0,
              get: function () {
                return o.Logger;
              },
            }),
            Object.defineProperty(t, "f", {
              enumerable: !0,
              get: function () {
                return o.StorageType;
              },
            }),
            Object.defineProperty(t, "g", {
              enumerable: !0,
              get: function () {
                return o.WidgetComponent;
              },
            }),
            Object.defineProperty(t, "h", {
              enumerable: !0,
              get: function () {
                return o.WidgetTheme;
              },
            });
        },
        5229: (e, t) => {
          Object.defineProperty(t, "p", { value: !0 }),
            (t.redwoodStyles = void 0);
          t.redwoodStyles =
            '@keyframes scale-in-center{0%{opacity:1;transform:scale(0)}100%{opacity:1;transform:scale(1)}}@keyframes scale-out-center{0%{display:flex;opacity:1;transform:scale(1)}100%{display:none;opacity:1;transform:scale(0)}}@keyframes scale-in-br{0%{opacity:1;transform:scale(0);transform-origin:100% 100%}100%{opacity:1;transform:scale(1);transform-origin:100% 100%}}@keyframes scale-in-bl{0%{opacity:1;transform:scale(0);transform-origin:0 100%}100%{opacity:1;transform:scale(1);transform-origin:0 100%}}@keyframes scale-in-tl{0%{opacity:1;transform:scale(0);transform-origin:0 0}100%{opacity:1;transform:scale(1);transform-origin:0 0}}@keyframes scale-in-tr{0%{opacity:1;transform:scale(0);transform-origin:100% 0}100%{opacity:1;transform:scale(1);transform-origin:100% 0}}@keyframes scale-out-br{0%{opacity:1;transform:scale(1);transform-origin:100% 100%}99%{opacity:1;transform:scale(0.01);transform-origin:100% 100%}100%{display:none;opacity:1;transform:scale(0);transform-origin:100% 100%}}@keyframes scale-out-bl{0%{opacity:1;transform:scale(1);transform-origin:0 100%}99%{opacity:1;transform:scale(0.01);transform-origin:0 100%}100%{display:none;opacity:1;transform:scale(0);transform-origin:0 100%}}@keyframes popup-suggestion{0%{box-shadow:0 0 0 0 rgba(0,0,0,0),0 0 0 0 rgba(0,0,0,0);transform:scaleY(0.4);transform-origin:0 100%}100%{box-shadow:0 -12px 15px -12px rgba(0,0,0,.35);transform:scaleY(1);transform-origin:0 100%}}@keyframes spin{from{transform:rotate(0)}to{transform:rotate(360deg)}}@keyframes dialog-in{0%{transform:translateY(-20px);opacity:0}100%{transform:translateY(0);opacity:1}}@keyframes dialog-out{0%{transform:translateY(0);opacity:1}100%{transform:translateY(-20px);opacity:0}}@keyframes typing-cue{0%{opacity:1}30%{opacity:.1}50%{opacity:1}100%{opacity:.1}}@keyframes oda-chat-webview-slide-out-bottom{0%{transform:translateY(0);opacity:1}95%{opacity:1}100%{transform:translateY(100%);opacity:0}}@keyframes oda-chat-webview-slide-in-bottom{0%{transform:translateY(100%);opacity:0}1%{opacity:1}100%{transform:translateY(0%);opacity:1}}@keyframes cancel-button-entrance{0%{transform:translateZ(-64px);opacity:0}100%{transform:translateZ(0);opacity:1}}@keyframes cancel-button-exit{0%{transform:translateZ(0);opacity:1}100%{transform:translateZ(-64px);opacity:0}}.flex{display:flex;justify-content:space-between;align-items:center}.col{flex-direction:column}.none{display:none !important}.wrapper{--color-branding: #c0533f;--color-branding-light: #ca4d3c;--color-branding-dark: #9b382a;--color-launch-icon-background: #c0533f;--color-text: #161513;--color-text-light: #161513;--color-header-background: #F1EFED;--color-header-button-fill: #161513;--color-header-text: #161513;--color-header-button-background-hover: rgba(22, 21, 19, 0.04);--color-header-button-fill-hover: #161513;--color-conversation-background: #F5F4F2;--color-timestamp: rgba(22, 21, 19, 0.65);--color-typing-indicator: #161513;--color-agent-initials: #FFFFFF;--color-agent-avatar-background: #A890B6;--color-agent-name: rgba(22, 21, 19, 0.65);--color-bot-message-background: #FFFFFF;--color-bot-text: #161513;--color-user-message-background: #E4E1DD;--color-user-text: #161513;--color-error-message-background: #FFF8F7;--color-error-border: #DC5C5E;--color-error-title: #D63B25;--color-error-text: #161513;--color-card-background: #FFFFFF;--color-card-nav-button: #FFF;--color-card-nav-button-focus: #FBF9F8;--color-card-nav-button-hover: #FBF9F8;--color-actions-background: #fff;--color-actions-background-focus: #fff;--color-actions-background-hover: rgba(22, 21, 19, 0.04);--color-actions-border: rgba(22, 21, 19, 0.5);--color-actions-outline-focus: rgb(22, 21, 19);--color-actions-text: #161513;--color-actions-text-focus: #161513;--color-actions-text-hover: #161513;--color-global-actions-background: transparent;--color-global-actions-background-focus: transparent;--color-global-actions-background-hover: rgba(22, 21, 19, 0.04);--color-global-actions-border: rgba(22, 21, 19, 0.5);--color-global-actions-text: #161513;--color-global-actions-text-focus: #161513;--color-global-actions-text-hover: #161513;--color-primary-actions-background: rgb(49, 45, 42);--color-primary-actions-background-focus: rgb(49, 45, 42);--color-primary-actions-background-hover: rgb(49, 45, 42) linear-gradient(rgb(58, 54, 50), rgb(58, 54, 50));--color-primary-actions-border: transparent;--color-primary-actions-text: #fff;--color-primary-actions-text-focus: #fff;--color-primary-actions-text-hover: #fff;--color-danger-actions-background: rgb(214, 59, 37);--color-danger-actions-background-focus: rgb(214, 59, 37);--color-danger-actions-background-hover: rgb(214, 59, 37) linear-gradient(rgb(195, 53, 34), rgb(195, 53, 34));--color-danger-actions-border: transparent;--color-danger-actions-text: #fff;--color-danger-actions-text-focus: #fff;--color-danger-actions-text-hover: #fff;--color-links: #c0533f;--color-user-links: #c0533f;--color-rating-star: #ececec;--color-rating-star-fill: #f0cc71;--color-horizontal-rule-background: #cbc5bf;--color-attachment-placeholder: #e3e1dc;--color-attachment-footer: #fff;--color-attachment-text: #161513;--color-footer-form-label: rgba(22, 21, 19, 0.65);--color-footer-background: #fff;--color-footer-button-fill: #161513;--color-footer-button-background-hover: rgba(22, 21, 19, 0.04);--color-footer-button-fill-hover: #161513;--color-input-background: #fff;--color-input-border: #fff;--color-input-text: #161513;--color-recognition-view-text: #fff;--color-visualizer: #161513;--color-visualizer-container-background: #fff;--color-notification-badge-background: #312d2a;--color-notification-badge-text: #fff;--color-popup-background: #fff;--color-popup-text: #161513;--color-popup-button-background: #fff;--color-popup-button-text: #161513;--color-popup-horizontal-rule: #cbc5bf;--color-popup-item-background-hover: rgba(22, 21, 19, 0.04);--color-table-header-background: #f1efec;--color-table-header-text: #161513;--color-table-background: #fff;--color-table-text: #161513;--color-table-separator: rgba(22, 21, 19, 0.1);--color-table-row-background-hover: rgba(22, 21, 19, 0.04);--color-table-actions-background: transparent;--color-table-actions-background-focus: transparent;--color-table-actions-background-hover: rgba(22, 21, 19, 0.04);--color-table-actions-border: rgba(22, 21, 19, 0.5);--color-table-actions-text: #161513;--color-table-actions-text-focus: #161513;--color-table-actions-text-hover: #161513;--color-form-header-background: #f1efec;--color-form-header-text: #161513;--color-form-background: #fff;--color-form-text: #161513;--color-form-input-background: #fff;--color-form-input-border: rgba(22, 21, 19, 0.5);--color-form-input-border-focus: rgb(14, 114, 151);--color-form-input-text: #161513;--color-form-label: rgba(22, 21, 19, 0.65);--color-form-error: rgba(179, 49, 31);--color-form-error-text: rgba(22, 21, 19, 0.65);--color-form-actions-background: transparent;--color-form-actions-background-focus: transparent;--color-form-actions-background-hover: rgba(22, 21, 19, 0.04);--color-form-actions-border: rgba(22, 21, 19, 0.5);--color-form-actions-text: #161513;--color-form-actions-text-focus: #161513;--color-form-actions-text-hover: #161513;--color-primary-form-actions-background: rgb(49, 45, 42);--color-primary-form-actions-background-focus: rgb(49, 45, 42);--color-primary-form-actions-background-hover: rgb(49, 45, 42) linear-gradient(rgb(58, 54, 50), rgb(58, 54, 50));--color-primary-form-actions-border: transparent;--color-primary-form-actions-text: #fff;--color-primary-form-actions-text-focus: #fff;--color-primary-form-actions-text-hover: #fff;--color-danger-form-actions-background: rgb(214, 59, 37);--color-danger-form-actions-background-focus: rgb(214, 59, 37);--color-danger-form-actions-background-hover: rgb(214, 59, 37) linear-gradient(rgb(195, 53, 34), rgb(195, 53, 34));--color-danger-form-actions-border: transparent;--color-danger-form-actions-text: #fff;--color-danger-form-actions-text-focus: #fff;--color-danger-form-actions-text-hover: #fff;--bubble-max-width: 680px;--width-full-screen: 375px;--widget-max-height: calc(100vh - 60px);--position-top: 0;--position-left: 0;--position-right: 20px;--position-bottom: 20px;--font-family: "Oracle Sans", -apple-system, BlinkMacSystemFont, "Segoe UI", "Helvetica Neue", sans-serif;position:fixed;box-sizing:border-box;text-transform:none;z-index:10000;color:var(--color-text);font-size:13.75px;line-height:16px;font-family:var(--font-family);-webkit-font-smoothing:antialiased}.wrapper.classic{--color-branding: #025e7e;--color-branding-light: #0e7295;--color-branding-dark: #06485f;--color-launch-icon-background: #025e7e;--color-text: #161513;--color-text-light: #3a3631;--color-header-background: #025e7e;--color-header-button-fill: #fff;--color-header-button-fill-hover: #fff;--color-header-text: #fff;--color-conversation-background: #fff;--color-timestamp: #5b5652;--color-typing-indicator: #227e9e;--color-bot-message-background: #e5f1ff;--color-user-message-background: #ececec;--color-card-background: #e5f1ff;--color-card-nav-button: #4190ac;--color-card-nav-button-focus: #5fa2ba;--color-card-nav-button-hover: #0e7295;--color-actions-background: transparent;--color-actions-background-focus: transparent;--color-actions-background-hover: rgba(14, 114, 149, 0.04);--color-actions-border: rgb(14, 114, 149);--color-actions-text: rgb(14, 114, 149);--color-actions-text-focus: rgb(14, 114, 149);--color-actions-text-hover: rgb(14, 114, 149);--color-global-actions-background: #fff;--color-global-actions-background-focus: #fff;--color-global-actions-background-hover: rgba(14, 114, 149, 0.04);--color-global-actions-border: rgb(14, 114, 149);--color-global-actions-text: rgb(14, 114, 149);--color-global-actions-text-focus: rgb(14, 114, 149);--color-global-actions-text-hover: rgb(14, 114, 149);--color-primary-actions-background: rgb(14, 114, 149);--color-primary-actions-background-focus: rgb(14, 114, 149);--color-primary-actions-background-hover: rgba(14, 114, 149, 0.95);--color-links: #0e7295;--color-user-links: #0e7295;--color-agent-name: #5b5652;--color-attachment-footer: #e5f1ff;--color-footer-background: #fff;--color-footer-button-fill: #161513;--color-footer-button-fill-hover: #025e7e;--color-visualizer: #025e7e;--color-primary-form-actions-background: rgb(14, 114, 149);--color-primary-form-actions-background-focus: rgb(14, 114, 149);--color-primary-form-actions-background-hover: rgba(14, 114, 149, 0.95);--color-notification-badge-background: #9a0007;--color-notification-badge-text: #fff;--color-popup-button-text: #025e7e}.wrapper.redwood-dark{--color-branding: #c0533f;--color-branding-light: #ca4d3c;--color-branding-dark: #9b382a;--color-launch-icon-background: #c0533f;--color-text: #161513;--color-text-light: #fcfbfa;--color-header-background: #201e1c;--color-header-button-fill: #fff;--color-header-button-fill-hover: #fff;--color-header-button-background-hover: rgba(255, 255, 255, 0.04);--color-header-text: #fff;--color-conversation-background: #3a3631;--color-timestamp: #fcfbfa;--color-typing-indicator: #fff;--color-bot-message-background: #655f5c;--color-bot-text: #fff;--color-user-message-background: #fff;--color-user-text: #161513;--color-card-background: #655f5c;--color-card-nav-button: #d5b364;--color-card-nav-button-focus: #f7e0a1;--color-card-nav-button-hover: #b39554;--color-actions-background: #655f5c;--color-actions-background-focus: #655f5c;--color-actions-background-hover: rgba(22, 21, 19, 0.3);--color-actions-border: #fff;--color-actions-text: #fff;--color-actions-text-focus: #fff;--color-actions-text-hover: #fff;--color-global-actions-background: #3a3631;--color-global-actions-background-focus: #3a3631;--color-global-actions-background-hover: rgba(22, 21, 19, 0.3);--color-global-actions-border: #fff;--color-global-actions-text: #fff;--color-global-actions-text-focus: #fff;--color-global-actions-text-hover: #fff;--color-primary-actions-background: #fff;--color-primary-actions-background-focus: #fff;--color-primary-actions-background-hover: #fff linear-gradient(rgb(251, 249, 248), rgb(251, 249, 248));--color-primary-actions-text: #161513;--color-primary-actions-text-focus: #161513;--color-primary-actions-text-hover: #161513;--color-danger-actions-background-focus: rgb(214, 59, 37);--color-danger-actions-background-hover: rgb(214, 59, 37) linear-gradient(rgba(255, 255, 255, 0.08), rgba(255, 255, 255, 0.08));--color-links: #f7e0a1;--color-user-links: #c0533f;--color-agent-name: #fcfbfa;--color-footer-form-label: #fcfbfa;--color-footer-background: #fff;--color-footer-button-fill: #161513;--color-input-background: #fff;--color-input-text: #161513;--color-recognition-view-text: #fff;--color-visualizer-container-background: #fff;--color-notification-badge-background: #312d2a;--color-notification-badge-text: #fff;--color-popup-button-text: #201e1c}.wrapper:not(.embedded):not(.contextual-widget):not(.search-bar-widget-wrapper){bottom:var(--position-bottom);left:var(--position-left);top:var(--position-top);right:var(--position-right)}.wrapper *{box-sizing:border-box}.wrapper b{font-weight:700}.wrapper button{position:relative;max-width:100%;padding:9px 16px;margin:0 0 8px;min-height:36px;line-height:16px;font-size:13.75px;font-weight:600;font-family:inherit;border-radius:4px;border-width:thin;border-style:solid;cursor:pointer;overflow:hidden;word-break:break-word;flex-shrink:0}.wrapper button:disabled{opacity:.5;cursor:not-allowed}.wrapper button.icon{width:36px;height:36px;padding:8px;margin:0;margin-inline-start:4px;border:none;border-radius:4px;color:var(--color-text);background-color:rgba(0,0,0,0);justify-content:center}.wrapper button.icon.with-label{width:auto;max-width:200px}.wrapper button.icon.with-label svg,.wrapper button.icon.with-label img{margin-right:4px}.wrapper button.icon.label-only{width:auto;max-width:200px}.wrapper button.icon.label-only svg,.wrapper button.icon.label-only img{display:none}.wrapper button:not(:disabled):focus{outline:1px dotted var(--color-actions-outline-focus);outline-offset:1px}.wrapper button svg,.wrapper button img{width:20px;height:20px;flex-shrink:0}.wrapper .button{position:absolute;right:0;bottom:0;height:48px;width:48px;max-width:unset;padding:0;margin:0;border:none;background-position:center center;background-repeat:no-repeat;cursor:pointer;justify-content:center;align-items:center;z-index:10000;color:var(--color-text);background-color:var(--color-launch-icon-background);border-radius:0;overflow:visible}.wrapper .button svg,.wrapper .button img{height:unset;width:unset;max-width:100%;max-height:100%}.wrapper .button:not(:disabled):hover,.wrapper .button:not(:disabled):focus,.wrapper .button:not(:disabled):active{background-color:var(--color-launch-icon-background)}@media screen and (min-width: 769px){.wrapper .button{height:64px;width:64px}}.wrapper .dialog-wrapper{position:absolute;top:0;left:0;right:0;width:100%;height:100%}.wrapper .dialog-wrapper .dialog-backdrop{position:absolute;background:rgba(0,0,0,.2);height:100%;width:100%;z-index:5}.wrapper .dialog-wrapper .dialog{box-shadow:rgba(0,0,0,.16) 0px 4px 8px 0px;border-radius:6px;position:relative;max-width:450px;min-height:48px;max-height:60%;top:30%;left:0;right:0;padding:8px 16px;margin:8px auto;width:calc(100% - 16px);z-index:5;animation:dialog-in .2s cubic-bezier(0.22, 0.45, 0.42, 0.92) both;background-color:var(--color-popup-background);overflow-y:auto}.wrapper .dialog-wrapper .dialog.dialog-out{animation:dialog-out .2s cubic-bezier(0.5, 0.07, 0.68, 0.48) both}.wrapper .dialog-wrapper .dialog .dialog-icon-content-wrapper{margin:16px 0}.wrapper .dialog-wrapper .dialog .dialog-icon-content-wrapper .dialog-icon{width:20px;height:20px;max-width:20px;max-height:20px;margin-inline-end:8px}.wrapper .dialog-wrapper .dialog .dialog-icon-content-wrapper .dialog-icon img,.wrapper .dialog-wrapper .dialog .dialog-icon-content-wrapper .dialog-icon svg{max-width:20px;max-height:20px}.wrapper .dialog-wrapper .dialog .dialog-icon-content-wrapper .dialog-content{line-height:1.4;margin-inline-end:28px}.wrapper .dialog-wrapper .dialog .dialog-icon-content-wrapper .dialog-content .dialog-title{font-family:var(--font-family);font-size:18px;font-weight:bold;word-break:break-word;color:var(--color-popup-text)}.wrapper .dialog-wrapper .dialog .dialog-icon-content-wrapper .dialog-content .dialog-description{color:var(--color-popup-text);opacity:.6;font-size:13px;margin-top:8px}.wrapper .dialog-wrapper .dialog .dialog-icon-content-wrapper .dialog-label{color:var(--color-popup-text);font-size:large}.wrapper .dialog-wrapper .dialog .dialog-icon-content-wrapper .dialog-input{font-size:medium;min-height:36px;width:100%;margin:0 0 10px 0;padding:10px;color:var(--color-form-input-text);background-color:var(--color-form-actions-background);border:1px solid var(--color-form-input-border);border-radius:4px}.wrapper .dialog-wrapper .dialog .dialog-close-button{margin-inline-start:0}.wrapper .dialog-wrapper .dialog .action-wrapper{width:100%;margin:16px 0 6px;gap:16px}.wrapper .dialog-wrapper .dialog .action-wrapper .popup-action{background-color:var(--color-popup-button-background);border-color:var(--color-popup-button-text);color:var(--color-popup-button-text);border-style:solid;margin:0;height:34px;justify-content:center;flex:1 0 auto}.wrapper .dialog-wrapper .dialog .action-wrapper .popup-action:hover{background-color:var(--color-footer-button-background-hover)}.wrapper .dialog-wrapper .dialog .action-wrapper .popup-action:last-child{margin:0}.wrapper .dialog-wrapper .dialog .action-wrapper .popup-action.filled{background-color:var(--color-popup-button-text);color:var(--color-popup-button-background)}.wrapper .dialog-wrapper .dialog .action-wrapper .popup-action.filled:hover{opacity:.9}.wrapper .dialog-wrapper.modeless{top:56px;height:auto}.wrapper .dialog-wrapper.modeless .dialog{gap:16px;top:0}.wrapper .dialog-wrapper.modeless .dialog .dialog-icon-content-wrapper{margin:0}.wrapper .dialog-wrapper.modeless .dialog .dialog-icon-content-wrapper .dialog-content{margin:0}.wrapper .dialog-wrapper.modeless .dialog .dialog-icon-content-wrapper .dialog-content .dialog-title{font-size:16px;line-height:1.3333;font-weight:normal}.wrapper .header{height:56px;padding:0 8px;background-color:var(--color-header-background);color:var(--color-header-text)}.wrapper .header .logo{flex:0 0 auto;max-width:100px;height:36px;max-height:36px;overflow:hidden;padding:0}.wrapper .header .header-info-wrapper{flex-direction:column;flex-wrap:nowrap;width:100%;min-width:0;padding:0;margin:0 8px}.wrapper .header .header-info-wrapper .title{max-width:100%;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;font-size:1.125em;font-weight:700}.wrapper .header .header-info-wrapper .subtitle{overflow:hidden;text-overflow:ellipsis;white-space:nowrap}.wrapper .header .header-info-wrapper .connection-status{font-weight:bold;font-size:10px;justify-content:center;padding:0;margin:0;text-transform:uppercase;text-overflow:ellipsis;white-space:nowrap;overflow:hidden}.wrapper .header .header-gap{flex:auto}.wrapper .header-actions{flex:1 0 auto;justify-content:flex-end;flex-direction:inherit}.wrapper .header-button svg>path{fill:var(--color-header-button-fill)}.wrapper .header-button:not(:disabled):hover{background-color:var(--color-header-button-background-hover)}.wrapper .header-button:not(:disabled):hover svg>path{fill:var(--color-header-button-fill-hover)}.wrapper .conversation{display:flex;flex:1;-webkit-box-orient:vertical;-webkit-box-direction:normal;flex-direction:column;overflow-x:hidden;overflow-y:auto;scroll-behavior:smooth;width:100%;padding:16px}.wrapper .conversation .conversation-pane .message-date,.wrapper .conversation .conversation-pane .relative-timestamp{font-size:12px;margin:8px 0 8px;color:var(--color-timestamp);text-align:start}.wrapper .conversation .conversation-pane .message-date.right,.wrapper .conversation .conversation-pane .relative-timestamp.right{text-align:end}.wrapper .conversation .conversation-pane.bot-icon .message.card-message-horizontal{margin-inline-start:-52px}.wrapper .conversation .conversation-pane.bot-icon .message.card-message-horizontal .message-header,.wrapper .conversation .conversation-pane.bot-icon .message.card-message-horizontal .message-footer,.wrapper .conversation .conversation-pane.bot-icon .message.card-message-horizontal .message-global-actions{margin-inline-start:52px}.wrapper .conversation .conversation-pane.bot-icon .message.card-message-horizontal .card-message-content .card-message-cards{padding-inline-start:52px}.wrapper .conversation .conversation-pane.bot-icon .relative-timestamp.left{margin-inline-start:36px}.wrapper .conversation .conversation-pane.user-icon .relative-timestamp.right{margin-inline-end:36px}.wrapper .conversation .conversation-pane.bot-icon .message-block .messages-wrapper,.wrapper .conversation .conversation-pane.user-icon .message-block .messages-wrapper{max-width:calc(.9*(100% - 36px))}.wrapper .conversation .conversation-pane.bot-icon .message-block .messages-wrapper .message.card-message-horizontal .message-header,.wrapper .conversation .conversation-pane.bot-icon .message-block .messages-wrapper .message.card-message-horizontal .message-footer,.wrapper .conversation .conversation-pane.bot-icon .message-block .messages-wrapper .message.card-message-horizontal .message-global-actions,.wrapper .conversation .conversation-pane.user-icon .message-block .messages-wrapper .message.card-message-horizontal .message-header,.wrapper .conversation .conversation-pane.user-icon .message-block .messages-wrapper .message.card-message-horizontal .message-footer,.wrapper .conversation .conversation-pane.user-icon .message-block .messages-wrapper .message.card-message-horizontal .message-global-actions{max-width:calc(.9*(100% - 68px))}.wrapper .conversation .conversation-pane.user-icon.bot-icon .message-block .messages-wrapper{max-width:calc(.9*(100% - 72px))}.wrapper .conversation .conversation-pane.user-icon.bot-icon .message-block .messages-wrapper .message.card-message-horizontal .message-header,.wrapper .conversation .conversation-pane.user-icon.bot-icon .message-block .messages-wrapper .message.card-message-horizontal .message-footer,.wrapper .conversation .conversation-pane.user-icon.bot-icon .message-block .messages-wrapper .message.card-message-horizontal .message-global-actions{max-width:calc(.9*(100% - 104px))}.wrapper .conversation .cancel-response-button{background-color:var(--color-branding);border-radius:10000px;bottom:72px;box-shadow:0px 8px 10px -2px rgba(0,0,0,.25);height:36px;position:absolute;left:unset;right:16px;width:36px;z-index:100;animation:cancel-button-entrance .25s ease-in forwards;transition:all .25s ease-in-out}[dir=rtl] .wrapper .conversation .cancel-response-button{left:16px;right:unset}.wrapper .conversation .cancel-response-button .cancel-response-button-icon path{fill:#fff}.wrapper .conversation .cancel-response-button:hover{background-color:var(--color-branding-light);box-shadow:0px 10px 12px -2px rgba(0,0,0,.3)}.wrapper .conversation .cancel-response-button:active{background-color:var(--color-branding-dark);box-shadow:0px 6px 8px -2px rgba(0,0,0,.2)}.wrapper .conversation .cancel-response-button:focus{outline:none;box-shadow:0px 0px 0px 3px rgba(192,83,63,.4),0px 8px 10px -2px rgba(0,0,0,.25)}.wrapper .conversation .cancel-response-button:focus:not(:focus-visible){box-shadow:0px 8px 10px -2px rgba(0,0,0,.25)}.wrapper .conversation .cancel-response-button.hide{animation:cancel-button-exit .2s ease-out forwards}.wrapper .timestamp-header{text-align:center;font-size:12px;font-weight:700;color:var(--color-timestamp);margin:16px 0}.wrapper .hr{margin:24px 0;font-size:12px;color:var(--color-horizontal-rule-background)}.wrapper .hr:before{content:"";background-color:var(--color-horizontal-rule-background);height:1px;flex-grow:1;margin-inline-end:10px}.wrapper .hr:after{content:"";background-color:var(--color-horizontal-rule-background);height:1px;flex-grow:1;margin-inline-start:10px}.wrapper .card-actions,.wrapper .form-actions,.wrapper .message-actions,.wrapper .message-global-actions{margin-top:6px;display:flex;align-items:flex-start;justify-content:flex-start;flex-wrap:wrap}.wrapper .card-actions.form-message-actions-col,.wrapper .form-actions.form-message-actions-col,.wrapper .message-actions.form-message-actions-col,.wrapper .message-global-actions.form-message-actions-col{flex-basis:100%;max-width:100%}.wrapper .card-actions:not(.col) .action-postback,.wrapper .form-actions:not(.col) .action-postback,.wrapper .message-actions:not(.col) .action-postback,.wrapper .message-global-actions:not(.col) .action-postback{margin-inline-end:8px}.wrapper .card-actions:not(.col) .action-postback:last-child,.wrapper .form-actions:not(.col) .action-postback:last-child,.wrapper .message-actions:not(.col) .action-postback:last-child,.wrapper .message-global-actions:not(.col) .action-postback:last-child{margin-inline-end:0}.wrapper .action-postback{background:var(--color-actions-background);border-color:var(--color-actions-border);color:var(--color-actions-text);display:flex;flex-direction:row;gap:10px;text-align:start}.wrapper .action-postback:not(:disabled):hover{color:var(--color-actions-text-hover);background-color:var(--color-actions-background-hover)}.wrapper .action-postback:not(:disabled):hover svg>path{fill:var(--color-actions-text-hover)}.wrapper .action-postback:not(:disabled):focus,.wrapper .action-postback:not(:disabled):active{background-color:var(--color-actions-background-focus);color:var(--color-actions-text-focus)}.wrapper .action-postback:not(:disabled):focus svg>path,.wrapper .action-postback:not(:disabled):active svg>path{fill:var(--color-actions-text-focus)}.wrapper .action-postback.primary{background:var(--color-primary-actions-background);color:var(--color-primary-actions-text);border:var(--color-primary-actions-border)}.wrapper .action-postback.primary:not(:disabled):hover{background:var(--color-primary-actions-background-hover);color:var(--color-primary-actions-text-hover)}.wrapper .action-postback.primary:not(:disabled):hover svg>path{fill:var(--color-primary-actions-text-hover)}.wrapper .action-postback.primary:not(:disabled):focus,.wrapper .action-postback.primary:not(:disabled):active{background:var(--color-primary-actions-background-focus);color:var(--color-primary-actions-text-focus)}.wrapper .action-postback.primary:not(:disabled):focus svg>path,.wrapper .action-postback.primary:not(:disabled):active svg>path{fill:var(--color-primary-actions-text-focus)}.wrapper .action-postback.danger{background:var(--color-danger-actions-background);color:var(--color-danger-actions-text);border:var(--color-danger-actions-border)}.wrapper .action-postback.danger:not(:disabled):hover{background:var(--color-danger-actions-background-hover);color:var(--color-danger-actions-text-hover)}.wrapper .action-postback.danger:not(:disabled):hover svg>path{fill:var(--color-danger-actions-text-hover)}.wrapper .action-postback.danger:not(:disabled):focus,.wrapper .action-postback.danger:not(:disabled):active{background:var(--color-danger-actions-background-focus);color:var(--color-danger-actions-text-focus)}.wrapper .action-postback.danger:not(:disabled):focus svg>path,.wrapper .action-postback.danger:not(:disabled):active svg>path{fill:var(--color-danger-actions-text-focus)}.wrapper .action-postback.display-link{outline:1px solid rgba(0,0,0,0);border:none;min-height:unset;background:rgba(0,0,0,0) !important;padding:0}.wrapper .action-postback.display-link:hover{text-decoration:underline}.wrapper .action-postback.c2k-action{border-radius:0;color:#227e9e !important;border:none;padding:0;min-height:unset;font-size:16px;background:rgba(0,0,0,0) !important;margin-bottom:0}.wrapper .message-global-actions{margin-top:8px}.wrapper .message-global-actions.stars{display:block}.wrapper .message-global-actions button{background:var(--color-global-actions-background);color:var(--color-global-actions-text);border-color:var(--color-global-actions-border)}.wrapper .message-global-actions button:not(:disabled):hover{background-color:var(--color-global-actions-background-hover);color:var(--color-global-actions-text-hover)}.wrapper .message-global-actions button:not(:disabled):hover svg>path{fill:var(--color-global-actions-text-hover)}.wrapper .message-global-actions button:not(:disabled):focus,.wrapper .message-global-actions button:not(:disabled):active{background-color:var(--color-global-actions-background-focus);color:var(--color-global-actions-text-focus)}.wrapper .message-global-actions button:not(:disabled):focus svg>path,.wrapper .message-global-actions button:not(:disabled):active svg>path{fill:var(--color-global-actions-text-focus)}.wrapper .message-bubble{position:relative;display:flex;flex-direction:column;align-items:flex-start;margin:0;padding:6px 16px;color:var(--color-bot-text);background:var(--color-bot-message-background);min-height:28px;line-height:16px;overflow-wrap:break-word;max-width:100%;border-radius:2px 10px 10px 2px;margin-top:2px}.wrapper .message-bubble>*{width:100%}.wrapper .message-bubble.before-card{border-radius:2px 10px 10px 10px}.wrapper .message-bubble .video-wrapper{max-width:100%}.wrapper .message-bubble.error{background-color:var(--color-error-message-background);color:var(--color-error-text);border:1px dashed var(--color-error-border)}.wrapper .message-bubble.error .message-icon path{fill:var(--color-error-title)}.wrapper .message-bubble.error .message-title{color:var(--color-error-title)}.wrapper .message-bubble span.highlight{background-color:rgba(143,191,208,.4)}.wrapper .message-bubble .message-with-icon{display:flex;align-items:flex-start;justify-content:space-between}.wrapper .message-bubble .message-with-icon .message-icon{width:24px;height:24px;align-items:center;margin-inline-end:16px}.wrapper .message-bubble .message-with-icon .message-text{word-break:break-word}.wrapper .message-bubble.message-header{margin-bottom:2px}.wrapper .message-bubble.message-footer{margin-top:2px}.wrapper .message-bubble .message-user-postback>img{max-height:32px;max-width:32px}.wrapper .messages-wrapper{max-width:90%;align-items:flex-start}.wrapper .messages-wrapper .agent-name{position:relative;bottom:3px;max-width:111.1111111111%;height:16px;font-size:12px;line-height:16px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;color:var(--color-agent-name)}.wrapper .messages-wrapper .screen-reader-only{height:1px;left:-20000px;overflow:hidden;position:absolute;top:auto;width:1px}.wrapper .messages-wrapper .message-list{width:100%;align-items:flex-start}.wrapper .message{width:100%;white-space:pre-wrap}.wrapper .message .embeddedAction{padding:2px 6px;border-radius:4px;cursor:pointer;display:inline-block;font-size:12px;font-weight:600;height:20px;line-height:16px;border:1px solid rgba(122,115,110,.2509803922)}.wrapper .message .embeddedAction.display-link{color:var(--color-links);padding:2px 0;outline:1px solid rgba(0,0,0,0);border:none}.wrapper .message .embeddedAction.display-link:hover{text-decoration:underline}.wrapper .message .embeddedAction.display-icon{padding:0;outline:1px solid rgba(0,0,0,0);border:none}.wrapper .message .action-wrapper{display:flex;flex-direction:column;position:relative}.wrapper .message .action-wrapper button:not(:disabled):hover+div>.tooltip{display:block;position:absolute;background-color:var(--color-bot-message-background);max-width:296px;border-radius:2px;box-shadow:0px 1px 4px 0px rgba(0,0,0,.1215686275);padding:8px;z-index:3;font-size:13px;font-weight:400;inset-inline-start:-16px;line-height:20px;margin-top:-4px;overflow-wrap:break-word}.wrapper .message a{color:var(--color-links)}.wrapper .message button.anchor-btn{padding:0}.wrapper .message button.anchor-btn a{display:block;text-decoration:inherit;color:inherit;padding:10px 20px}.wrapper .message button:last-child{margin-bottom:0}.wrapper .message .message-wrapper{display:flex;align-items:flex-start;flex-direction:column;width:100%;max-width:100%}.wrapper .message:first-child .message-bubble:not(.message-footer){margin-top:0}.wrapper .message:first-child .card-message-content:first-child .card-message-cards{margin-top:0}.wrapper .message:last-child .message-bubble:last-child{border-radius:2px 10px 10px 10px}.wrapper .message:last-child .message-bubble:last-child.edit-form-message .form-message-header{border-radius:1px 9px 0 0}.wrapper .message:last-child .message-bubble:last-child.edit-form-message .form-message-item{border-radius:1px 9px 9px 9px}.wrapper .message:last-child .card-message-content:last-child .card-message-cards{margin-bottom:-8px}.wrapper .message.card-message-horizontal{margin-inline-start:-16px;width:calc(var(--width-full-screen) - 12px)}.wrapper .message.card-message-horizontal .message-header,.wrapper .message.card-message-horizontal .message-footer,.wrapper .message.card-message-horizontal .message-global-actions{margin-inline-start:16px;max-width:calc(.9*(100% - 28px))}.wrapper .message.card-message-horizontal .message-header{border-radius:2px 10px 10px 10px}.wrapper .message.card-message-horizontal .card-message-cards{flex-direction:row;overflow-x:auto;padding-inline-start:16px}.wrapper .message.card-message-horizontal .card{border:1px solid rgba(22,21,19,.12);box-shadow:0px 1px 4px 0px rgba(0,0,0,.12);margin-inline-end:8px}.wrapper .message.card-message-horizontal .next-wrapper,.wrapper .message.card-message-horizontal .prev-wrapper{position:absolute;height:100%;top:0;width:52px;z-index:1}.wrapper .message.card-message-horizontal .next-wrapper{inset-inline-end:0;background:linear-gradient(90deg, rgba(255, 255, 255, 0), var(--color-conversation-background) 60%)}.wrapper .message.card-message-horizontal .prev-wrapper{inset-inline-start:0;background:linear-gradient(90deg, var(--color-conversation-background) 40%, rgba(255, 255, 255, 0))}[dir=rtl] .wrapper .message.card-message-horizontal .next-wrapper{background:linear-gradient(90deg, var(--color-conversation-background) 40%, rgba(255, 255, 255, 0))}[dir=rtl] .wrapper .message.card-message-horizontal .prev-wrapper{background:linear-gradient(90deg, rgba(255, 255, 255, 0), var(--color-conversation-background) 60%)}[dir=rtl] .wrapper .message.card-message-horizontal .next,[dir=rtl] .wrapper .message.card-message-horizontal .previous{transform:rotate(180deg)}.wrapper .message.card-message-horizontal .next,.wrapper .message.card-message-horizontal .previous{position:absolute;z-index:10;width:36px;height:36px;left:8px;padding:0;overflow:hidden;background-color:var(--color-card-nav-button);border:none;box-shadow:0px 2px 4px rgba(0,0,0,.1);top:calc(50% - 18px);justify-content:center}.wrapper .message.card-message-horizontal .next:hover,.wrapper .message.card-message-horizontal .previous:hover{background-color:var(--color-card-nav-button-hover)}.wrapper .message.card-message-horizontal .next:focus,.wrapper .message.card-message-horizontal .next:active,.wrapper .message.card-message-horizontal .previous:focus,.wrapper .message.card-message-horizontal .previous:active{background-color:var(--color-card-nav-button-focus)}.wrapper .message-block{justify-content:flex-start;align-items:flex-start;margin-bottom:8px}.wrapper .message-block.right{flex-direction:row-reverse}.wrapper .message-block.right .icon-wrapper{margin:unset;margin-inline-start:8px}.wrapper .message-block.right .messages-wrapper{align-items:flex-end}.wrapper .message-block.right .messages-wrapper .message a{color:var(--color-user-links)}.wrapper .message-block.right .messages-wrapper .message .message-wrapper{align-items:flex-end}.wrapper .message-block.right .messages-wrapper .message .message-bubble{border-radius:10px 2px 2px 10px}.wrapper .message-block.right .messages-wrapper .message .message-bubble:not(.error){color:var(--color-user-text);background:var(--color-user-message-background)}.wrapper .message-block.right .messages-wrapper .message:last-child .message-bubble:last-child{border-radius:10px 2px 10px 10px}.wrapper .message-block.right .message-date{text-align:right}.wrapper .icon-wrapper{margin-inline-end:8px;width:28px;height:28px;min-height:28px;min-width:28px;border-radius:4px;overflow:hidden;z-index:1;display:flex;align-items:center;justify-content:center}.wrapper .icon-wrapper.agent-avatar{background:var(--color-agent-avatar-background);margin-top:16px}.wrapper .icon-wrapper .message-icon{height:100%;max-height:100%;max-width:100%;width:100%;color:var(--color-timestamp);overflow:hidden;text-overflow:ellipsis}.wrapper .icon-wrapper .agent-icon{position:relative;min-width:20px;min-height:20px;font-weight:700;font-size:16px;line-height:20px;text-align:center;color:var(--color-agent-initials)}.wrapper .attachment{width:100%}.wrapper .attachment .attachment-placeholder{background-color:var(--color-attachment-placeholder);max-width:calc(100% + 32px);min-width:228px;min-height:88px;max-height:230px;margin:-6px -16px 0;justify-content:center;overflow:hidden}.wrapper .attachment .attachment-placeholder>*{max-width:100%}.wrapper .attachment .attachment-placeholder .attachment-icon{height:48px;width:48px}.wrapper .attachment .attachment-placeholder .attachment-icon svg{height:48px;width:48px}.wrapper .attachment .attachment-placeholder .attachment-icon img{width:100%}.wrapper .attachment .attachment-placeholder .attachment-audio{height:50px;width:100%}.wrapper .attachment .attachment-placeholder .attachment-audio::-webkit-media-controls-enclosure{background-color:rgba(0,0,0,0)}.wrapper .attachment .attachment-footer{background-color:var(--color-attachment-footer);color:var(--color-attachment-text);margin:0 -16px -6px;height:50px;padding:16px}.wrapper .attachment .attachment-footer.with-actions{border-bottom:thin solid rgba(22,21,19,.1);margin-bottom:6px}.wrapper .attachment .attachment-footer .attachment-title{flex-grow:1;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}.wrapper .card{width:252px;border-radius:6px;padding:12px 16px;margin-block-end:8px;justify-content:flex-start;flex-shrink:0;color:var(--color-bot-text);background:var(--color-card-background);overflow:hidden}.wrapper .card .card-content{margin-bottom:12px}.wrapper .card .card-image{display:block;width:calc(100% + 32px);margin:-12px -16px 10px;min-height:88px;background-color:var(--color-attachment-placeholder)}.wrapper .card .card-title{margin-bottom:4px;font-weight:700;word-break:break-word}.wrapper .card .card-description{color:var(--color-text-light)}.wrapper .card-message-content{width:100%;position:relative}.wrapper .card-message-content .card-message-cards{width:100%;align-items:stretch;display:flex;scroll-behavior:smooth;overflow-x:visible;flex-direction:column;margin:8px 0 0;scrollbar-width:none}.wrapper .card-message-content .card-message-cards::-webkit-scrollbar{display:none}.wrapper .message-bubble-tabular-message,.wrapper .message-bubble-form-message{width:111%;max-width:unset;border-radius:0 8px 8px 8px;padding:0;background-color:var(--color-table-background);color:var(--color-table-text);border:1px solid var(--color-table-header-background);overflow:hidden}.wrapper .message-bubble-tabular-message .popupContent,.wrapper .message-bubble-form-message .popupContent{max-width:280px;position:absolute;height:auto;border-radius:8px;z-index:3;box-shadow:0px 4px 4px 0px rgba(0,0,0,.1019607843);border:1px solid rgba(22,21,19,.1215686275);background:var(--color-bot-message-background);display:none;inset-inline-start:-4px}.wrapper .message-bubble-tabular-message .results-page-status,.wrapper .message-bubble-form-message .results-page-status{align-items:center;background-color:var(--color-table-background);color:var(--color-table-text);display:flex;flex-direction:row;font-size:13.75px;justify-content:flex-end;line-height:16px;padding:12px 16px;border-top:1px solid var(--color-table-separator)}.wrapper .message-bubble-tabular-message~.message-footer,.wrapper .message-bubble-form-message~.message-footer{margin-top:8px}.wrapper .message-bubble-tabular-message .message-actions .action-postback,.wrapper .message-bubble-tabular-message .table-message-item .action-postback{background:var(--color-table-actions-background);color:var(--color-table-actions-text);border-color:var(--color-table-actions-border)}.wrapper .message-bubble-tabular-message .message-actions .action-postback:not(:disabled):hover,.wrapper .message-bubble-tabular-message .table-message-item .action-postback:not(:disabled):hover{color:var(--color-table-actions-text-hover);background:var(--color-table-actions-background-hover)}.wrapper .message-bubble-tabular-message .message-actions .action-postback:not(:disabled):hover svg>path,.wrapper .message-bubble-tabular-message .table-message-item .action-postback:not(:disabled):hover svg>path{fill:var(--color-table-actions-text-hover)}.wrapper .message-bubble-tabular-message .message-actions .action-postback:not(:disabled):focus,.wrapper .message-bubble-tabular-message .message-actions .action-postback:not(:disabled):active,.wrapper .message-bubble-tabular-message .table-message-item .action-postback:not(:disabled):focus,.wrapper .message-bubble-tabular-message .table-message-item .action-postback:not(:disabled):active{background:var(--color-table-actions-background-focus);color:var(--color-table-actions-text-focus)}.wrapper .message-bubble-tabular-message .message-actions .action-postback:not(:disabled):focus svg>path,.wrapper .message-bubble-tabular-message .message-actions .action-postback:not(:disabled):active svg>path,.wrapper .message-bubble-tabular-message .table-message-item .action-postback:not(:disabled):focus svg>path,.wrapper .message-bubble-tabular-message .table-message-item .action-postback:not(:disabled):active svg>path{fill:var(--color-table-actions-text-focus)}.wrapper .message-bubble-tabular-message .message-actions,.wrapper .message-bubble-form-message .message-actions{border-top:1px solid var(--color-table-separator);padding:12px 16px;margin-top:auto}.wrapper .message-bubble-tabular-message .message-actions .action-postback.primary,.wrapper .message-bubble-tabular-message .table-message-item .action-postback.primary,.wrapper .message-bubble-tabular-message .form-actions .action-postback.primary,.wrapper .message-bubble-tabular-message .form-message-value .action-postback.primary,.wrapper .message-bubble-form-message .message-actions .action-postback.primary,.wrapper .message-bubble-form-message .table-message-item .action-postback.primary,.wrapper .message-bubble-form-message .form-actions .action-postback.primary,.wrapper .message-bubble-form-message .form-message-value .action-postback.primary{background:var(--color-primary-form-actions-background);color:var(--color-primary-form-actions-text);border:var(--color-primary-form-actions-border)}.wrapper .message-bubble-tabular-message .message-actions .action-postback.primary:not(:disabled):hover,.wrapper .message-bubble-tabular-message .table-message-item .action-postback.primary:not(:disabled):hover,.wrapper .message-bubble-tabular-message .form-actions .action-postback.primary:not(:disabled):hover,.wrapper .message-bubble-tabular-message .form-message-value .action-postback.primary:not(:disabled):hover,.wrapper .message-bubble-form-message .message-actions .action-postback.primary:not(:disabled):hover,.wrapper .message-bubble-form-message .table-message-item .action-postback.primary:not(:disabled):hover,.wrapper .message-bubble-form-message .form-actions .action-postback.primary:not(:disabled):hover,.wrapper .message-bubble-form-message .form-message-value .action-postback.primary:not(:disabled):hover{background:var(--color-primary-form-actions-background-hover);color:var(--color-primary-form-actions-text-hover)}.wrapper .message-bubble-tabular-message .message-actions .action-postback.primary:not(:disabled):hover svg>path,.wrapper .message-bubble-tabular-message .table-message-item .action-postback.primary:not(:disabled):hover svg>path,.wrapper .message-bubble-tabular-message .form-actions .action-postback.primary:not(:disabled):hover svg>path,.wrapper .message-bubble-tabular-message .form-message-value .action-postback.primary:not(:disabled):hover svg>path,.wrapper .message-bubble-form-message .message-actions .action-postback.primary:not(:disabled):hover svg>path,.wrapper .message-bubble-form-message .table-message-item .action-postback.primary:not(:disabled):hover svg>path,.wrapper .message-bubble-form-message .form-actions .action-postback.primary:not(:disabled):hover svg>path,.wrapper .message-bubble-form-message .form-message-value .action-postback.primary:not(:disabled):hover svg>path{fill:var(--color-primary-form-actions-text-hover)}.wrapper .message-bubble-tabular-message .message-actions .action-postback.primary:not(:disabled):focus,.wrapper .message-bubble-tabular-message .message-actions .action-postback.primary:not(:disabled):active,.wrapper .message-bubble-tabular-message .table-message-item .action-postback.primary:not(:disabled):focus,.wrapper .message-bubble-tabular-message .table-message-item .action-postback.primary:not(:disabled):active,.wrapper .message-bubble-tabular-message .form-actions .action-postback.primary:not(:disabled):focus,.wrapper .message-bubble-tabular-message .form-actions .action-postback.primary:not(:disabled):active,.wrapper .message-bubble-tabular-message .form-message-value .action-postback.primary:not(:disabled):focus,.wrapper .message-bubble-tabular-message .form-message-value .action-postback.primary:not(:disabled):active,.wrapper .message-bubble-form-message .message-actions .action-postback.primary:not(:disabled):focus,.wrapper .message-bubble-form-message .message-actions .action-postback.primary:not(:disabled):active,.wrapper .message-bubble-form-message .table-message-item .action-postback.primary:not(:disabled):focus,.wrapper .message-bubble-form-message .table-message-item .action-postback.primary:not(:disabled):active,.wrapper .message-bubble-form-message .form-actions .action-postback.primary:not(:disabled):focus,.wrapper .message-bubble-form-message .form-actions .action-postback.primary:not(:disabled):active,.wrapper .message-bubble-form-message .form-message-value .action-postback.primary:not(:disabled):focus,.wrapper .message-bubble-form-message .form-message-value .action-postback.primary:not(:disabled):active{background:var(--color-primary-form-actions-background-focus);color:var(--color-primary-form-actions-text-focus)}.wrapper .message-bubble-tabular-message .message-actions .action-postback.primary:not(:disabled):focus svg>path,.wrapper .message-bubble-tabular-message .message-actions .action-postback.primary:not(:disabled):active svg>path,.wrapper .message-bubble-tabular-message .table-message-item .action-postback.primary:not(:disabled):focus svg>path,.wrapper .message-bubble-tabular-message .table-message-item .action-postback.primary:not(:disabled):active svg>path,.wrapper .message-bubble-tabular-message .form-actions .action-postback.primary:not(:disabled):focus svg>path,.wrapper .message-bubble-tabular-message .form-actions .action-postback.primary:not(:disabled):active svg>path,.wrapper .message-bubble-tabular-message .form-message-value .action-postback.primary:not(:disabled):focus svg>path,.wrapper .message-bubble-tabular-message .form-message-value .action-postback.primary:not(:disabled):active svg>path,.wrapper .message-bubble-form-message .message-actions .action-postback.primary:not(:disabled):focus svg>path,.wrapper .message-bubble-form-message .message-actions .action-postback.primary:not(:disabled):active svg>path,.wrapper .message-bubble-form-message .table-message-item .action-postback.primary:not(:disabled):focus svg>path,.wrapper .message-bubble-form-message .table-message-item .action-postback.primary:not(:disabled):active svg>path,.wrapper .message-bubble-form-message .form-actions .action-postback.primary:not(:disabled):focus svg>path,.wrapper .message-bubble-form-message .form-actions .action-postback.primary:not(:disabled):active svg>path,.wrapper .message-bubble-form-message .form-message-value .action-postback.primary:not(:disabled):focus svg>path,.wrapper .message-bubble-form-message .form-message-value .action-postback.primary:not(:disabled):active svg>path{fill:var(--color-primary-form-actions-text-focus)}.wrapper .message-bubble-tabular-message .message-actions .action-postback.danger,.wrapper .message-bubble-tabular-message .table-message-item .action-postback.danger,.wrapper .message-bubble-tabular-message .form-actions .action-postback.danger,.wrapper .message-bubble-tabular-message .form-message-value .action-postback.danger,.wrapper .message-bubble-form-message .message-actions .action-postback.danger,.wrapper .message-bubble-form-message .table-message-item .action-postback.danger,.wrapper .message-bubble-form-message .form-actions .action-postback.danger,.wrapper .message-bubble-form-message .form-message-value .action-postback.danger{background:var(--color-danger-form-actions-background);color:var(--color-danger-form-actions-text);border:var(--color-danger-form-actions-border)}.wrapper .message-bubble-tabular-message .message-actions .action-postback.danger:not(:disabled):hover,.wrapper .message-bubble-tabular-message .table-message-item .action-postback.danger:not(:disabled):hover,.wrapper .message-bubble-tabular-message .form-actions .action-postback.danger:not(:disabled):hover,.wrapper .message-bubble-tabular-message .form-message-value .action-postback.danger:not(:disabled):hover,.wrapper .message-bubble-form-message .message-actions .action-postback.danger:not(:disabled):hover,.wrapper .message-bubble-form-message .table-message-item .action-postback.danger:not(:disabled):hover,.wrapper .message-bubble-form-message .form-actions .action-postback.danger:not(:disabled):hover,.wrapper .message-bubble-form-message .form-message-value .action-postback.danger:not(:disabled):hover{background:var(--color-danger-form-actions-background-hover);color:var(--color-danger-form-actions-text-hover)}.wrapper .message-bubble-tabular-message .message-actions .action-postback.danger:not(:disabled):hover svg>path,.wrapper .message-bubble-tabular-message .table-message-item .action-postback.danger:not(:disabled):hover svg>path,.wrapper .message-bubble-tabular-message .form-actions .action-postback.danger:not(:disabled):hover svg>path,.wrapper .message-bubble-tabular-message .form-message-value .action-postback.danger:not(:disabled):hover svg>path,.wrapper .message-bubble-form-message .message-actions .action-postback.danger:not(:disabled):hover svg>path,.wrapper .message-bubble-form-message .table-message-item .action-postback.danger:not(:disabled):hover svg>path,.wrapper .message-bubble-form-message .form-actions .action-postback.danger:not(:disabled):hover svg>path,.wrapper .message-bubble-form-message .form-message-value .action-postback.danger:not(:disabled):hover svg>path{fill:var(--color-danger-form-actions-text-hover)}.wrapper .message-bubble-tabular-message .message-actions .action-postback.danger:not(:disabled):focus,.wrapper .message-bubble-tabular-message .message-actions .action-postback.danger:not(:disabled):active,.wrapper .message-bubble-tabular-message .table-message-item .action-postback.danger:not(:disabled):focus,.wrapper .message-bubble-tabular-message .table-message-item .action-postback.danger:not(:disabled):active,.wrapper .message-bubble-tabular-message .form-actions .action-postback.danger:not(:disabled):focus,.wrapper .message-bubble-tabular-message .form-actions .action-postback.danger:not(:disabled):active,.wrapper .message-bubble-tabular-message .form-message-value .action-postback.danger:not(:disabled):focus,.wrapper .message-bubble-tabular-message .form-message-value .action-postback.danger:not(:disabled):active,.wrapper .message-bubble-form-message .message-actions .action-postback.danger:not(:disabled):focus,.wrapper .message-bubble-form-message .message-actions .action-postback.danger:not(:disabled):active,.wrapper .message-bubble-form-message .table-message-item .action-postback.danger:not(:disabled):focus,.wrapper .message-bubble-form-message .table-message-item .action-postback.danger:not(:disabled):active,.wrapper .message-bubble-form-message .form-actions .action-postback.danger:not(:disabled):focus,.wrapper .message-bubble-form-message .form-actions .action-postback.danger:not(:disabled):active,.wrapper .message-bubble-form-message .form-message-value .action-postback.danger:not(:disabled):focus,.wrapper .message-bubble-form-message .form-message-value .action-postback.danger:not(:disabled):active{background:var(--color-danger-form-actions-background-focus);color:var(--color-danger-form-actions-text-focus)}.wrapper .message-bubble-tabular-message .message-actions .action-postback.danger:not(:disabled):focus svg>path,.wrapper .message-bubble-tabular-message .message-actions .action-postback.danger:not(:disabled):active svg>path,.wrapper .message-bubble-tabular-message .table-message-item .action-postback.danger:not(:disabled):focus svg>path,.wrapper .message-bubble-tabular-message .table-message-item .action-postback.danger:not(:disabled):active svg>path,.wrapper .message-bubble-tabular-message .form-actions .action-postback.danger:not(:disabled):focus svg>path,.wrapper .message-bubble-tabular-message .form-actions .action-postback.danger:not(:disabled):active svg>path,.wrapper .message-bubble-tabular-message .form-message-value .action-postback.danger:not(:disabled):focus svg>path,.wrapper .message-bubble-tabular-message .form-message-value .action-postback.danger:not(:disabled):active svg>path,.wrapper .message-bubble-form-message .message-actions .action-postback.danger:not(:disabled):focus svg>path,.wrapper .message-bubble-form-message .message-actions .action-postback.danger:not(:disabled):active svg>path,.wrapper .message-bubble-form-message .table-message-item .action-postback.danger:not(:disabled):focus svg>path,.wrapper .message-bubble-form-message .table-message-item .action-postback.danger:not(:disabled):active svg>path,.wrapper .message-bubble-form-message .form-actions .action-postback.danger:not(:disabled):focus svg>path,.wrapper .message-bubble-form-message .form-actions .action-postback.danger:not(:disabled):active svg>path,.wrapper .message-bubble-form-message .form-message-value .action-postback.danger:not(:disabled):focus svg>path,.wrapper .message-bubble-form-message .form-message-value .action-postback.danger:not(:disabled):active svg>path{fill:var(--color-danger-form-actions-text-focus)}.wrapper .message-bubble-form-message{background-color:var(--color-form-background);color:var(--color-form-text)}.wrapper .message-bubble-form-message.edit-form-message{overflow:visible}.wrapper .message-bubble-form-message.edit-form-message .message-actions{border-top:none;padding-top:0}.wrapper .message-bubble-form-message.edit-form-message .form-message-header{border-radius:0 7px 0 0}.wrapper .message-bubble-form-message.edit-form-message .form-message-item{border-radius:0 7px 7px 7px}.wrapper .message-bubble-form-message .results-page-status{background-color:var(--color-form-background);color:var(--color-form-text)}.wrapper .message-bubble-form-message .message-actions .action-postback{background:var(--color-form-actions-background);color:var(--color-form-actions-text);border-color:var(--color-form-actions-border)}.wrapper .message-bubble-form-message .message-actions .action-postback:not(:disabled):hover{color:var(--color-form-actions-text-hover);background:var(--color-form-actions-background-hover)}.wrapper .message-bubble-form-message .message-actions .action-postback:not(:disabled):hover svg>path{fill:var(--color-form-actions-text-hover)}.wrapper .message-bubble-form-message .message-actions .action-postback:not(:disabled):focus,.wrapper .message-bubble-form-message .message-actions .action-postback:not(:disabled):active{background:var(--color-form-actions-background-focus);color:var(--color-form-actions-text-focus)}.wrapper .message-bubble-form-message .message-actions .action-postback:not(:disabled):focus svg>path,.wrapper .message-bubble-form-message .message-actions .action-postback:not(:disabled):active svg>path{fill:var(--color-form-actions-text-focus)}.wrapper .form-message-field,.wrapper .table-message-heading,.wrapper .table-message-item{overflow-wrap:break-word;word-break:break-word}.wrapper .form-message-field:hover .popupContent,.wrapper .table-message-heading:hover .popupContent,.wrapper .table-message-item:hover .popupContent{display:flex}.wrapper .table-message-wrapper{overflow:auto}.wrapper .table-message-wrapper .table-message{min-width:100%;max-width:200%;border-collapse:collapse}.wrapper .table-message-wrapper .table-message .table-message-headings{align-items:center;color:var(--color-table-header-text);background-color:var(--color-table-header-background);display:flex}.wrapper .table-message-wrapper .table-message .table-message-headings .table-message-heading{font-size:12px;font-weight:600;line-height:16px;padding:16px;min-width:120px}.wrapper .table-message-wrapper .table-message .table-message-row{border-top:1px solid var(--color-table-separator);display:flex;align-items:center}.wrapper .table-message-wrapper .table-message .table-message-row .table-message-item{color:var(--color-table-text);font-size:16px;line-height:20px;min-width:120px;padding:10px 16px}.wrapper .form-message-header{align-items:center;background-color:var(--color-form-header-background);color:var(--color-form-header-text);display:flex;font-weight:700;line-height:20px;padding:16px;text-align:start}.wrapper .form-message-item{color:var(--color-form-text);background-color:var(--color-form-background);display:flex;flex-flow:row wrap;justify-content:space-between;padding:16px}.wrapper .form-message-item .form-row{display:flex;flex-basis:100%;flex-wrap:nowrap;width:100%}.wrapper .form-message-item .form-row.separator{border-top:1px solid var(--color-table-separator);margin-top:8px}.wrapper .form-message-item .form-row .form-row-column{display:flex;flex-flow:column wrap;flex:0 1 auto;min-width:0}.wrapper .form-message-item .form-row .form-row-column.stretch{flex-grow:1}.wrapper .form-message-item .form-row .form-row-column.align-center{justify-content:center}.wrapper .form-message-item .form-row .form-row-column.align-start{justify-content:flex-start}.wrapper .form-message-item .form-row .form-row-column.align-end{justify-content:flex-end}.wrapper .form-message-item .form-row .form-row-column:not(:last-child){margin-inline-end:16px}.wrapper .form-message-item .form-row .form-row-column .form-message-field.margin-top-lg{margin-top:28px}.wrapper .form-message-item .form-row .form-row-column .form-message-field.margin-top-md{margin-top:16px}.wrapper .form-message-item .form-row .form-row-column .form-message-field.margin-top-default{margin-top:8px}.wrapper .form-message-item .form-row .form-row-column .edit-form-message-field .listbox{min-width:100%;inset-inline-start:0;max-width:unset}.wrapper .form-message-item.c2k-reference{justify-content:flex-start}.wrapper .form-message-item.c2k-reference .form-row{margin-inline-end:8px;flex-basis:auto;width:auto;line-height:16px;color:rgba(22,21,19,.6509803922)}.wrapper .form-message-item.c2k-reference .form-row .form-row-column:not(:last-child){margin-inline-end:6px}.wrapper .form-message-item.c2k-reference .form-row span.delimiter{margin-inline-end:8px}.wrapper .form-message-item.with-border{border-bottom:1px solid var(--color-table-separator)}.wrapper .form-message-item .form-message-key{color:var(--color-form-label);line-height:16px}.wrapper .form-message-item .form-message-key.with-margin{cursor:auto;margin-bottom:8px}.wrapper .form-message-item .form-message-key.font-size-lg{font-size:14px;line-height:18px}.wrapper .form-message-item .form-message-key.font-size-md{font-size:12px;line-height:15.5px}.wrapper .form-message-item .form-message-key.font-size-sm{font-size:10px;line-height:13px}.wrapper .form-message-item .form-message-key.font-weight-bold{font-weight:700}.wrapper .form-message-item .form-message-key.font-weight-md{font-weight:600}.wrapper .form-message-item .form-message-key.font-weight-light{font-weight:400}.wrapper .form-message-item>.form-message-field:not(:last-child){margin-bottom:16px}.wrapper .form-message-item .form-message-field .form-message-value.font-size-lg{font-size:18px;line-height:23.5px}.wrapper .form-message-item .form-message-field .form-message-value.font-size-md{font-size:16px;line-height:21px}.wrapper .form-message-item .form-message-field .form-message-value.font-size-sm{font-size:13.8px;line-height:18px}.wrapper .form-message-item .form-message-field .form-message-value.font-weight-bold{font-weight:600}.wrapper .form-message-item .form-message-field .form-message-value.font-weight-md{font-weight:400}.wrapper .form-message-item .form-message-field .form-message-value.font-weight-light{font-weight:300}.wrapper .form-message-item .form-message-field .form-message-value.with-top-margin{margin-top:2px}.wrapper .form-message-item .form-message-field .form-message-value button.action-postback{margin-inline-start:0}.wrapper .form-message-item .form-message-field.form-message-field-col-1{flex-basis:100%;max-width:100%}.wrapper .form-message-item .form-message-field.form-message-field-col-2{flex-basis:calc(50% - 12px);max-width:calc(50% - 12px);height:100%}.wrapper .form-message-item .form-message-field.form-message-field-col-2:nth-last-child(2){margin-bottom:0}.wrapper .form-message-item .form-message-field.form-message-field-col-2:nth-child(even) .popupContent{inset-inline-start:calc(50% - 7px)}.wrapper .form-message-item .form-message-field.form-message-field-col-2.edit-form-message-field:nth-child(even) .listbox{inset-inline:auto 16px}.wrapper .form-message-item .form-message-field.form-message-field-col-2.edit-form-message-field .listbox{min-width:calc(50% - 28px)}.wrapper .form-message-item .form-message-field.edit-form-message-field{display:flex;flex-direction:column;overflow:visible;width:100%}.wrapper .form-message-item .form-message-field.edit-form-message-field.disabled{cursor:not-allowed}.wrapper .form-message-item .form-message-field.edit-form-message-field input.form-message-value,.wrapper .form-message-item .form-message-field.edit-form-message-field textarea.form-message-value,.wrapper .form-message-item .form-message-field.edit-form-message-field .select-wrapper.form-message-value{border-radius:4px;background-color:var(--color-form-input-background);color:var(--color-form-input-text);border:1px solid var(--color-form-input-border);font-size:16px}.wrapper .form-message-item .form-message-field.edit-form-message-field input.form-message-value:focus,.wrapper .form-message-item .form-message-field.edit-form-message-field textarea.form-message-value:focus,.wrapper .form-message-item .form-message-field.edit-form-message-field .select-wrapper.form-message-value:focus{border-color:var(--color-form-input-border-focus);box-shadow:0 0 0 1px var(--color-form-input-border-focus) inset;outline:1px solid rgba(0,0,0,0)}.wrapper .form-message-item .form-message-field.edit-form-message-field input:disabled,.wrapper .form-message-item .form-message-field.edit-form-message-field textarea:disabled,.wrapper .form-message-item .form-message-field.edit-form-message-field .select-wrapper:disabled{opacity:.5;cursor:not-allowed}.wrapper .form-message-item .form-message-field.edit-form-message-field input:disabled~.field-error,.wrapper .form-message-item .form-message-field.edit-form-message-field textarea:disabled~.field-error,.wrapper .form-message-item .form-message-field.edit-form-message-field .select-wrapper:disabled~.field-error{display:none}.wrapper .form-message-item .form-message-field.edit-form-message-field.error>input:not(:disabled,.disabled),.wrapper .form-message-item .form-message-field.edit-form-message-field.error>textarea:not(:disabled,.disabled),.wrapper .form-message-item .form-message-field.edit-form-message-field.error>.select-wrapper:not(:disabled,.disabled),.wrapper .form-message-item .form-message-field.edit-form-message-field.error>.text-field-container:not(:disabled,.disabled){border-color:var(--color-form-error)}.wrapper .form-message-item .form-message-field.edit-form-message-field input.form-message-value{height:42px;padding:0 12px}.wrapper .form-message-item .form-message-field.edit-form-message-field input.form-message-value[type=date]::-webkit-calendar-picker-indicator,.wrapper .form-message-item .form-message-field.edit-form-message-field input.form-message-value[type=time]::-webkit-calendar-picker-indicator,.wrapper .form-message-item .form-message-field.edit-form-message-field input.form-message-value[type=number]::-webkit-inner-spin-button{cursor:pointer;width:20px;height:20px;margin-inline-end:-8px}.wrapper .form-message-item .form-message-field.edit-form-message-field .select-wrapper{align-items:center;display:flex;height:44px}.wrapper .form-message-item .form-message-field.edit-form-message-field .select-wrapper.focused{border-color:var(--color-form-input-border-focus);box-shadow:0 0 0 1px var(--color-form-input-border-focus) inset;outline:1px solid rgba(0,0,0,0)}.wrapper .form-message-item .form-message-field.edit-form-message-field .select-wrapper.disabled{opacity:.5;pointer-events:none}.wrapper .form-message-item .form-message-field.edit-form-message-field .select-wrapper.disabled~.field-error{display:none}.wrapper .form-message-item .form-message-field.edit-form-message-field .select-wrapper input{width:calc(100% - 36px);border:none;box-shadow:none !important;outline:1px solid rgba(0,0,0,0);height:40px;margin-inline-start:1px}.wrapper .form-message-item .form-message-field.edit-form-message-field .select-wrapper .select-icon{margin-inline-start:0;color:var(--color-form-input-text)}.wrapper .form-message-item .form-message-field.edit-form-message-field textarea.form-message-value{overflow:auto;padding:11px 12px;resize:none}.wrapper .form-message-item .form-message-field.edit-form-message-field .form-container{display:flex;max-width:max-content}.wrapper .form-message-item .form-message-field.edit-form-message-field .form-container.disabled{cursor:not-allowed;opacity:.5}.wrapper .form-message-item .form-message-field.edit-form-message-field .form-container.disabled+.field-error{display:none}.wrapper .form-message-item .form-message-field.edit-form-message-field .form-container label{display:flex;min-height:36px;align-items:center;padding:7.5px 0;border-bottom:1px solid rgba(0,0,0,0)}.wrapper .form-message-item .form-message-field.edit-form-message-field .form-container .radio-input{margin-inline-end:8px}.wrapper .form-message-item .form-message-field.edit-form-message-field .text-field-container{background-color:var(--color-form-input-background);border-radius:4px;border:1px solid var(--color-form-input-border);display:flex;min-height:44px;flex-direction:row;cursor:text}.wrapper .form-message-item .form-message-field.edit-form-message-field .text-field-container.disabled{opacity:.5;pointer-events:none}.wrapper .form-message-item .form-message-field.edit-form-message-field .text-field-container.disabled~.field-error{display:none}.wrapper .form-message-item .form-message-field.edit-form-message-field .text-field-container:focus{border-color:var(--color-form-input-border-focus);box-shadow:0 0 0 1px var(--color-form-input-border-focus) inset;outline:1px solid rgba(0,0,0,0)}.wrapper .form-message-item .form-message-field.edit-form-message-field .text-field-container .selected-options{padding:0 12px 5px}.wrapper .form-message-item .form-message-field.edit-form-message-field .text-field-container .selected-options:empty{padding-top:5px}.wrapper .form-message-item .form-message-field.edit-form-message-field .text-field-container .selected-options:empty:before{content:attr(data-placeholder)}.wrapper .form-message-item .form-message-field.edit-form-message-field .text-field-container .selected-options .multi-select-option{float:left;line-height:16px;display:flex;align-items:center;cursor:default;border-radius:4px;border:1px solid var(--color-form-input-border);color:var(--color-form-input-text);background-clip:padding-box;font-size:12px;margin-inline-end:6px;margin-top:5px;padding-inline:6px 4px}.wrapper .form-message-item .form-message-field.edit-form-message-field .text-field-container .selected-options .multi-select-option .opt-close{cursor:pointer;height:16px;width:16px}.wrapper .form-message-item .form-message-field.edit-form-message-field .listbox{border:1px solid var(--color-table-separator);border-radius:4px;display:flex;flex-direction:column;margin-top:3px;inset-inline-start:16px;max-width:calc(100% - 32px);min-width:calc(100% - 32px);z-index:3}.wrapper .form-message-item .form-message-field.edit-form-message-field .listbox .filter-message-box{display:flex;flex-direction:column;padding:0 12px}.wrapper .form-message-item .form-message-field.edit-form-message-field .listbox .filter-message-box .filter-message-text{color:var(--color-form-label);font-size:13.75px;height:42px;padding:12px 0;border-bottom:1px solid var(--color-table-separator)}.wrapper .form-message-item .form-message-field.edit-form-message-field .listbox .listbox-search{flex-shrink:0;margin:12px;padding-inline-end:36px}.wrapper .form-message-item .form-message-field.edit-form-message-field .listbox .search-icon-wrapper{position:relative;height:0}.wrapper .form-message-item .form-message-field.edit-form-message-field .listbox .search-icon-wrapper .search-icon{position:absolute;inset-inline-end:21px;bottom:23px}.wrapper .form-message-item .form-message-field.edit-form-message-field .listbox .multi-select-list,.wrapper .form-message-item .form-message-field.edit-form-message-field .listbox .single-select-list{animation:none;display:block;max-height:400px;margin:1px 0 2px 0;overflow-y:auto;padding:8px 0;z-index:3}.wrapper .form-message-item .form-message-field.edit-form-message-field .listbox .multi-select-list li,.wrapper .form-message-item .form-message-field.edit-form-message-field .listbox .single-select-list li{height:auto;margin:0;padding:12px}.wrapper .form-message-item .form-message-field.edit-form-message-field .listbox .multi-select-list li:not(.none).selected,.wrapper .form-message-item .form-message-field.edit-form-message-field .listbox .single-select-list li:not(.none).selected{border-top:1px solid #227e9e;background-color:#e4f1f7}.wrapper .form-message-item .form-message-field.edit-form-message-field .listbox .multi-select-list li:not(.none).selected:last-child,.wrapper .form-message-item .form-message-field.edit-form-message-field .listbox .single-select-list li:not(.none).selected:last-child{box-shadow:inset 0 -1px 0 0 #227e9e}.wrapper .form-message-item .form-message-field.edit-form-message-field .listbox .multi-select-list li:not(.none).selected+li,.wrapper .form-message-item .form-message-field.edit-form-message-field .listbox .single-select-list li:not(.none).selected+li{border-top:1px solid #227e9e}.wrapper .form-message-item .form-message-field.edit-form-message-field .toggle{position:relative;width:36px;height:20px}.wrapper .form-message-item .form-message-field.edit-form-message-field .toggle.disabled+.field-error{display:none}.wrapper .form-message-item .form-message-field.edit-form-message-field .toggle input{display:none}.wrapper .form-message-item .form-message-field.edit-form-message-field .toggle input:disabled+.round-slider{cursor:not-allowed;opacity:.5}.wrapper .form-message-item .form-message-field.edit-form-message-field .toggle input:checked+.round-slider{background-color:#227e9e;border-color:#227e9e}.wrapper .form-message-item .form-message-field.edit-form-message-field .toggle input:checked+.round-slider:before{inset-inline:auto 1px;transition:height .3s cubic-bezier(0, 0, 0.2, 1),width .3s cubic-bezier(0, 0, 0.2, 1),right .3s cubic-bezier(0, 0, 0.2, 1)}.wrapper .form-message-item .form-message-field.edit-form-message-field .toggle .round-slider{position:absolute;cursor:pointer;background-color:#8b8580;transition:background-color .2s linear .1s,opacity .2s linear .1s,border-color .2s linear .1s;border:1px solid rgba(0,0,0,0);border-radius:4px;height:20px;width:36px}.wrapper .form-message-item .form-message-field.edit-form-message-field .toggle .round-slider:before{border-radius:4px;width:16px;height:16px;inset-inline:1px auto;position:absolute;content:"";bottom:1px;background-color:var(--color-form-background);transition:height .3s cubic-bezier(0, 0, 0.2, 1),width .3s cubic-bezier(0, 0, 0.2, 1),left .3s cubic-bezier(0, 0, 0.2, 1)}.wrapper .form-message-item span.field-error{display:flex;margin-top:2px;line-height:16px}.wrapper .form-message-item span.field-error .error-text{color:var(--color-form-error-text);font-size:12px;margin-inline-start:4px}.wrapper .form-message-item span.field-error svg.form-error-icon{position:relative;height:16px;width:16px;fill:var(--color-form-error);flex-shrink:0}.wrapper .form-message-item span.field-error.form-error{padding:8px;background:var(--color-error-message-background);border-radius:4px;margin:10px 0;border:thin dashed var(--color-error-border);width:100%}.wrapper .form-message-item span.field-error.form-error.disabled{display:none}.wrapper .form-message-item span.field-error.form-error svg.form-error-icon{top:0}.wrapper .form-message-item span.field-error.form-error .error-text{font-weight:600;color:var(--color-error-title);margin-inline-start:8px;font-size:14px}.wrapper .form-message-item .form-actions .action-postback,.wrapper .form-message-item .form-message-value .action-postback{background:var(--color-form-actions-background);color:var(--color-form-actions-text);border-color:var(--color-form-actions-border)}.wrapper .form-message-item .form-actions .action-postback:not(:disabled):hover,.wrapper .form-message-item .form-message-value .action-postback:not(:disabled):hover{color:var(--color-form-actions-text-hover);background:var(--color-form-actions-background-hover)}.wrapper .form-message-item .form-actions .action-postback:not(:disabled):hover svg>path,.wrapper .form-message-item .form-message-value .action-postback:not(:disabled):hover svg>path{fill:var(--color-form-actions-text-hover)}.wrapper .form-message-item .form-actions .action-postback:not(:disabled):focus,.wrapper .form-message-item .form-actions .action-postback:not(:disabled):active,.wrapper .form-message-item .form-message-value .action-postback:not(:disabled):focus,.wrapper .form-message-item .form-message-value .action-postback:not(:disabled):active{background:var(--color-form-actions-background-focus);color:var(--color-form-actions-text-focus)}.wrapper .form-message-item .form-actions .action-postback:not(:disabled):focus svg>path,.wrapper .form-message-item .form-actions .action-postback:not(:disabled):active svg>path,.wrapper .form-message-item .form-message-value .action-postback:not(:disabled):focus svg>path,.wrapper .form-message-item .form-message-value .action-postback:not(:disabled):active svg>path{fill:var(--color-form-actions-text-focus)}.wrapper .tableform-message .table-message-row{cursor:pointer}.wrapper .tableform-message .table-message-row:hover{background-color:var(--color-table-row-background-hover)}.wrapper .tableform-message .table-message-row button:hover,.wrapper .tableform-message .table-message-row button:active,.wrapper .tableform-message .table-message-row button:focus{background-color:unset}.wrapper .tableform-message .table-message-headings .table-message-heading:last-child,.wrapper .tableform-message .table-message-row .table-message-item:last-child{min-width:unset;padding:0}.wrapper .tableform-message .table-message-headings .table-message-heading:last-child button,.wrapper .tableform-message .table-message-row .table-message-item:last-child button{margin:0 2px;transition:transform .25s ease-in-out}.wrapper .tableform-message .table-message-headings .table-message-heading:last-child button.rotate-180,.wrapper .tableform-message .table-message-row .table-message-item:last-child button.rotate-180{transform:rotate3d(0, 0, 1, 180deg)}.wrapper .tableform-message .form-message-item{margin:0;padding:16px;transition:all .25s ease-in-out;border-bottom:none}.wrapper .tableform-message .form-message-item:last-child{border-top:1px solid var(--color-table-bottom)}.wrapper .footer-form{width:100%}.wrapper .footer-form .message-bubble-form-message{background:rgba(0,0,0,0);border:none;width:100%}.wrapper .footer-form .message-bubble-form-message .form-message-item{background:rgba(0,0,0,0);padding:0}.wrapper .footer-form .message-bubble-form-message .form-message-item .form-message-key{color:var(--color-footer-form-label)}.wrapper .footer{max-width:100%;padding:0;background-color:var(--color-footer-background);z-index:3;box-shadow:0px -1px 4px 0px rgba(0,0,0,.1019607843);border-top:1px solid rgba(22,21,19,.1)}.wrapper .footer .footer-mode-keyboard{margin:5px;background-color:var(--color-input-background);color:var(--color-input-text);border:1px solid var(--color-input-border);border-radius:6px}.wrapper .footer .footer-mode-voice{height:60px;padding:14px 0;background:var(--color-visualizer-container-background);justify-content:center}.wrapper .footer .footer-mode-voice .footer-visualizer-wrapper{max-width:296px;height:32px}.wrapper .footer .footer-logo{flex:0 0 auto;max-width:100px;max-height:36px;overflow:hidden;padding:0}.wrapper .footer.mode-keyboard .button-switch-kbd{display:none}.wrapper .footer.mode-keyboard .footer-mode-voice{display:none}.wrapper .footer.mode-voice .button-switch-voice{display:none}.wrapper .user-input{flex-grow:1;min-height:44px;padding:14px 4px 14px 10px;margin:0;font-size:13.75px;font-family:inherit;text-align:start;line-height:16px;outline:1px solid rgba(0,0,0,0);resize:none;border:none;background-color:rgba(0,0,0,0);color:var(--color-input-text)}.wrapper .user-input:focus,.wrapper .user-input:focus-visible{outline:1px solid rgba(22,21,19,0)}.wrapper .footer-actions{margin-inline-end:2px}.wrapper .footer-button.button-send{background-color:var(--color-footer-button-fill);border-radius:50%}.wrapper .footer-button.button-send svg>path{fill:var(--color-input-background)}.wrapper .footer-button.button-send:not(:disabled):hover{background-color:var(--color-footer-button-fill-hover)}.wrapper .footer-button.button-send:not(:disabled):hover svg>path{fill:var(--color-input-background)}.wrapper .footer-button svg>path{fill:var(--color-footer-button-fill)}.wrapper .footer-button:not(:disabled):hover{background-color:var(--color-footer-button-background-hover)}.wrapper .footer-button:not(:disabled):hover svg>path{fill:var(--color-footer-button-fill-hover)}.wrapper .autocomplete-items{position:absolute;bottom:56px;width:100%;max-height:calc(100% - 56px);overflow-y:auto;background-color:var(--color-input-background);box-shadow:0px -1px 4px 0px rgba(0,0,0,.1019607843);margin:0 -5px}.wrapper .autocomplete-items .autocomplete-item{min-height:40px;padding:8px 16px;cursor:pointer}.wrapper .autocomplete-items .autocomplete-item:hover,.wrapper .autocomplete-items .autocomplete-item.autocomplete-active{background-color:var(--color-card-nav-button-hover)}.wrapper .autocomplete-items .autocomplete-item:first-of-type{margin-top:8px}.wrapper .autocomplete-items .autocomplete-item:last-of-type{margin-bottom:8px}.wrapper .autocomplete-items .autocomplete-item strong{font-weight:700}.wrapper.embedded .open{width:100%;height:100%}.wrapper.embedded .open .widget{border-radius:0;width:100%;min-width:100%;max-width:100%;height:100%;position:inherit;box-shadow:none;max-height:unset}.wrapper.popup-content-wrapper{background:rgba(22,21,19,.4);width:100vw;height:100vh;position:fixed;z-index:10000;top:0 !important;left:0 !important;display:flex;align-items:center;justify-content:center}.wrapper.popup-content-wrapper .popup-dialog{overflow:hidden;max-width:600px;border-radius:6px;box-shadow:0px 6px 12px 0px rgba(0,0,0,.2);max-height:calc(100vh - 16px)}.wrapper.popup-content-wrapper .popup-dialog .popup-header{justify-content:flex-end;background-color:#fff;height:56px;padding:0 8px}.wrapper.popup-content-wrapper .popup-dialog .message-bubble{width:auto;padding:32px;margin-top:0;border-radius:0;overflow:auto;max-height:calc(100vh - 16px)}.wrapper.popup-content-wrapper .popup-dialog .message-bubble:last-child{border-radius:0}.wrapper.popup-content-wrapper .popup-dialog .message-bubble.message-header{display:none}.wrapper.popup-content-wrapper .popup-dialog .message-bubble.message-bubble-form-message{padding:0}.wrapper.popup-content-wrapper .popup-dialog .message-bubble.message-bubble-form-message:last-child .form-message-header{border-radius:0}.wrapper.popup-content-wrapper .popup-dialog .message-bubble.message-bubble-form-message:last-child .form-message-item{border-radius:0}.wrapper.popup-content-wrapper .popup-dialog .message-bubble.message-bubble-form-message .form-message-header{padding:32px 32px 12px;border-radius:0;justify-content:space-between}.wrapper.popup-content-wrapper .popup-dialog .message-bubble.message-bubble-form-message .form-message-item{padding:0 32px 32px;border-radius:0}.wrapper .full-screen-modal{position:fixed;top:0;left:0;width:100%;height:100vh;z-index:1000000;background-color:rgba(0,0,0,.8)}.wrapper .modal-header{background:linear-gradient(180deg, rgba(0, 0, 0, 0.5), transparent);color:#fff;display:flex;justify-content:space-between;position:relative;padding:10px 20px;z-index:1000001}.wrapper .modal-header .close-btn{border:none;background:rgba(0,0,0,0);cursor:pointer}.wrapper .full-screen-image{position:absolute;max-width:100vw;max-height:100vh;margin:auto;top:0;bottom:0;left:0;right:0}.wrapper .typing-cue-wrapper{width:32px;margin:auto;display:flex}.wrapper .typing-cue-wrapper .typing-cue{position:relative;left:0;right:0;margin:auto;width:8px;height:8px;border-radius:50%;background-color:var(--color-typing-indicator);animation:typing-cue 1550ms infinite linear alternate;animation-delay:250ms;opacity:.1}.wrapper .typing-cue-wrapper .typing-cue::before,.wrapper .typing-cue-wrapper .typing-cue::after{content:"";display:inline-block;position:absolute;width:8px;height:8px;border-radius:50%;background-color:var(--color-typing-indicator);animation:typing-cue 1550ms infinite linear alternate;opacity:.1}.wrapper .typing-cue-wrapper .typing-cue::before{left:-12px;animation-delay:0s}.wrapper .typing-cue-wrapper .typing-cue::after{left:12px;animation-delay:500ms}.wrapper .hidden{border:0;clip:rect(0 0 0 0);height:1px;margin:-1px;overflow:hidden;padding:0;position:absolute;width:1px}.wrapper .rating-root{display:flex}.wrapper [dir=rtl] .rating-root{flex-direction:row-reverse}.wrapper .rating-wrapper{display:flex;margin-top:8px}.wrapper [dir=rtl] .rating-wrapper{flex-direction:row-reverse}.wrapper .rating-hidden{border:0;clip:rect(0 0 0 0);height:1px;margin:-1px;overflow:hidden;padding:0;position:absolute;width:1px}.wrapper .star-label{background-color:rgba(0,0,0,0);border:0;cursor:pointer;padding:0}.wrapper .star-label>svg>path{fill:var(--color-rating-star)}.wrapper .star-input.active+label>svg>path{fill:var(--color-rating-star-fill)}.wrapper .star-input:disabled+.star-label{cursor:not-allowed;filter:brightness(0.8)}.wrapper .rating-star-icon{height:32px;width:32px}.wrapper.expanded .widget:not(.drag){animation:scale-in-br .25s cubic-bezier(0.25, 0.46, 0.45, 0.94) .2s both}.wrapper.expanded .widget.sidepanel{animation:unset}.wrapper.expanded .widget .resizable{width:4px;height:100%;top:0;left:0;background-color:rgba(0,0,0,0);position:absolute;z-index:10000;cursor:col-resize}.wrapper.expanded .widget .resizable.right-resize{right:0;left:unset}.wrapper.expanded .widget .resizable.top-resize{width:100%;height:4px;cursor:row-resize}.wrapper.expanded .widget .resizable.corner{height:8px;width:8px;cursor:nwse-resize}.wrapper.expanded .widget .resizable.corner.right-resize{cursor:nesw-resize}.wrapper.expanded:not(.pos-left) .right-resize{display:none}.wrapper.expanded .button:not(.drag){animation:scale-out-center .25s cubic-bezier(0.55, 0.085, 0.68, 0.53) forwards}.wrapper.collapsed .widget:not(.drag){animation:scale-out-br .25s cubic-bezier(0.55, 0.085, 0.68, 0.53) forwards}.wrapper.collapsed .widget.sidepanel{animation:unset}.wrapper.collapsed .notification-badge{background-color:var(--color-notification-badge-background);color:var(--color-notification-badge-text);right:-5px;top:-5px;align-items:center;border-radius:24px;display:flex;font-size:14px;height:24px;justify-content:center;position:absolute;text-align:center;width:32px}.wrapper.collapsed .button:not(.drag){animation:scale-in-center .25s cubic-bezier(0.25, 0.46, 0.45, 0.94) .2s both}.wrapper.pos-left .widget{right:unset;left:calc(var(--position-left)*-1);max-width:100vw}.wrapper.pos-left.expanded .widget:not(.drag){animation:scale-in-bl .25s cubic-bezier(0.25, 0.46, 0.45, 0.94) .2s both}.wrapper.pos-left.expanded .widget .left-resize{display:none}.wrapper.pos-left.collapsed .widget{animation:scale-out-bl .25s cubic-bezier(0.55, 0.085, 0.68, 0.53) forwards}.wrapper .ellipsis{display:inline-block;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;max-width:100%}.wrapper .popup{position:absolute;background-color:var(--color-popup-background);color:var(--color-popup-text);min-width:140px;max-height:calc(100% - 128px);display:none;padding:4px 0;border-radius:6px;box-shadow:rgba(0,0,0,.16) 0px 4px 8px 0px;overflow-y:auto;z-index:5}.wrapper .popup li{display:flex;align-items:center;height:48px;margin:4px 0;cursor:pointer;overflow:hidden;color:var(--color-popup-button-text)}.wrapper .popup li svg>path{fill:var(--color-popup-text)}.wrapper .popup li#action-menu-option-lang{border-top:1px solid var(--color-popup-horizontal-rule)}.wrapper .popup li.disable{pointer-events:none;cursor:not-allowed;opacity:.5}.wrapper .popup li:focus{outline:1px dotted var(--color-actions-outline-focus);outline-offset:1px}.wrapper .popup li:hover,.wrapper .popup li:focus,.wrapper .popup li.active{background-color:var(--color-popup-item-background-hover)}.wrapper .popup li .icon{margin-inline-start:16px;height:20px;width:20px}.wrapper .popup li .text{padding:0 16px 0 16px}.wrapper .popup.expand{display:block;-webkit-animation:scale-in-br .25s cubic-bezier(0.25, 0.46, 0.45, 0.94) .2s both;animation:scale-in-br .25s cubic-bezier(0.25, 0.46, 0.45, 0.94) .2s both}.wrapper .popup.action-menu,.wrapper .popup.language-selection-menu{top:50px;bottom:unset}.wrapper .popup.action-menu.expand,.wrapper .popup.language-selection-menu.expand{display:block;-webkit-animation:scale-in-tr .25s cubic-bezier(0.25, 0.46, 0.45, 0.94) .2s both;animation:scale-in-tr .25s cubic-bezier(0.25, 0.46, 0.45, 0.94) .2s both}.wrapper .popup.language-selection-menu{max-height:calc(100% - 280px)}.wrapper .popup.share-popup-list{bottom:50px;left:unset}.wrapper .spinner{height:48px;width:48px}.wrapper .spinner svg{animation-duration:750ms;-webkit-animation:spin 1s linear infinite;animation:spin 1s linear infinite}.wrapper .spinner svg circle{fill:rgba(0,0,0,0);stroke:var(--color-user-text);stroke-width:2px;stroke-dasharray:128px;stroke-dashoffset:82px}.wrapper .webview-container{position:absolute;width:100%;height:80%;bottom:0;box-shadow:0px -4px 32px rgba(0,0,0,.1);z-index:10}.wrapper .webview-container .webview-header svg{fill:var(--color-actions-text)}.wrapper .webview-container .webview-header button{color:var(--color-actions-text)}.wrapper .webview-container .spinner{position:absolute;margin:auto;left:0;right:0;top:40%}.wrapper .webview-container iframe{width:100%;height:100%;background:var(--color-conversation-background);border:none}.wrapper .webview-container .webview-error{position:absolute;bottom:0;background:var(--color-popup-background);width:calc(100% - 32px);margin:10px 16px;padding:6px 16px;border-radius:6px;display:flex;align-items:center;box-shadow:0px -4px 32px rgba(0,0,0,.1)}.wrapper .webview-container .webview-error .webview-error-button-close{border:none}.wrapper .webview-container.webview-container-close{animation:oda-chat-webview-slide-out-bottom .4s cubic-bezier(0.55, 0.085, 0.68, 0.53) both}.wrapper .webview-container.webview-container-open{animation:oda-chat-webview-slide-in-bottom .4s cubic-bezier(0.25, 0.46, 0.45, 0.94) both}.widget{position:absolute;bottom:calc(var(--position-bottom)*-1);border-radius:6px 6px 0 0;box-shadow:0px -4px 32px rgba(0,0,0,.1);right:calc(var(--position-right)*-1);width:100vw;min-width:100vw;max-width:100vw;max-height:var(--widget-max-height);margin:0;overflow:hidden;text-decoration:none;text-transform:none;z-index:10000;align-items:stretch;background:var(--color-conversation-background)}.widget.large-size{--bubble-max-width: 780px}.wrapper .widget.large-size{font-size:18px;line-height:24px}.wrapper .widget.large-size .card{padding:24px}.wrapper .widget.large-size .card .card-content{margin-bottom:24px}.wrapper .widget.large-size .card .card-image{margin:-24px -24px 10px;width:calc(100% + 48px)}.wrapper .widget.large-size .message-bubble{line-height:24px;padding:16px 24px}.wrapper .widget.large-size .attachment .attachment-placeholder{margin:-16px -24px 0;max-width:calc(100% + 48px)}.wrapper .widget.large-size .attachment .attachment-footer{margin:0 -24px -16px}.wrapper .widget.large-size button:not(.icon){height:44px}.wrapper .widget.large-size .footer{border-radius:20px 20px 0 0;margin:0 24px;overflow:hidden}.wrapper .widget.large-size .footer.left{margin-inline-start:68px}.wrapper .widget.large-size .footer.right{margin-inline-end:68px}.wrapper .widget.large-size .footer-actions{margin-inline-end:10px}.wrapper .widget.large-size .user-input{font-size:18px;line-height:24px;min-height:60px;padding:18px 12px 18px 18px}.wrapper .widget.medium-size{font-size:16px;line-height:20px}.wrapper .widget.medium-size .card{padding:16px}.wrapper .widget.medium-size .card .card-content{margin-bottom:16px}.wrapper .widget.medium-size .card .card-image{margin-top:-16px}.wrapper .widget.medium-size .message-bubble{line-height:20px;padding:8px 16px}.wrapper .widget.medium-size .attachment .attachment-placeholder{margin:-8px -16px 0}.wrapper .widget.medium-size .attachment .attachment-footer{margin:0 -16px -8px}.wrapper .widget.medium-size .footer{border-radius:20px 20px 0 0;margin:0 24px;overflow:hidden}.wrapper .widget.medium-size .user-input{font-size:16px;line-height:20px;min-height:60px;padding:20px 12px 20px 10px}.wrapper .widget.large-size .icon-wrapper,.wrapper .widget.medium-size .icon-wrapper{height:36px;width:36px;min-height:36px;min-width:36px}.wrapper .widget.large-size .message.card-message-horizontal,.wrapper .widget.medium-size .message.card-message-horizontal{margin-inline-start:-24px}.wrapper .widget.large-size .message.card-message-horizontal .message-header,.wrapper .widget.large-size .message.card-message-horizontal .message-footer,.wrapper .widget.large-size .message.card-message-horizontal .message-global-actions,.wrapper .widget.medium-size .message.card-message-horizontal .message-header,.wrapper .widget.medium-size .message.card-message-horizontal .message-footer,.wrapper .widget.medium-size .message.card-message-horizontal .message-global-actions{margin-inline-start:24px;max-width:calc(.9*(100% - 36px))}.wrapper .widget.large-size .message.card-message-horizontal .card-message-cards,.wrapper .widget.medium-size .message.card-message-horizontal .card-message-cards{padding-inline-start:24px}.wrapper .widget.large-size .card,.wrapper .widget.medium-size .card{width:344px}.wrapper .widget.large-size .conversation,.wrapper .widget.medium-size .conversation{padding:16px 24px}.wrapper .widget.large-size .conversation .conversation-pane.bot-icon .message.card-message-horizontal,.wrapper .widget.medium-size .conversation .conversation-pane.bot-icon .message.card-message-horizontal{margin-inline-start:-68px}.wrapper .widget.large-size .conversation .conversation-pane.bot-icon .message.card-message-horizontal .message-header,.wrapper .widget.large-size .conversation .conversation-pane.bot-icon .message.card-message-horizontal .message-footer,.wrapper .widget.large-size .conversation .conversation-pane.bot-icon .message.card-message-horizontal .message-global-actions,.wrapper .widget.medium-size .conversation .conversation-pane.bot-icon .message.card-message-horizontal .message-header,.wrapper .widget.medium-size .conversation .conversation-pane.bot-icon .message.card-message-horizontal .message-footer,.wrapper .widget.medium-size .conversation .conversation-pane.bot-icon .message.card-message-horizontal .message-global-actions{margin-inline-start:68px}.wrapper .widget.large-size .conversation .conversation-pane.bot-icon .message.card-message-horizontal .card-message-content .card-message-cards,.wrapper .widget.medium-size .conversation .conversation-pane.bot-icon .message.card-message-horizontal .card-message-content .card-message-cards{padding-inline-start:68px}.wrapper .widget.large-size .conversation .conversation-pane.bot-icon .relative-timestamp.left,.wrapper .widget.medium-size .conversation .conversation-pane.bot-icon .relative-timestamp.left{margin-inline-start:44px}.wrapper .widget.large-size .conversation .conversation-pane.user-icon .relative-timestamp.right,.wrapper .widget.medium-size .conversation .conversation-pane.user-icon .relative-timestamp.right{margin-inline-end:44px}.wrapper .widget.large-size .conversation .conversation-pane.bot-icon .message-block .messages-wrapper,.wrapper .widget.large-size .conversation .conversation-pane.user-icon .message-block .messages-wrapper,.wrapper .widget.medium-size .conversation .conversation-pane.bot-icon .message-block .messages-wrapper,.wrapper .widget.medium-size .conversation .conversation-pane.user-icon .message-block .messages-wrapper{max-width:min(var(--bubble-max-width),.9*(100% - 44px))}.wrapper .widget.large-size .conversation .conversation-pane.bot-icon .message-block .messages-wrapper .message.card-message-horizontal .message-header,.wrapper .widget.large-size .conversation .conversation-pane.bot-icon .message-block .messages-wrapper .message.card-message-horizontal .message-footer,.wrapper .widget.large-size .conversation .conversation-pane.bot-icon .message-block .messages-wrapper .message.card-message-horizontal .message-global-actions,.wrapper .widget.large-size .conversation .conversation-pane.user-icon .message-block .messages-wrapper .message.card-message-horizontal .message-header,.wrapper .widget.large-size .conversation .conversation-pane.user-icon .message-block .messages-wrapper .message.card-message-horizontal .message-footer,.wrapper .widget.large-size .conversation .conversation-pane.user-icon .message-block .messages-wrapper .message.card-message-horizontal .message-global-actions,.wrapper .widget.medium-size .conversation .conversation-pane.bot-icon .message-block .messages-wrapper .message.card-message-horizontal .message-header,.wrapper .widget.medium-size .conversation .conversation-pane.bot-icon .message-block .messages-wrapper .message.card-message-horizontal .message-footer,.wrapper .widget.medium-size .conversation .conversation-pane.bot-icon .message-block .messages-wrapper .message.card-message-horizontal .message-global-actions,.wrapper .widget.medium-size .conversation .conversation-pane.user-icon .message-block .messages-wrapper .message.card-message-horizontal .message-header,.wrapper .widget.medium-size .conversation .conversation-pane.user-icon .message-block .messages-wrapper .message.card-message-horizontal .message-footer,.wrapper .widget.medium-size .conversation .conversation-pane.user-icon .message-block .messages-wrapper .message.card-message-horizontal .message-global-actions{max-width:min(var(--bubble-max-width),.9*(100% - 92px))}.wrapper .widget.large-size .conversation .conversation-pane.user-icon.bot-icon .message-block .messages-wrapper,.wrapper .widget.medium-size .conversation .conversation-pane.user-icon.bot-icon .message-block .messages-wrapper{max-width:min(var(--bubble-max-width),.9*(100% - 88px))}.wrapper .widget.large-size .conversation .conversation-pane.user-icon.bot-icon .message-block .messages-wrapper .message.card-message-horizontal .message-header,.wrapper .widget.large-size .conversation .conversation-pane.user-icon.bot-icon .message-block .messages-wrapper .message.card-message-horizontal .message-footer,.wrapper .widget.large-size .conversation .conversation-pane.user-icon.bot-icon .message-block .messages-wrapper .message.card-message-horizontal .message-global-actions,.wrapper .widget.medium-size .conversation .conversation-pane.user-icon.bot-icon .message-block .messages-wrapper .message.card-message-horizontal .message-header,.wrapper .widget.medium-size .conversation .conversation-pane.user-icon.bot-icon .message-block .messages-wrapper .message.card-message-horizontal .message-footer,.wrapper .widget.medium-size .conversation .conversation-pane.user-icon.bot-icon .message-block .messages-wrapper .message.card-message-horizontal .message-global-actions{max-width:min(var(--bubble-max-width),.9*(100% - 136px))}.wrapper .widget.large-size .message-bubble-tabular-message,.wrapper .widget.large-size .message-bubble-form-message,.wrapper .widget.medium-size .message-bubble-tabular-message,.wrapper .widget.medium-size .message-bubble-form-message{padding:0}.widget .alert-wrapper{position:absolute;top:48px;width:100%}.widget .alert-wrapper .alert-prompt{position:relative;left:0;right:0;width:auto;margin:6px;padding:10px;border-radius:10px;z-index:11}.widget .msg-icon{padding:5px 10px 0 0}.widget .msg{flex-grow:1}.sidepanel-content-wrapper{display:flex;width:100vw}.sidepanel-content-wrapper>*{flex-grow:1}.sidepanel-content-wrapper .wrapper:not(.contextual-widget){position:absolute;bottom:0;right:0;height:100vh;flex-grow:unset;width:0;min-width:0;max-width:0;flex-shrink:0;--width-full-screen: 375px}.sidepanel-content-wrapper .wrapper:not(.contextual-widget).expanded{min-width:100vw;max-width:100vw}.sidepanel-content-wrapper .wrapper:not(.contextual-widget).expanded::after{content:"";background-color:rgba(0,0,0,0);position:absolute;top:0;left:0;width:4px;height:100%;cursor:col-resize;z-index:10000}.sidepanel-content-wrapper .wrapper:not(.contextual-widget).expanded.drag{transition:unset}.sidepanel-content-wrapper .wrapper:not(.contextual-widget).expanded.drag::after{background-color:#ccc}.sidepanel-content-wrapper .widget{position:relative;bottom:0;right:0;left:0;top:0;width:100%;min-width:unset;max-width:unset;height:100%;max-height:100%;box-shadow:none;border-radius:0}.contextual-widget-wrapper{position:relative}.contextual-widget-wrapper .widget-wrapper{position:sticky;height:0;z-index:1;top:8px;max-width:100%}.contextual-widget-wrapper .widget-wrapper .container{position:absolute;right:-44px}.contextual-widget-wrapper .widget-wrapper .container .contextual-widget{position:relative;width:272px;border-radius:6px;background-color:#f5f4f2;box-shadow:0px 6px 12px 0px rgba(0,0,0,.2)}.contextual-widget-wrapper .widget-wrapper .container .contextual-widget.minimum-size{width:36px;box-shadow:0px 1px 4px 0px rgba(0,0,0,.1215686275);border-radius:4px}.contextual-widget-wrapper .widget-wrapper .container .contextual-widget.minimum-size.no-feedback>:first-child{border-bottom:none}.contextual-widget-wrapper .widget-wrapper .container .contextual-widget.minimum-size.no-feedback>:not(:first-child){display:none}.contextual-widget-wrapper .widget-wrapper .container .contextual-widget.minimum-size>:not(:last-child){border-bottom:1px solid rgba(22,21,19,.1215686275)}.contextual-widget-wrapper .widget-wrapper .container .contextual-widget.minimum-size button{background:#f5f4f2;margin-inline-start:0;border-radius:0}.contextual-widget-wrapper .widget-wrapper .container .contextual-widget.full-size{width:416px;display:block}.contextual-widget-wrapper .widget-wrapper .container .contextual-widget.full-size .conversation .message-wrapper{border-bottom:1px solid rgba(22,21,19,.1215686275)}.contextual-widget-wrapper .widget-wrapper .container .contextual-widget.full-size .footer.enabled{display:block}.contextual-widget-wrapper .widget-wrapper .container .contextual-widget:not(.full-size) .message-actions>:only-child,.contextual-widget-wrapper .widget-wrapper .container .contextual-widget:not(.full-size) .message-actions>:nth-child(2){border:none}.contextual-widget-wrapper .widget-wrapper .container .contextual-widget .header{height:44px;background:#f5f4f2;padding:8px 12px 0}.contextual-widget-wrapper .widget-wrapper .container .contextual-widget .header .logo{height:16px;width:16px}.contextual-widget-wrapper .widget-wrapper .container .contextual-widget .header .title{height:16px;font-weight:400;font-size:12px;line-height:16px;color:rgba(22,21,19,.6980392157)}.contextual-widget-wrapper .widget-wrapper .container .contextual-widget .error-message{display:flex;height:76px;border-radius:6px;border:1px solid rgba(22,21,19,.1215686275);margin:0 12px 12px;background:#fef9f2;padding:8px}.contextual-widget-wrapper .widget-wrapper .container .contextual-widget .error-message .error-icon{height:18px;margin:8px;padding-top:2px;width:16px}.contextual-widget-wrapper .widget-wrapper .container .contextual-widget .error-message .error-info{margin:8px 0}.contextual-widget-wrapper .widget-wrapper .container .contextual-widget .error-message .error-info .error-text{color:#8f520a;line-height:20px;font-weight:700}.contextual-widget-wrapper .widget-wrapper .container .contextual-widget .error-message .error-info .reset-button{cursor:pointer;line-height:16px;font-size:13.75px;font-weight:600;margin-top:8px;color:#161513}.contextual-widget-wrapper .widget-wrapper .container .contextual-widget .message-global-actions{margin-top:0px;padding:12px 12px 4px;background:#fff}.contextual-widget-wrapper .widget-wrapper .container .contextual-widget .message-global-actions button.action-postback{height:auto}.contextual-widget-wrapper .widget-wrapper .container .contextual-widget .message-wrapper{padding:0 12px 0}.contextual-widget-wrapper .widget-wrapper .container .contextual-widget .message-wrapper .message-actions{margin-top:0;margin-bottom:4px;padding:0}.contextual-widget-wrapper .widget-wrapper .container .contextual-widget .message-wrapper .message-actions .action-postback{background:rgba(0,0,0,0)}.contextual-widget-wrapper .widget-wrapper .container .contextual-widget .message-bubble{font-size:13.75px;line-height:16px;margin-top:0;margin-bottom:0;background:rgba(0,0,0,0);border-radius:0;min-height:unset;padding:0 !important}.contextual-widget-wrapper .widget-wrapper .container .contextual-widget .message-bubble .message-text{margin-bottom:12px}.contextual-widget-wrapper .widget-wrapper .container .contextual-widget .footer,.contextual-widget-wrapper .widget-wrapper .container .contextual-widget .footer-form{display:none}.contextual-widget-wrapper .widget-wrapper .container .generate-spinner{background-color:#f5f4f2;box-sizing:border-box;width:154px;height:52px;padding:8px 12px;border-radius:6px;box-shadow:0px 6px 12px 0px rgba(0,0,0,.2);position:sticky;top:8px;bottom:8px;z-index:1;display:flex;align-items:center}.contextual-widget-wrapper .widget-wrapper .container .generate-spinner .generate-icon{height:16px;width:16px}.contextual-widget-wrapper .widget-wrapper .container .generate-spinner .generate-icon.spin{-webkit-animation:spin 1s linear infinite;animation:spin 1s linear infinite}.contextual-widget-wrapper .widget-wrapper .container .generate-spinner .generate-text{width:70px;height:16px;font-size:12px;line-height:16px;color:rgba(22,21,19,.6980392157)}.contextual-widget-wrapper .widget-wrapper .container .generate-spinner .close-button{border:rgba(0,0,0,0);cursor:pointer;background:#f5f4f2;width:36px;height:36px;padding:8px}.contextual-widget-wrapper .widget-wrapper .container .generate-spinner>:not(:last-child){margin-inline-end:4px}.contextual-widget-wrapper .widget-wrapper .widget{position:relative;bottom:0;right:0;left:0;top:0;width:100%;height:100%;border-radius:6px}.search-bar-widget-wrapper{position:relative;height:100%;min-height:40px}.search-bar-widget-wrapper .dialog-wrapper{position:relative}.search-bar-widget-wrapper .dialog-wrapper .dialog{position:relative}.search-bar-widget-wrapper .footer{border:none;box-shadow:none;background:rgba(0,0,0,0);height:100%}.search-bar-widget-wrapper .footer.mode-voice+.search-bar-widget .search-bar-popup{display:none}.search-bar-widget-wrapper .footer .footer-mode-keyboard{min-height:unset;margin:0;border:0;background:rgba(0,0,0,0);height:100%;top:0;position:absolute;width:100%}.search-bar-widget-wrapper .footer .footer-mode-voice{position:absolute;left:0;right:0;top:calc(100% + 2px);border:1px solid rgba(22,21,19,.12)}.search-bar-widget-wrapper .footer .user-input{height:100%;min-height:unset;padding:4px;line-height:unset}.search-bar-widget-wrapper .footer .footer-actions{height:100%}.search-bar-widget-wrapper .footer .footer-actions .share-popup-list{max-height:unset;bottom:unset;animation:none}.search-bar-widget-wrapper .autocomplete-items{max-height:unset;top:56px;bottom:unset}.search-bar-widget-wrapper .search-bar-widget{position:absolute;bottom:0;height:0;width:100%}.search-bar-widget-wrapper .search-bar-widget .search-bar-widget-content{position:relative;top:4px;background:#fff;height:0}.search-bar-widget-wrapper .search-bar-widget .search-bar-widget-content .search-bar-popup{position:absolute;min-width:100%;width:100%;max-width:100%;border-radius:6.06px;border:2px solid #000;background:#fff;padding:8px;display:flex;flex-direction:column;box-shadow:0 12px 20px rgba(0,0,0,.2784313725);max-height:400px;overflow:auto;--color-conversation-background: #fff}.search-bar-widget-wrapper .search-bar-widget .search-bar-widget-content .search-bar-popup:empty{display:none !important}.search-bar-widget-wrapper .search-bar-widget .search-bar-widget-content .search-bar-popup .user-message{font-weight:bold}.search-bar-widget-wrapper .search-bar-widget .search-bar-widget-content .search-bar-popup .message{max-width:100%}.search-bar-widget-wrapper .search-bar-widget .search-bar-widget-content .search-bar-popup .message.card-message-horizontal{margin-inline:0;width:100vw}.search-bar-widget-wrapper .search-bar-widget .search-bar-widget-content .search-bar-popup .message-bubble-tabular-message,.search-bar-widget-wrapper .search-bar-widget .search-bar-widget-content .search-bar-popup .message-bubble-form-message{width:100%}.image-preview-wrapper{background:rgba(0,0,0,.8);height:100%;position:fixed;top:0;left:0;width:100%;z-index:10000}.image-preview-wrapper .image-preview-header{align-items:center;background:linear-gradient(180deg, rgba(0, 0, 0, 0.5), transparent);color:#fff;display:flex;justify-content:space-between;position:relative;padding:10px 20px;z-index:1000001}.image-preview-wrapper .image-preview-header .image-preview-close{background:rgba(0,0,0,0);border:none;cursor:pointer;height:36px;width:36px}.image-preview-wrapper .image-preview-header .image-preview-close .image-preview-close-icon{fill:#fff;height:100%;width:100%}.image-preview-wrapper .image-preview{bottom:0;left:0;margin:auto;max-height:100vh;max-width:100vw;position:absolute;right:0;top:0}.arrow-icon{margin-inline-end:2px;width:32px;height:32px;display:flex;align-items:center;flex-shrink:0}@media screen and (min-width: 426px){.wrapper.pos-left .widget{left:0}.wrapper:not(.embedded) .widget:not(.sidepanel){max-width:calc(100vw - var(--position-right))}.wrapper:not(.embedded).pos-left .widget:not(.sidepanel){max-width:calc(100vw - var(--position-left))}.widget:not(.sidepanel){width:var(--width-full-screen);min-width:unset;max-height:var(--widget-max-height);bottom:0;right:0}.sidepanel-content-wrapper .wrapper.wrapper:not(.contextual-widget){position:sticky;top:0}.sidepanel-content-wrapper .wrapper.wrapper:not(.contextual-widget).expanded{min-width:375px;max-width:800px}.sidepanel-content-wrapper .wrapper.wrapper:not(.contextual-widget) .widget{border-left:thin solid #ccc}}@media(prefers-reduced-motion){.open{animation:none}.close{animation:none}}[dir=rtl] .wrapper *{direction:rtl}[dir=rtl] .multi-select-option{float:right !important}[dir=rtl] .wrapper{text-align:right}[dir=rtl] .wrapper .widget.open{animation:scale-in-bl .25s cubic-bezier(0.25, 0.46, 0.45, 0.94) .2s both}[dir=rtl] .wrapper .widget.close{animation:scale-out-bl .25s cubic-bezier(0.55, 0.085, 0.68, 0.53) forwards}[dir=rtl] .wrapper .message-bubble{border-radius:10px 2px 2px 10px}[dir=rtl] .wrapper .message-block .message:last-child .message-bubble:last-child{border-radius:10px 2px 10px 10px}[dir=rtl] .wrapper .message-block.right .messages-wrapper .message .message-bubble{border-radius:2px 10px 10px 2px}[dir=rtl] .wrapper .message-block.right .messages-wrapper .message:last-child .message-bubble:last-child{border-radius:2px 10px 10px 10px}[dir=rtl] .wrapper .button{left:0;right:unset}[dir=rtl] .wrapper .popup.expand{-webkit-animation:scale-in-bl .25s cubic-bezier(0.25, 0.46, 0.45, 0.94) .2s both;animation:scale-in-bl .25s cubic-bezier(0.25, 0.46, 0.45, 0.94) .2s both}[dir=rtl] .wrapper .popup.action-menu.expand,[dir=rtl] .wrapper .popup.language-selection-menu.expand{-webkit-animation:scale-in-tl .25s cubic-bezier(0.25, 0.46, 0.45, 0.94) .2s both;animation:scale-in-tl .25s cubic-bezier(0.25, 0.46, 0.45, 0.94) .2s both}';
        },
        5565: function (e, t, s) {
          var i =
              (this && this.t) ||
              (Object.create
                ? function (e, t, s, i) {
                    void 0 === i && (i = s);
                    var o = Object.getOwnPropertyDescriptor(t, s);
                    (o &&
                      !("get" in o ? !t.p : o.writable || o.configurable)) ||
                      (o = {
                        enumerable: !0,
                        get: function () {
                          return t[s];
                        },
                      }),
                      Object.defineProperty(e, i, o);
                  }
                : function (e, t, s, i) {
                    void 0 === i && (i = s), (e[i] = t[s]);
                  }),
            o =
              (this && this.u) ||
              function (e, t) {
                for (var s in e)
                  "default" === s ||
                    Object.prototype.hasOwnProperty.call(t, s) ||
                    i(t, e, s);
              };
          Object.defineProperty(t, "p", { value: !0 }),
            o(s(833), t),
            o(s(3693), t);
        },
        833: (e, t) => {
          Object.defineProperty(t, "p", { value: !0 }),
            (t.UserAudioEvent = void 0);
          t.UserAudioEvent = {
            AudioData: "uae:audiodata",
            AnalyserData: "uae:analyserdata",
          };
        },
        3693: function (e, t, s) {
          var i =
            (this && this.v) ||
            function (e, t, s, i) {
              return new (s || (s = Promise))(function (o, r) {
                function a(e) {
                  try {
                    c(i.next(e));
                  } catch (e) {
                    r(e);
                  }
                }
                function n(e) {
                  try {
                    c(i.throw(e));
                  } catch (e) {
                    r(e);
                  }
                }
                function c(e) {
                  var t;
                  e.done
                    ? o(e.value)
                    : ((t = e.value),
                      t instanceof s
                        ? t
                        : new s(function (e) {
                            e(t);
                          })).then(a, n);
                }
                c((i = i.apply(e, t || [])).next());
              });
            };
          Object.defineProperty(t, "p", { value: !0 }),
            (t.UserAudioProviderService = void 0);
          const o = s(6064),
            r = s(7262),
            a = s(833),
            n = s(7585);
          class c {
            static getInstance() {
              return this.xh || (this.xh = new c()), this.xh;
            }
            constructor() {
              (this.kh = (0, n.createAudioWorklet)(l)),
                (this.$ = !1),
                (this.yh = new Float32Array(p)),
                (this._h = 0),
                (this.Oh = !0),
                (this.Mh = new Float32Array(0)),
                (this.jh = (0, o.generateEventDispatcher)()),
                (this.zh = (e) => {
                  this.$h && (this.$h.resolve(), (this.$h = void 0)),
                    this.Ih() && this.Ch(),
                    e.data && this.Sh(e.data);
                });
            }
            start() {
              return i(this, void 0, void 0, function* () {
                if (this.$) return;
                this.$ = !0;
                const e = yield (0, r.getAudioResources)();
                (this.Th = e.context), (this.Ah = e.streamNode);
                const { analyserNode: t, processorNode: s } = yield this.Eh(e);
                (this.Ph = t),
                  (this.Lh = s),
                  (s.port.onmessage = this.zh),
                  (this.$h = new o.Deferred()),
                  yield this.$h.promise;
              });
            }
            stop() {
              return i(this, void 0, void 0, function* () {
                return this.se();
              });
            }
            getAnalyser() {
              return this.Ph;
            }
            on(e, t) {
              this.jh.bind(e, t);
            }
            Eh(e) {
              return i(this, void 0, void 0, function* () {
                const { context: t, streamNode: s } = e;
                yield t.audioWorklet.addModule(this.kh);
                const i = new AudioWorkletNode(t, l),
                  o = t.createAnalyser();
                return (
                  (o.smoothingTimeConstant = h),
                  (o.fftSize = d),
                  (this.Fh = window.setInterval(() => {
                    this.Nh();
                  }, u)),
                  s.connect(o).connect(i).connect(t.destination),
                  { analyserNode: o, processorNode: i }
                );
              });
            }
            Ih() {
              return this._h === p;
            }
            Ch() {
              const e = this._h < p ? this.yh.slice(0, this._h) : this.yh;
              (this._h = 0), this.Rh(e);
            }
            Sh(e) {
              for (const t of e) this.yh[this._h++] = t;
            }
            Rh(e) {
              var t, s;
              const i =
                null !==
                  (s =
                    null === (t = this.Th) || void 0 === t
                      ? void 0
                      : t.sampleRate) && void 0 !== s
                  ? s
                  : g;
              try {
                const t = this.Dh(e, i, b);
                this.jh.trigger(a.UserAudioEvent.AudioData, t);
              } catch (e) {
                this.stop();
              }
            }
            Dh(e, t, s) {
              if (s === t) return e;
              if (s > t) throw Error();
              let i = [];
              switch (t) {
                case g:
                  i = f;
                  break;
                case m:
                  i = w;
                  break;
                default:
                  throw Error();
              }
              const o = t / s;
              let r, a, n;
              const c = this.Oh,
                l = this.Mh;
              c
                ? ((r = Math.floor(e.length % o)),
                  (a = e.length - r),
                  (n = 0 === r ? Array.from(e) : e.slice(0, a)))
                : ((r = Math.floor((e.length + l.length - i.length) % o)),
                  (a = e.length + l.length - i.length - r),
                  (n = new Float32Array(l.length + a)),
                  n.set(l),
                  n.set(e.slice(0, a), l.length));
              const h = Math.floor(a / o),
                d = new Int16Array(h);
              if (t === g)
                for (let e = i.length; e < n.length; e += o) {
                  let t = 0;
                  for (let s = 0; s < i.length; s++) t += n[e - s] * i[s];
                  const s = 32767 * Math.max(Math.min(t, 1), -1);
                  d[(e - i.length) / o] = s;
                }
              else {
                const e = [];
                for (let t = i.length; t < n.length; t++) {
                  let s = 0;
                  for (let e = 0; e < i.length; e++) s += n[t - e] * i[e];
                  e[t - i.length] = s;
                }
                for (let t = 0; t < h; t++) {
                  const s = 3,
                    i = t * o,
                    r = Math.floor(i) - s + 1,
                    a = Math.floor(i) + s;
                  let n = 0;
                  for (let t = r; t <= a; t++) {
                    n +=
                      (t < 0 ? e[0] : t >= e.length ? e[e.length - 1] : e[t]) *
                      v(s, i - t);
                  }
                  d[t] = 32767 * Math.max(Math.min(n, 1), -1);
                }
              }
              return (
                (this.Mh = c
                  ? e.slice(a - i.length - l.length)
                  : e.slice(a - i.length - (l.length - i.length))),
                (this.Oh = !1),
                d.buffer
              );
            }
            Nh() {
              const e = this.Ph;
              if (e) {
                const t = new Uint8Array(e.frequencyBinCount);
                e.getByteFrequencyData(t),
                  this.jh.trigger(a.UserAudioEvent.AnalyserData, t);
              }
            }
            se() {
              return i(this, void 0, void 0, function* () {
                var e, t, s, i, o, r, a;
                this.$ &&
                  ((this.$ = !1),
                  clearInterval(this.Fh),
                  null === (e = this.$h) || void 0 === e || e.reject(),
                  (this.$h = void 0),
                  null === (t = this.Lh) || void 0 === t || t.disconnect(),
                  null === (s = this.Ph) || void 0 === s || s.disconnect(),
                  null ===
                    (o =
                      null === (i = this.Ah) || void 0 === i
                        ? void 0
                        : i.mediaStream) ||
                    void 0 === o ||
                    o.getAudioTracks().forEach((e) => {
                      e.stop();
                    }),
                  null === (r = this.Ah) || void 0 === r || r.disconnect(),
                  yield null === (a = this.Th) || void 0 === a
                    ? void 0
                    : a.suspend(),
                  (this.Lh = void 0),
                  (this.Ph = void 0),
                  (this.Ah = void 0),
                  (this.Oh = !0),
                  (this.Mh = new Float32Array(0)),
                  (this.yh = new Float32Array(p)),
                  (this._h = 0));
              });
            }
          }
          t.UserAudioProviderService = c;
          const l = "oda-voice-processor-worklet",
            h = 0.8,
            d = 256,
            p = 4096,
            u = 33,
            g = 48e3,
            m = 44100,
            b = 16e3,
            f = [
              -25033838264794034e-21, -3645156113737857e-20,
              -11489993827892933e-21, 393243788874656e-19, 6998419352067277e-20,
              37556691270439976e-21, -476966455345305e-19,
              -0.00011379935461751734, -8400957697117619e-20,
              4208817777607469e-20, 0.00016391587447478332,
              0.00015508372993570357, -1253765788919669e-20,
              -0.00021258262011091092, -0.0002524059896175195,
              -51874329668708116e-21, 0.0002479230009768214,
              0.00037351534477673157, 0.00016157590781788105,
              -0.0002541085239198603, -0.000510486865332593,
              -0.0003246104617540939, 0.00021219136947965464,
              0.0006488877825604561, 0.0005444416935293036,
              -0.0001016639071691704, -0.0007673001147209819,
              -0.0008176720912938691, -972696982411551e-19,
              0.0008376185852528038, 0.0011319450250252222,
              0.0004008193339799052, -0.0008262743020160207,
              -0.0014643282305934196, -0.0008183365045047033,
              0.0006964471772153777, 0.001780467922489105,
              0.0013489288090360295, -0.00041122152287042,
              -0.0020347535966250413, -0.0019782994815083733,
              -6247794246099269e-20, 0.002171643809964705,
              0.0026761621389245617, 0.00074944268608935, -0.00212817775887288,
              -0.003394541347147186, -0.0016615884301227524,
              0.001837545335885159, 0.004067170702246546, 0.0027936171643976352,
              -0.001233420727213658, -0.004610035314537476,
              -0.004119319153202972, 0.00025459137646049936,
              0.00492286494534436, 0.005588805700369816, 0.001150762425755883,
              -0.004891042781491068, -0.0071267634777626675,
              -0.003021979039818941, 0.00438688631315642, 0.008631467181982988,
              0.005385139236634672, -0.003268406079325266,
              -0.009973661255235284, -0.008256256502745316,
              0.0013719935383757782, 0.010993210336541666, 0.011651337116264694,
              0.0015082475865128093, -0.01148872195209017,
              -0.015609515327517686, -0.005671504441670989,
              0.011188303272599716, 0.02024519058502148, 0.011637590928971467,
              -0.009667754909210324, -0.025878090076785515,
              -0.020500381603699786, 0.006098908137700642, 0.033428666116203716,
              0.03513487017573178, 0.001719739622764723, -0.046085580848361105,
              -0.06623078150315037, -0.023349941728869696, 0.08292213207159124,
              0.21069217442624302, 0.2973829711397418, 0.2973829711397419,
              0.21069217442624305, 0.08292213207159124, -0.023349941728869693,
              -0.06623078150315037, -0.046085580848361105,
              0.0017197396227647225, 0.03513487017573178, 0.033428666116203716,
              0.006098908137700641, -0.020500381603699783,
              -0.025878090076785508, -0.009667754909210326,
              0.011637590928971469, 0.020245190585021472, 0.011188303272599716,
              -0.00567150444167099, -0.015609515327517682, -0.01148872195209017,
              0.001508247586512809, 0.011651337116264699, 0.010993210336541666,
              0.0013719935383757782, -0.008256256502745314,
              -0.009973661255235283, -0.0032684060793252657,
              0.00538513923663467, 0.008631467181982988, 0.004386886313156419,
              -0.0030219790398189413, -0.0071267634777626675,
              -0.0048910427814910715, 0.0011507624257558842,
              0.005588805700369813, 0.00492286494534436, 0.00025459137646049936,
              -0.004119319153202973, -0.004610035314537475,
              -0.0012334207272136583, 0.002793617164397636,
              0.004067170702246546, 0.0018375453358851592,
              -0.0016615884301227509, -0.0033945413471471847,
              -0.0021281777588728797, 0.0007494426860893505,
              0.0026761621389245612, 0.0021716438099647056,
              -6247794246099253e-20, -0.001978299481508373,
              -0.0020347535966250404, -0.00041122152287042,
              0.0013489288090360292, 0.0017804679224891048,
              0.0006964471772153777, -0.0008183365045047026,
              -0.00146432823059342, -0.0008262743020160207,
              0.0004008193339799063, 0.0011319450250252222,
              0.0008376185852528037, -9726969824115494e-20,
              -0.0008176720912938694, -0.0007673001147209783,
              -0.00010166390716916983, 0.0005444416935293033,
              0.0006488877825604562, 0.0002121913694796546,
              -0.00032461046175409424, -0.000510486865332593,
              -0.00025410852391986036, 0.0001615759078178811,
              0.0003735153447767315, 0.00024792300097682137,
              -5187432966870808e-20, -0.0002524059896175194,
              -0.00021258262011091095, -1253765788919669e-20,
              0.0001550837299357036, 0.0001639158744747833,
              42088177776074685e-21, -8400957697117623e-20,
              -0.00011379935461751733, -4769664553453051e-20,
              3755669127044002e-20, 699841935206728e-19, 393243788874656e-19,
              -11489993827892933e-21, -3645156113737856e-20,
              -2503383826479402e-20,
            ],
            w = [
              -5044267067893139e-21, 5738740247594612e-21, 1611195555688156e-20,
              10560179594562795e-21, -1242816862904201e-20,
              -3084430704328611e-20, -18160396924882423e-21,
              2303124169528074e-20, 5216612702894834e-20, 2806026886746509e-20,
              -389608521587068e-19, -8174245278012476e-20,
              -4037543061985353e-20, 619375276294956e-19,
              0.00012143092661620545, 55083199655424166e-21,
              -9401891583478883e-20, -0.00017326981522755043,
              -7198069055926206e-20, 0.0001376274218691789,
              0.00023946132645647525, 9064030545698025e-20,
              -0.00019557611633250834, -0.0003223511502826996,
              -0.00011036322783022617, 0.0002710935667931249,
              0.00042440564349633953, 0.00013013140955365376,
              -0.00036784896615780913, -0.0005481886438481025,
              -0.00014855826094166272, 0.0004899798946967381,
              0.000696340560985472, 0.00016383778624615643,
              -0.0006421263408051642, -0.0008715631880363658,
              -0.00017369118859371453, 0.000829476349448821,
              0.0010766146787146871, 0.00017530890385814463,
              -0.0010578310750603923, -0.001314320458073489,
              -0.0001652844648711556, 0.0013337004262191077,
              0.0015876076783199174, 0.000139534308084411,
              -0.0016644454627712116, -0.001899573527380014,
              -9319422024995832e-20, 0.002058491185395933,
              0.0022536018141979036, 20477911370491685e-21,
              -0.0025256449668619525, -0.0026535487754524955,
              8552498376473957e-20, 0.0030775744811722015, 0.0031040297261921,
              -0.00023314744969763122, -0.003728529808331677,
              -0.003610856230113392, 0.000432598472497653,
              0.0044964472481822506, 0.004181705019767344,
              -0.0006966685466235378, -0.005404666489478738,
              -0.00482715710731867, 0.0010418556659416306, 0.006484667519607787,
              0.00556235368742558, -0.0014902159613265254,
              -0.007780573986407925, -0.0064097301786953595,
              0.002072517010858728, 0.009356870546119134, 0.0074037416266333166,
              -0.00283386009764953, -0.011312323822665827,
              -0.008599512596140524, 0.003844300507349054, 0.013806774337071994,
              0.01008985372973804, -0.005220460312862638, -0.01711716324115331,
              -0.01204196749753927, 0.007174046245357611, 0.021768247992024713,
              0.01478690833035584, -0.010136389804721707, -0.02888735624896028,
              -0.019078400739739057, 0.015146805312378952, 0.041410446665863104,
              0.027068163980255515, -0.025512027260482153, -0.07011218378743589,
              -0.04829678433503421, 0.06041368701604651, 0.21199607414538668,
              0.3213532652447261, 0.3213532652447261, 0.21199607414538668,
              0.060413687016046526, -0.04829678433503422, -0.07011218378743589,
              -0.025512027260482153, 0.027068163980255515, 0.041410446665863104,
              0.015146805312378952, -0.019078400739739057, -0.02888735624896028,
              -0.010136389804721703, 0.01478690833035584, 0.021768247992024713,
              0.007174046245357611, -0.01204196749753927, -0.01711716324115331,
              -0.005220460312862639, 0.010089853729738038, 0.013806774337071994,
              0.0038443005073490553, -0.008599512596140524,
              -0.011312323822665827, -0.0028338600976495314,
              0.007403741626633317, 0.009356870546119134, 0.002072517010858727,
              -0.006409730178695359, -0.007780573986407925,
              -0.001490215961326526, 0.005562353687425577, 0.006484667519607787,
              0.0010418556659416256, -0.004827157107318673,
              -0.005404666489478739, -0.0006966685466235378,
              0.004181705019767345, 0.004496447248182251, 0.0004325984724976533,
              -0.003610856230113392, -0.003728529808331677,
              -0.0002331474496976315, 0.0031040297261921003,
              0.003077574481172201, 8552498376473897e-20, -0.002653548775452496,
              -0.002525644966861952, 2047791137049164e-20, 0.002253601814197904,
              0.002058491185395933, -9319422024995909e-20,
              -0.001899573527380014, -0.0016644454627712118,
              0.00013953430808441038, 0.0015876076783199174,
              0.0013337004262191077, -0.0001652844648711556,
              -0.0013143204580734896, -0.0010578310750603925,
              0.00017530890385814333, 0.0010766146787146878,
              0.0008294763494488195, -0.00017369118859371463,
              -0.00087156318803637, -0.0006421263408051633,
              0.00016383778624615698, 0.0006963405609854716,
              0.0004899798946967381, -0.00014855826094166245,
              -0.0005481886438481027, -0.00036784896615780924,
              0.00013013140955365368, 0.00042440564349633964,
              0.00027109356679312505, -0.00011036322783022619,
              -0.0003223511502826996, -0.00019557611633250842,
              9064030545698017e-20, 0.00023946132645647525,
              0.00013762742186917883, -7198069055926207e-20,
              -0.0001732698152275505, -9401891583478886e-20,
              5508319965542416e-20, 0.00012143092661620549,
              6193752762949557e-20, -4037543061985352e-20,
              -8174245278012477e-20, -38960852158706805e-21,
              28060268867465078e-21, 52166127028948336e-21,
              2303124169528077e-20, -18160396924882423e-21,
              -30844307043286126e-21, -12428168629042018e-21,
              10560179594562806e-21, 1611195555688157e-20, 5738740247594605e-21,
              -5044267067893138e-21,
            ],
            v = (e, t) => {
              let s;
              if (0 === t) s = 1;
              else if (Math.abs(t) >= e) s = 0;
              else {
                const i = Math.PI * t;
                s = (e * Math.sin(i) * Math.sin(i / e)) / Math.pow(i, 2);
              }
              return s;
            };
        },
        7585: (e, t) => {
          Object.defineProperty(t, "p", { value: !0 }),
            (t.createAudioWorklet = void 0);
          t.createAudioWorklet = (e) => {
            const t = `\nclass VoiceProcessor extends AudioWorkletProcessor {\n    process(inputs) {\n        this.port.postMessage(inputs[0][0]);\n        return true;\n    }\n}\n\nregisterProcessor('${e}', VoiceProcessor);`;
            return URL.createObjectURL(
              new Blob([t], { type: "application/javascript" })
            );
          };
        },
        7262: function (e, t, s) {
          var i =
            (this && this.v) ||
            function (e, t, s, i) {
              return new (s || (s = Promise))(function (o, r) {
                function a(e) {
                  try {
                    c(i.next(e));
                  } catch (e) {
                    r(e);
                  }
                }
                function n(e) {
                  try {
                    c(i.throw(e));
                  } catch (e) {
                    r(e);
                  }
                }
                function c(e) {
                  var t;
                  e.done
                    ? o(e.value)
                    : ((t = e.value),
                      t instanceof s
                        ? t
                        : new s(function (e) {
                            e(t);
                          })).then(a, n);
                }
                c((i = i.apply(e, t || [])).next());
              });
            };
          Object.defineProperty(t, "p", { value: !0 }),
            (t.getAudioResources = void 0);
          const o = s(6246);
          t.getAudioResources = () =>
            i(void 0, void 0, void 0, function* () {
              if (!r()) throw Error(o.RecognitionError.RecognitionNoAPI);
              return a();
            });
          const r = () => {
              var e;
              return !!(null === (e = navigator.mediaDevices) || void 0 === e
                ? void 0
                : e.getUserMedia);
            },
            a = () =>
              i(void 0, void 0, void 0, function* () {
                try {
                  const e = yield navigator.mediaDevices.getUserMedia({
                      audio: !0,
                    }),
                    t = new AudioContext();
                  return {
                    context: t,
                    streamNode: t.createMediaStreamSource(e),
                  };
                } catch (e) {
                  throw Error(o.RecognitionError.RecognitionNoAPI);
                }
              });
        },
        6323: (e, t) => {
          Object.defineProperty(t, "p", { value: !0 }),
            (t.drawVisualizer = void 0);
          t.drawVisualizer = (e, t, o = "#000") => {
            const r = t.height,
              a = t.width,
              n = Math.floor(r / 2);
            let c = s(e, 31);
            c = i(c, r / 255);
            const l = t.getContext("2d");
            if (l) {
              (l.fillStyle = o), l.clearRect(0, 0, a, r), l.save();
              let e = 0;
              c.forEach((t) => {
                const s = Math.ceil(t / 2) + 1;
                l.fillRect(e, n - s, 2, 2 * s), (e += 8);
              }),
                l.save();
            }
          };
          const s = (e, t) => {
              const s = Math.ceil(t / 2),
                i = e.length / s,
                o = [],
                r = [];
              for (let t = 0; t < e.length; t += i) {
                const s =
                  e
                    .slice(t, t + i)
                    .map((e) => e * e)
                    .reduce((e, t) => e + t, 0) / i;
                o.push(s), r.unshift(s);
              }
              return o.splice(0, 1), r.concat(o);
            },
            i = (e, t) => e.map((e) => e * t);
        },
        2175: function (e, t, s) {
          var i =
            (this && this.v) ||
            function (e, t, s, i) {
              return new (s || (s = Promise))(function (o, r) {
                function a(e) {
                  try {
                    c(i.next(e));
                  } catch (e) {
                    r(e);
                  }
                }
                function n(e) {
                  try {
                    c(i.throw(e));
                  } catch (e) {
                    r(e);
                  }
                }
                function c(e) {
                  var t;
                  e.done
                    ? o(e.value)
                    : ((t = e.value),
                      t instanceof s
                        ? t
                        : new s(function (e) {
                            e(t);
                          })).then(a, n);
                }
                c((i = i.apply(e, t || [])).next());
              });
            };
          Object.defineProperty(t, "p", { value: !0 }),
            (t.AuthTokenService = void 0);
          const o = s(7689),
            r = s(1590),
            a = s(9504);
          class n {
            static getInstance() {
              return this._ || (this._ = new n()), this._;
            }
            get() {
              return i(this, void 0, void 0, function* () {
                if (this.Hh && d(this.Hh)) return this.Hh;
                const e = yield this.Uh();
                this.Hh = new r.JWT(e);
                try {
                  if (
                    ((function (e) {
                      e || u(o.AuthError.AuthNoToken);
                      const t = "iat",
                        s = e.getClaim(t);
                      p(t, l, s);
                      const i = e.getClaim(h);
                      p(h, l, i), i <= s && u(o.AuthError.AuthExpLessThanIat);
                      const r = "channelId",
                        a = e.getClaim(r);
                      p(r, c, a);
                      const n = "userId",
                        d = e.getClaim(n);
                      p(n, c, d);
                    })(this.Hh),
                    d(this.Hh))
                  )
                    return this.Hh;
                  throw Error(o.AuthError.AuthExpiredToken);
                } catch (e) {
                  throw e;
                }
              });
            }
            reset() {
              this.Hh = void 0;
            }
            setFetch(e) {
              if (!(0, a.isFunction)(e))
                throw new Error(
                  "'generateAuthToken' is not a function. Create a function that returns a Promise that resolves to a new JWT when called."
                );
              (this.Uh = e), this.reset();
            }
          }
          t.AuthTokenService = n;
          const c = "string",
            l = "number",
            h = "exp";
          function d(e) {
            const t = Math.floor((Date.now() + 2e4) / 1e3);
            return e.getClaim(h) > t;
          }
          function p(e, t, s) {
            null == s && u(`AuthNo${e}`),
              typeof s !== t && u(`AuthInvalid${e}`),
              "number" == typeof s
                ? s <= 0 && u(`AuthNegative${e}`)
                : s.length || u(`AuthEmpty${e}`);
          }
          function u(e) {
            throw Error(e);
          }
        },
        7689: (e, t) => {
          Object.defineProperty(t, "p", { value: !0 }), (t.AuthError = void 0);
          t.AuthError = {
            AuthExpiredToken: "AuthExpiredToken",
            AuthNoToken: "AuthNoToken",
            AuthNoChannelId: "AuthNochannelId",
            AuthNoUserId: "AuthNouserId",
            AuthNoExp: "AuthNoexp",
            AuthNoIat: "AuthNoiat",
            AuthInvalidChannelId: "AuthInvalidchannelId",
            AuthInvalidUserId: "AuthInvaliduserId",
            AuthInvalidExp: "AuthInvalidexp",
            AuthInvalidIat: "AuthInvalidiat",
            AuthEmptyChannelIdClaim: "AuthInvalidchannelId",
            AuthEmptyUserIdClaim: "AuthInvaliduserId",
            AuthNegativeExp: "AuthNegativeexp",
            AuthNegativeIat: "AuthNegativeiat",
            AuthExpLessThanIat: "AuthExpLessThanIat",
          };
        },
        2003: function (e, t, s) {
          var i =
              (this && this.t) ||
              (Object.create
                ? function (e, t, s, i) {
                    void 0 === i && (i = s);
                    var o = Object.getOwnPropertyDescriptor(t, s);
                    (o &&
                      !("get" in o ? !t.p : o.writable || o.configurable)) ||
                      (o = {
                        enumerable: !0,
                        get: function () {
                          return t[s];
                        },
                      }),
                      Object.defineProperty(e, i, o);
                  }
                : function (e, t, s, i) {
                    void 0 === i && (i = s), (e[i] = t[s]);
                  }),
            o =
              (this && this.u) ||
              function (e, t) {
                for (var s in e)
                  "default" === s ||
                    Object.prototype.hasOwnProperty.call(t, s) ||
                    i(t, e, s);
              };
          Object.defineProperty(t, "p", { value: !0 }),
            o(s(2175), t),
            o(s(7689), t),
            o(s(1590), t),
            o(s(9633), t);
        },
        1590: (e, t) => {
          Object.defineProperty(t, "p", { value: !0 }), (t.JWT = void 0);
          t.JWT = class {
            constructor(e) {
              this.token = e;
              const t = this.token.split(".");
              (this.header = JSON.parse(atob(t[0]))),
                (this.payload = JSON.parse(atob(t[1])));
            }
            getClaim(e) {
              return this.payload[e];
            }
          };
        },
        9633: (e, t) => {
          Object.defineProperty(t, "p", { value: !0 });
        },
        8514: (e, t) => {
          Object.defineProperty(t, "p", { value: !0 });
        },
        5277: (e, t) => {
          Object.defineProperty(t, "p", { value: !0 }), (t.Deferred = void 0);
          t.Deferred = class {
            constructor() {
              (this.promise = new Promise((e, t) => {
                (this.resolve = e), (this.reject = t);
              })),
                Object.freeze(this);
            }
          };
        },
        5624: (e, t) => {
          Object.defineProperty(t, "p", { value: !0 }),
            (t.isMobile = t.isAndroid = t.isApple = t.getDeviceType = void 0);
          const s = () => /Android/i.test(navigator.userAgent);
          t.isAndroid = s;
          const i = () =>
            /iPhone|iPad/i.test(navigator.userAgent) && !window.MSStream;
          t.isApple = i;
          t.isMobile = () => s() || i();
          t.getDeviceType = () => (s() ? "android" : i() ? "ios" : "desktop");
        },
        3392: (e, t) => {
          Object.defineProperty(t, "p", { value: !0 }),
            (t.stringToHTML =
              t.safeHTML =
              t.removeDisplayNoneAndDecode =
              t.parseDOM =
              t.isVisible =
              t.decodeHTMLEntites =
                void 0);
          t.removeDisplayNoneAndDecode = (e) => {
            var t;
            const i = document.createElement("div");
            (i.style.display = "none"),
              document.body.appendChild(i),
              (i.innerHTML = e),
              s(i);
            const o = null !== (t = i.textContent) && void 0 !== t ? t : "";
            return i.remove(), o;
          };
          const s = (e) => {
              for (let t = e.childElementCount - 1; t >= 0; t--) {
                const i = e.children[t],
                  o = window.getComputedStyle(i);
                "none" === o.display || "hidden" === o.visibility
                  ? i.remove()
                  : s(i);
              }
            },
            i = (e) => {
              const t = new DOMParser().parseFromString(
                e.replace(/\r\n|\n|\r/g, "<br/>"),
                "text/html"
              );
              return null == t ? void 0 : t.body;
            };
          t.parseDOM = i;
          t.safeHTML = (e) => {
            const t = i(e);
            t.querySelectorAll("script, iframe, link, object").forEach((e) => {
              e.remove();
            });
            return (
              t.querySelectorAll("*").forEach((e) => {
                for (const t of e.attributes) o(t) && e.removeAttribute(t.name);
              }),
              t.innerHTML
            );
          };
          const o = (e) => {
            const t = e.name.toLowerCase(),
              s = e.value.toLowerCase();
            return (
              t.startsWith("on") || "style" === t || s.startsWith("javascript")
            );
          };
          t.stringToHTML = (e) => {
            const t = document.createElement("template");
            return (t.innerHTML = e.trim()), t.content.firstChild;
          };
          t.decodeHTMLEntites = (e) => {
            const t = document.createElement("textarea");
            return (t.innerHTML = e), t.value;
          };
          t.isVisible = (e) => {
            if (!e) return !1;
            const t = window.getComputedStyle(e);
            return (
              !!(
                "none" !== t.display &&
                "hidden" !== t.visibility &&
                "0" !== t.opacity &&
                e.offsetHeight &&
                e.offsetWidth &&
                e.getClientRects().length
              ) && null !== e.offsetParent
            );
          };
        },
        6362: (e, t) => {
          Object.defineProperty(t, "p", { value: !0 }), (t.KeyCode = void 0);
          t.KeyCode = {
            Return: "Enter",
            Esc: "Escape",
            Space: "Space",
            Left: "ArrowLeft",
            Up: "ArrowUp",
            Right: "ArrowRight",
            Down: "ArrowDown",
            Tab: "Tab",
            PageDown: "PageDown",
            PageUp: "PageUp",
            Home: "Home",
            End: "End",
            Backspace: "Backspace",
          };
        },
        604: (e, t, s) => {
          Object.defineProperty(t, "p", { value: !0 }),
            (t.generateEventDispatcher = void 0);
          const i = s(9504);
          t.generateEventDispatcher = () => {
            const e = new Map();
            return {
              bind: (t, s) => {
                var o;
                t &&
                  s &&
                  (0, i.isFunction)(s) &&
                  (e.has(t) || e.set(t, new Set()),
                  null === (o = e.get(t)) || void 0 === o || o.add(s));
              },
              trigger: (t, s) => {
                const o = e.get(t);
                o &&
                  o.forEach((e) => {
                    try {
                      e((0, i.clone)(s));
                    } catch (e) {
                      console.error(`${String(t)} listener error`, e);
                    }
                  });
              },
              unbind: (t, s) => {
                if (t) {
                  if (s) {
                    const i = e.get(t);
                    i && (i.delete(s), 0 === i.size && e.delete(t));
                  } else e.delete(t);
                } else e.clear();
              },
            };
          };
        },
        2050: (e, t, s) => {
          Object.defineProperty(t, "p", { value: !0 }),
            (t.isSameDay = t.formatDate = void 0);
          const i = s(9504);
          t.formatDate = (e, { pattern: t, locale: s }) => {
            const a = new Date(e);
            if ("string" == typeof t)
              try {
                return o(a, t);
              } catch (e) {}
            else if ((0, i.isObject)(t))
              return new Intl.DateTimeFormat(s, t).format(a);
            return r(a, s);
          };
          const o = (e, t) => {
              const s = e.getDate(),
                i = e.getDay(),
                o = a[i],
                r = e.getMonth() + 1,
                p = n[r - 1],
                u = `${e.getFullYear()}`,
                g = e.getHours(),
                m = e.getMinutes(),
                b = e.getSeconds(),
                f = e.getMilliseconds(),
                w = g >= c ? "PM" : "AM",
                v = l(e),
                x = g % c || c,
                k = {
                  DD: d(s),
                  Do: `${s}${h(s)}`,
                  D: `${s}`,
                  dddd: o,
                  ddd: o.substring(0, 3),
                  d: `${i}`,
                  MMMM: p,
                  MMM: p.substring(0, 3),
                  MM: d(r),
                  M: `${r}`,
                  YYYY: u,
                  YY: u.slice(-2),
                  HH: d(g),
                  H: `${g}`,
                  hh: d(x),
                  h: `${x}`,
                  mm: d(m),
                  m: `${m}`,
                  ss: d(b),
                  s: `${b}`,
                  SSS: `${f}`,
                  SS: "" + (f % 100),
                  S: "" + (f % 1e3),
                  A: w,
                  a: w.toLowerCase(),
                  ZZ: v.replace(":", ""),
                  Z: v,
                };
              return t.replace(
                /DD|Do|D|dddd|ddd|d|MMMM|MMM|MM|M|YYYY|YY|HH|H|hh|h|mm|m|ss|s|SSS|SS|S|A|a|ZZ|Z/g,
                (e) => k[e]
              );
            },
            r = (e, t) => {
              const s = null != t ? t : "en";
              return `${e
                .toLocaleDateString(s, {
                  weekday: "short",
                  month: "short",
                  day: "numeric",
                })
                .replace(/,/g, "")}, ${e.toLocaleTimeString(s, {
                hour: "numeric",
                minute: "numeric",
                hour12: !0,
              })}`;
            },
            a = [
              "Sunday",
              "Monday",
              "Tuesday",
              "Wednesday",
              "Thursday",
              "Friday",
              "Saturday",
            ],
            n = [
              "January",
              "February",
              "March",
              "April",
              "May",
              "June",
              "July",
              "August",
              "September",
              "October",
              "November",
              "December",
            ],
            c = 12,
            l = (e) => {
              const t = e.getTimezoneOffset(),
                s = Math.abs(t);
              return `${s === t ? "+" : "-"}${d(Math.floor(s / 60))}:${d(
                s % 60
              )}`;
            },
            h = (e) => {
              let t = "th";
              if (e >= 11 && e <= 13) return t;
              switch (e % 10) {
                case 1:
                  t = "st";
                  break;
                case 2:
                  t = "nd";
                  break;
                case 3:
                  t = "rd";
              }
              return t;
            },
            d = (e) => `${e}`.padStart(2, "0");
          t.isSameDay = (e, t) => {
            const s = new Date(e),
              i = new Date(t);
            return (
              s.getDate() === i.getDate() &&
              s.getMonth() === i.getMonth() &&
              s.getFullYear() === i.getFullYear()
            );
          };
        },
        5287: (e, t) => {
          Object.defineProperty(t, "p", { value: !0 }), (t.generateID = void 0);
          t.generateID = (e = {}) => {
            if (null === e) return "";
            const {
                prefix: t = "",
                randomPartLength: s = 5,
                separator: i = "-",
                alphanumeric: o = !1,
              } = e,
              r = o ? 36 : 10,
              a = Date.now().toString(r);
            let n = "";
            if (o)
              n = Math.random().toString(r).replace("0.", "").substring(0, s);
            else {
              const e = Math.pow(10, s);
              n = Math.floor(Math.random() * e)
                .toString(r)
                .padStart(s, "0");
            }
            return `${t}${t ? i : ""}${a}${i}${n}`;
          };
        },
        6064: function (e, t, s) {
          var i =
              (this && this.t) ||
              (Object.create
                ? function (e, t, s, i) {
                    void 0 === i && (i = s);
                    var o = Object.getOwnPropertyDescriptor(t, s);
                    (o &&
                      !("get" in o ? !t.p : o.writable || o.configurable)) ||
                      (o = {
                        enumerable: !0,
                        get: function () {
                          return t[s];
                        },
                      }),
                      Object.defineProperty(e, i, o);
                  }
                : function (e, t, s, i) {
                    void 0 === i && (i = s), (e[i] = t[s]);
                  }),
            o =
              (this && this.u) ||
              function (e, t) {
                for (var s in e)
                  "default" === s ||
                    Object.prototype.hasOwnProperty.call(t, s) ||
                    i(t, e, s);
              };
          Object.defineProperty(t, "p", { value: !0 }),
            o(s(6323), t),
            o(s(2003), t),
            o(s(8514), t),
            o(s(5277), t),
            o(s(5624), t),
            o(s(3392), t),
            o(s(6362), t),
            o(s(604), t),
            o(s(2050), t),
            o(s(5287), t),
            o(s(9487), t),
            o(s(9504), t),
            o(s(2930), t),
            o(s(589), t),
            o(s(3172), t);
        },
        9487: (e, t) => {
          Object.defineProperty(t, "p", { value: !0 }),
            (t.isBetween = function (e, t, s) {
              return e >= t && e <= s;
            }),
            (t.isNumber = function (e) {
              return "number" == typeof e;
            });
        },
        9504: (e, t) => {
          Object.defineProperty(t, "p", { value: !0 }),
            (t.setReadOnly =
              t.resetRegex =
              t.pipe =
              t.isObject =
              t.isFunction =
              t.deepFreeze =
              t.clone =
                void 0);
          const s = (e) => "object" == typeof e && null !== e;
          t.isObject = s;
          t.isFunction = (e) => e instanceof Function;
          const i = (e) => {
            if (
              !s(e) ||
              ((t = e), ArrayBuffer.isView(t) && !(t instanceof DataView)) ||
              e instanceof ArrayBuffer ||
              e instanceof Event
            )
              return e;
            var t;
            if (e instanceof Blob) return e.slice(0, e.size, e.type);
            if (e instanceof Error) {
              const t = new e.constructor(e.message);
              return (t.stack = e.stack), (t.name = e.name), t;
            }
            return e instanceof Array
              ? e.map((e) => i(e))
              : e instanceof Date
              ? new Date(e)
              : Object.fromEntries(
                  Object.entries(e).map(([e, t]) => [e, i(t)])
                );
          };
          t.clone = i;
          const o = (e) => {
            if (!s(e)) return e;
            for (const t of Object.values(e)) s(t) && o(t);
            return Object.freeze(e);
          };
          t.deepFreeze = o;
          t.setReadOnly = (e) => {
            const t = {};
            return (
              Object.keys(e).forEach((s) => {
                Object.defineProperty(t, s, {
                  get: () => e[s],
                  enumerable: !0,
                  configurable: !0,
                });
              }),
              t
            );
          };
          t.pipe = (e, ...t) => t.reduce((e, t) => t(e), e);
          t.resetRegex = (e) => ((e.lastIndex = 0), e);
        },
        2930: (e, t) => {
          Object.defineProperty(t, "p", { value: !0 }), (t.startTimer = void 0);
          const s = window.setInterval,
            i = window.setTimeout,
            o = 36e5,
            r = 864e5,
            a = 30 * r,
            n = 365 * r;
          let c;
          const l = () => {
              clearTimeout(c), clearInterval(c);
            },
            h = (e, t, i, o, r, a) => {
              var n;
              let h = 1;
              l(),
                e(
                  (null === (n = t[r]) || void 0 === n
                    ? void 0
                    : n.replace("{0}", `${h}`)) || ""
                ),
                (c = s(() => {
                  var s;
                  h++,
                    i && a && h >= i
                      ? a(e, t)
                      : e(
                          (null === (s = t[r]) || void 0 === s
                            ? void 0
                            : s.replace("{0}", `${h}`)) || ""
                        );
                }, o));
            },
            d = (e, t) => {
              h(e, t, 60, 6e4, "relTimeMin", p);
            },
            p = (e, t) => {
              h(e, t, 24, o, "relTimeHr", u);
            },
            u = (e, t) => {
              h(e, t, 30, r, "relTimeDay", g);
            },
            g = (e, t) => {
              h(e, t, 12, a, "relTimeMon", m);
            },
            m = (e, t) => {
              h(e, t, 0, n, "relTimeYr");
            };
          t.startTimer = (e, t) => {
            l(),
              e(t.relTimeNow || ""),
              (c = i(() => {
                ((e, t) => {
                  l(),
                    e(t.relTimeMoment || ""),
                    (c = i(() => {
                      d(e, t);
                    }, 5e4));
                })(e, t);
              }, 1e4));
          };
        },
        589: (e, t) => {
          Object.defineProperty(t, "p", { value: !0 }),
            (t.requestOn = function (e, t, s) {
              e.addEventListener(t, s);
            }),
            (t.setRequestHeader = function (e, t, s) {
              e.setRequestHeader(t, s);
            });
        },
        3172: (e, t) => {
          Object.defineProperty(t, "p", { value: !0 }),
            (t.stripHTTP =
              t.getWebSocketURL =
              t.getLongPollURL =
              t.buildURL =
                void 0);
          const s = (e, t, s, o) => i(`${e}${t}${o}`, s);
          t.buildURL = s;
          t.getWebSocketURL = (e, t, i = !0, o = "websdk") =>
            s(`ws${i ? "s" : ""}://`, e, t, `/chat/v1/chats/sockets/${o}`);
          t.getLongPollURL = (e, t, i = !0) =>
            s(`http${i ? "s" : ""}://`, e, t, "/chat/v1/chats/message");
          const i = (e, t) => {
            const s = Object.keys(t)
              .map((e) => `${e}=${t[e]}`)
              .join("&");
            return s.length ? `${e}?${s}` : e;
          };
          t.stripHTTP = (e) => e.replace(/^https?:\/\//i, "");
        },
      },
      t = {};
    function s(i) {
      var o = t[i];
      if (void 0 !== o) return o.exports;
      var r = (t[i] = { exports: {} });
      return e[i].call(r.exports, r, r.exports, s), r.exports;
    }
    (s.n = (e) => {
      var t = e && e.p ? () => e.default : () => e;
      return s.d(t, { a: t }), t;
    }),
      (s.d = (e, t) => {
        for (var i in t)
          s.o(t, i) &&
            !s.o(e, i) &&
            Object.defineProperty(e, i, { enumerable: !0, get: t[i] });
      }),
      (s.o = (e, t) => Object.prototype.hasOwnProperty.call(e, t));
    var i = {};
    s.d(i, { default: () => c });
    var o = s(4261),
      r = s(5398),
      a = s(6064);
    const n = {};
    function c(e, t) {
      let s;
      const i = (0, r.i)(e);
      let d;
      const p = (0, a.generateEventDispatcher)();
      let u = !1;
      const g = new r.c(i);
      (r.d.logLevel = i.isDebugMode
        ? r.d.LOG_LEVEL.DEBUG
        : r.d.LOG_LEVEL.ERROR),
        (r.d.appName = i.name),
        (r.d.appVersion = r.e);
      const m = new r.d("main"),
        b = new o.c({
          URI: i.URI,
          channelId: i.channelId,
          userId: i.userId,
          isTLS: i.enableSecureConnection,
          channel: i.channel,
          enableAttachment: i.enableAttachment,
          enableAttachmentSecurity: i.enableAttachmentSecurity,
          isLongPoll: i.enableLongPolling,
          isTTS: i.enableBotAudioResponse,
          TTSService: i.ttsService,
          tokenGenerator: i.clientAuthEnabled ? t : null,
          recognitionLocale: i.speechLocale,
          retryInterval: i.reconnectInterval,
          retryMaxAttempts: i.reconnectMaxAttempts,
          enableCancelResponse: i.enableCancelResponse,
        });
      if (
        (i.skillVoices &&
          (!i.ttsVoice || (Array.isArray(i.ttsVoice) && !i.ttsVoice.length)) &&
          (i.ttsVoice = i.skillVoices),
        i.enableBotAudioResponse)
      )
        try {
          i.ttsVoice && b.setTTSVoice(i.ttsVoice);
        } catch (e) {
          m.error("Failed to initialize TTS");
        }
      const f = Object.values(o.a),
        w = (e, ...t) => {
          1 === t.length
            ? m.error(
                `Parameter ${t} was not passed for ${e} call. No action processed.`
              )
            : m.error(
                `Parameters ${t.join(
                  ", "
                )} were not passed for ${e} call. No action processed.`
              );
        },
        v = (e) => {
          p.trigger(r.a.MESSAGE_SENT, e), p.trigger(r.a.MESSAGE, e);
        },
        x = (e) => {
          p.trigger(r.a.MESSAGE_RECEIVED, e), p.trigger(r.a.MESSAGE, e);
        },
        k = (e) => {
          p.trigger(r.a.NETWORK, e);
        },
        y = () => {
          (s = new r.g(b, i, {
            connect: this.connect.bind(this),
            openChat: this.openChat.bind(this),
            closeChat: this.closeChat.bind(this),
            handleSessionEnd: O.bind(this),
            receivedMessage: x.bind(this),
            sentMessage: v.bind(this),
            getUnreadMessagesCount: this.getUnreadMessagesCount.bind(this),
            onConnectionStatusChange: k.bind(this),
            util: g,
            eventDispatcher: p,
          })),
            (s.contextWidgetMap = n),
            s.render();
        };
      let _ = () => {
        p.trigger(r.a.READY), (_ = () => {});
      };
      (this.configureWidget = (e, t, o = !0) => {
        const a = new r.b(i, g, e, t, o, n, b, s, p);
        return this.isConnected() || this.connect(), (n[a.threadId] = a), a;
      }),
        (this.updateChatContext = (
          e,
          t,
          s,
          o,
          { event: a, semanticObject: n } = {}
        ) => (
          e || w("updateChatContext", "appContext"),
          b.updateChatContext(
            e,
            {
              properties: Object.assign(Object.assign({}, (0, r.j)(t)), s),
              event: a,
              semanticObject: n,
            },
            o,
            i.sdkMetadata
              ? Object.assign({ version: r.e }, i.sdkMetadata)
              : { version: r.e }
          )
        )),
        (this.connect = ({ URI: e, channelId: t, userId: o } = {}) => {
          let r;
          return (
            e || t || o
              ? (((e, t, o) => {
                  "string" == typeof e && e.length && (i.URI = e),
                    "string" == typeof t && t.length && (i.channelId = t),
                    "string" == typeof o &&
                      o.length &&
                      ((i.userId = o), s.configureStorage());
                })(e, t, o),
                (r = b.connect(i)))
              : (r = b.connect()),
            r
              .then(
                () => {
                  m.debug("Connection ready");
                },
                () => {
                  m.debug("Connection timeout"), s.showConnectionError();
                }
              )
              .finally(() => {
                _();
              }),
            r
          );
        }),
        (this.disconnect = () => (
          i.enableSpeech && this.stopVoiceRecording(),
          i.enableBotAudioResponse && this.cancelTTS(),
          b.disconnect()
        )),
        (this.isConnected = () => b.isConnected()),
        (this.openChat = () => {
          s.isOpen || (s.showChat(), u && (this.connect(), (u = !1))),
            p.trigger(r.a.WIDGET_OPENED);
        }),
        (this.closeChat = () => {
          s.isOpen && s.onClose(), p.trigger(r.a.WIDGET_CLOSED);
        }),
        (this.endChat = () => {
          this.isConnected() && s.sendExitEvent();
        }),
        (this.showWidget = () => {
          null == s || s.showWidget();
        }),
        (this.hideWidget = () => {
          null == s || s.hideWidget();
        });
      const O = () => {
        s.isOpen && this.closeChat(),
          this.disconnect(),
          this.clearConversationHistory(),
          (u = !0),
          p.trigger(r.a.CHAT_END);
      };
      (this.isChatOpened = () => s.isOpen),
        (this.destroy = () => {
          if ((this.disconnect(), this.closeChat(), s.remove(), document)) {
            const e = s.styleSheet;
            e && e.remove();
          }
          p.trigger(r.a.DESTROY), this.off();
          for (const e in this) this[e] && delete this[e];
        }),
        (this.on = (e, t) => {
          switch (e) {
            case o.b.TTSStart:
            case o.b.TTSStop:
              b.on(e, t);
              break;
            default:
              p.bind(e, t);
          }
        }),
        (this.off = (e, t) => {
          switch (e) {
            case o.b.TTSStart:
            case o.b.TTSStop:
              b.off(e, t);
              break;
            default:
              p.unbind(e, t);
          }
        }),
        (this.sendAttachment = (e) =>
          e
            ? s.uploadFile(e)
            : (w("sendAttachment", "file"),
              Promise.reject(new Error("Invalid Parameter")))),
        (this.sendMessage = (e, t) =>
          e
            ? s.sendMessage(e, t)
            : (w("sendMessage", "message"),
              Promise.reject(new Error("Invalid Parameter")))),
        (this.sendUserTypingStatus = (e, t) =>
          e
            ? b.sendUserTypingStatus(e, t)
            : (w("sendUserTypingStatus", "status"),
              Promise.reject(new Error("Invalid Parameter")))),
        (this.updateUser = (e) =>
          e
            ? b
                .updateUser(e, { sdkMetadata: { version: r.e } })
                .then(() => v(e))
            : (w("updateUser", "userDetails"),
              Promise.reject(new Error("Invalid Parameter")))),
        (this.setUserAvatar = (e) => {
          e ? s.setUserAvatar(e) : w("setUserAvatar", "userAvatar");
        }),
        (this.setAgentDetails = (e) => {
          e ? s.setAgentDetails(e) : w("setAgentDetails", "agentDetails");
        }),
        (this.getAgentDetails = () => s.getAgentDetails()),
        (this.setSkillVoices = (e) => {
          if (!b.getTTSService()) return h();
          let t = [];
          return (
            e &&
            !Array.isArray(e) &&
            "string" == typeof (null == e ? void 0 : e.lang)
              ? (t = [e])
              : Array.isArray(e) && (t = e),
            this.setTTSVoice(t)
          );
        }),
        (this.setTTSService = (e) => {
          const t = b.getTTSService();
          t && t.cancel(),
            "string" == typeof e
              ? b.setTTSService(e)
              : b.setTTSService(
                  (function (e) {
                    return (
                      e &&
                      (0, a.isFunction)(e.speak) &&
                      (0, a.isFunction)(e.cancel) &&
                      (0, a.isFunction)(e.getVoice) &&
                      (0, a.isFunction)(e.getVoices) &&
                      (0, a.isFunction)(e.setVoice)
                    );
                  })(e)
                    ? e
                    : null
                );
          const o = b.getTTSService();
          (i.ttsService = o),
            s && s.refreshTTS(),
            o &&
              ((i.enableBotAudioResponse = !0),
              (0, r.k)(o, i.ttsVoice).then((e) => {
                e || (i.ttsVoice = []);
                const t = (0, r.l)({
                  hasRecognition: i.enableSpeech,
                  hasSynthesis: i.enableBotAudioResponse,
                  recognitionLocale: i.speechLocale,
                  synthesisLocales: i.ttsVoice,
                });
                t &&
                  o.setVoice(t).catch((e) => {
                    m.error(e);
                  }),
                  (i.ttsVoice = t);
              }));
        }),
        (this.getTTSVoices = () => b.getTTSVoices()),
        (this.setTTSVoice = (e) => {
          const t = b.getTTSService();
          return t
            ? (0, r.k)(t, i.ttsVoice).then(
                (t) => (
                  (i.ttsVoice = (0, r.l)({
                    hasRecognition: i.enableSpeech,
                    hasSynthesis: i.enableBotAudioResponse,
                    isReset: t,
                    recognitionLocale: i.speechLocale,
                    synthesisLocales: e,
                  })),
                  b.setTTSVoice(e).catch(() => h())
                )
              )
            : h();
        }),
        (this.getTTSVoice = () => {
          try {
            return b.getTTSVoice();
          } catch (e) {
            throw Error(l);
          }
        }),
        (this.speakTTS = (e) => {
          b.speakTTS(e, i.i18n[i.locale]);
        }),
        (this.cancelTTS = () => {
          b.cancelTTS();
        }),
        (this.setPrimaryChatLanguage = (e) => {
          if (null !== e && "string" != typeof e)
            throw Error("Please pass a language string or null as argument");
          this.isConnected()
            ? s.setPrimaryChatLanguage(e)
            : m.error("Not connected. Can not call setPrimaryChatLanguage.");
        }),
        (this.setDelegate = (e) => {
          i.delegate = e;
        }),
        (this.getConversationHistory = () => {
          const e = s.getMessages();
          return {
            messages: e,
            messagesCount: e.length,
            unreadCount: this.getUnreadMessagesCount(),
            userId: i.userId,
          };
        }),
        (this.clearConversationHistory = (e, t = !0) => {
          e && "string" != typeof e
            ? m.error(
                "Argument passed in clearConversationHistory() is not of type string. Returning without execution."
              )
            : ((e && 0 !== e.length) || (e = i.userId),
              t && e === i.userId
                ? s.clearConversationHistory()
                : s.clearMessages(e, r.f.LOCAL));
        }),
        (this.clearAllConversationsHistory = (e = !0) => {
          s.clearAllMessage(), e && s.clearConversationHistory();
        }),
        (this.getSuggestions = (e) =>
          i.enableAutocomplete
            ? e
              ? "string" != typeof e && "number" != typeof e
                ? Promise.reject(
                    "Invalid query parameter type passed for the getSuggestions call."
                  )
                : s.getSuggestions(e)
              : Promise.reject(
                  "No query parameter passed for the getSuggestions call."
                )
            : Promise.reject("Autocomplete suggestions not enabled.")),
        (this.startVoiceRecording = (e, t) =>
          i.enableSpeech
            ? b.startRecognition({
                onRecognitionText: (t) => {
                  null == e || e(t.message);
                },
                onVisualData: null == t ? void 0 : t.onAnalyserFrequencies,
              })
            : Promise.reject(
                new Error(
                  "Speech-to-text feature is not enabled. Initialize the widget with enableSpeech: true to use the service."
                )
              )),
        (this.stopVoiceRecording = () => {
          if (!i.enableSpeech)
            throw new Error(
              "Speech-to-text feature is not enabled. Speech recognition service is not running."
            );
          return b.stopRecognition();
        }),
        (this.setSpeechLocale = (e) => {
          if (!i.enableSpeech) return !1;
          e = e.toLowerCase();
          const t = f.indexOf(e) >= 0;
          if (
            ((i.speechLocale = e),
            b.setRecognitionLocale(e),
            s.setVoiceRecognitionService(t),
            t && i.enableBotAudioResponse)
          ) {
            const e = (0, r.l)({
              hasRecognition: i.enableSpeech,
              hasSynthesis: i.enableBotAudioResponse,
              recognitionLocale: i.speechLocale,
              synthesisLocales: i.ttsVoice,
            });
            e !== i.ttsVoice &&
              ((i.ttsVoice = e), e.length && b.setTTSVoice(e));
          }
          return t;
        }),
        (this.getUnreadMessagesCount = () => {
          if (i.enableHeadless) return 0;
          const e = s.getUnreadMsgsCount();
          return e !== d && ((d = e), p.trigger(r.a.UNREAD, e)), e;
        }),
        (this.setAllMessagesAsRead = () => {
          i.enableHeadless ||
            (this.getUnreadMessagesCount(), s.updateNotificationBadge(0));
        }),
        (this.showTypingIndicator = () => {
          if (!i.showTypingIndicator)
            throw new Error("Typing indicator is configured not to be shown.");
          if (i.enableHeadless)
            throw new Error(
              "Typing indicator cannot be shown in headless mode."
            );
          this.isConnected() && s.showTypingIndicator();
        }),
        (this.setWebViewConfig = (e) => {
          if (i.enableHeadless)
            throw new Error("WebView cannot be configured in headless mode.");
          s.refreshWebView(e);
        }),
        (this.setUserInputMessage = (e) => {
          if (i.enableHeadless)
            throw new Error("User input cannot be set in headless mode.");
          s.setUserInputMessage(e);
        }),
        (this.setUserInputPlaceholder = (e) => {
          if (i.enableHeadless)
            throw new Error("Placeholder cannot be set in headless mode.");
          e
            ? s.setUserInputPlaceholder(e)
            : w("setUserInputPlaceholder", "placeholder text");
        }),
        (this.setHeight = (e) => {
          e ? null == s || s.setHeight(e) : w("setHeight", "height");
        }),
        (this.setWidth = (e) => {
          e ? null == s || s.setWidth(e) : w("setWidth", "width");
        }),
        (this.setSize = (e, t) => {
          e || t
            ? null == s || s.setSize(e, t)
            : w("setSize", "width", "height");
        }),
        (this.setMessagePadding = (e) => {
          e
            ? null == s || s.setMessagePadding(e)
            : w("setMessagePadding", "padding");
        }),
        (this.setChatBubbleIconHeight = (e) => {
          e
            ? null == s || s.setChatBubbleIconHeight(e)
            : w("setChatBubbleIconHeight", "height");
        }),
        (this.setChatBubbleIconWidth = (e) => {
          e
            ? null == s || s.setChatBubbleIconWidth(e)
            : w("setChatBubbleIconWidth", "width");
        }),
        (this.setChatBubbleIconSize = (e, t) => {
          e || !t
            ? null == s || s.setChatBubbleIconSize(e, t)
            : w("setChatBubbleIconSize", "width", "height");
        }),
        (this.setFont = (e) => {
          e ? (g.updateCSSVar("font", e), (i.font = e)) : w("setFont", "font");
        }),
        (this.setFontFamily = (e) => {
          e
            ? (g.updateCSSVar("font-family", e), (i.fontFamily = e))
            : w("setFontFamily", "fontFamily");
        }),
        (this.setFontSize = (e) => {
          e ? g.updateCSSVar("font-size", e) : w("setFontSize", "fontSize");
        }),
        (this.setTextColor = (e) => {
          e
            ? (g.updateCSSVar("--color-bot-text", e),
              g.updateCSSVar("--color-user-text", e))
            : w("setTextColor", "color");
        }),
        (this.setTextColorLight = (e) => {
          e
            ? (g.updateCSSVar("--color-text-light", e),
              (i.colors.textLight = e))
            : w("setTextColorLight", "color");
        }),
        m.debug("onLoad", "load chat widget"),
        y(),
        (0, a.setReadOnly)(this);
      const M = window;
      M && "function" == typeof M.define && M.define.amd && (M.WebSDK = c);
    }
    const l = "Text-to-speech is not available.";
    function h() {
      return (e = l), Promise.reject(Error(e));
      var e;
    }
    return (
      (c.EVENT = r.a),
      (c.SPEECH_LOCALE = o.a),
      (c.THEME = r.h),
      (c.Version = r.e),
      (0, a.deepFreeze)(c),
      (i = i.default)
    );
  })()
);
